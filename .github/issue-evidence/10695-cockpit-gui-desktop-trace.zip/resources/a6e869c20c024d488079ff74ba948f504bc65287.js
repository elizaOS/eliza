const __eliza_dynamic_view_host_external_0 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/agent-surface");
const { useAgentElement: e } = __eliza_dynamic_view_host_external_0;
const __eliza_dynamic_view_host_external_1 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("react");
const { useCallback: t, useEffect: n, useState: r } = __eliza_dynamic_view_host_external_1;
const __eliza_dynamic_view_host_external_2 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/spatial");
const { Button: i, Card: a, Divider: o, HStack: s, Image: c, List: l, Text: u, VStack: d } = __eliza_dynamic_view_host_external_2;
const __eliza_dynamic_view_host_external_3 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("react/jsx-runtime");
const { jsx: f, jsxs: p } = __eliza_dynamic_view_host_external_3;
//#region src/views/viewManagerData.ts
var m = [
	"gui",
	"xr",
	"tui"
];
function h(e) {
	let t = new Set(e);
	return m.filter((e) => t.has(e));
}
function g(e) {
	let t = [], n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = r.modalities ?? [r.viewType ?? "gui"], i = n.get(r.id);
		if (!i) {
			t.push(r.id), n.set(r.id, {
				...r,
				modalities: h(e)
			});
			continue;
		}
		let a = h([...i.modalities ?? [i.viewType ?? "gui"], ...e]), o = (r.viewType ?? "gui") === "gui", s = (i.viewType ?? "gui") === "gui", c = o && !s ? r : i;
		n.set(r.id, {
			...c,
			modalities: a
		});
	}
	return t.map((e) => n.get(e));
}
//#endregion
//#region src/components/ViewManagerSpatialView.tsx
function _(e) {
	return e.modalities ?? [e.viewType ?? "gui"];
}
function v(e) {
	switch (e) {
		case "tui": return "warning";
		case "xr": return "primary";
		default: return "muted";
	}
}
function y({ snapshot: e, onOpenView: t }) {
	let n = g(e.views), r = n.filter((e) => e.available).length;
	return /* @__PURE__ */ p(a, {
		gap: 1,
		padding: 1,
		children: [
			/* @__PURE__ */ p(s, {
				gap: 1,
				align: "center",
				children: [/* @__PURE__ */ f(u, {
					style: "caption",
					tone: "success",
					grow: 1,
					children: e.loading ? "loading" : `${r}/${n.length} ready`
				}), /* @__PURE__ */ f(u, {
					style: "caption",
					tone: "muted",
					children: "views"
				})]
			}),
			e.error ? /* @__PURE__ */ f(u, {
				tone: "danger",
				style: "caption",
				children: e.error
			}) : null,
			/* @__PURE__ */ f(o, { label: "views" }),
			n.length === 0 ? /* @__PURE__ */ f(u, {
				tone: "muted",
				align: "center",
				style: "caption",
				children: "None"
			}) : /* @__PURE__ */ f(l, {
				gap: 1,
				children: n.slice(0, 12).map((e) => /* @__PURE__ */ p(s, {
					gap: 1,
					align: "center",
					agent: `open-${e.id}`,
					children: [
						e.heroImageUrl ? /* @__PURE__ */ f(c, {
							src: e.heroImageUrl,
							alt: "",
							width: 4,
							height: 4
						}) : null,
						/* @__PURE__ */ p(d, {
							gap: 0,
							grow: 1,
							children: [
								/* @__PURE__ */ f(u, {
									bold: !0,
									wrap: !1,
									children: e.label
								}),
								/* @__PURE__ */ f(u, {
									style: "caption",
									tone: "muted",
									wrap: !1,
									children: e.path ?? e.pluginName
								}),
								/* @__PURE__ */ p(s, {
									gap: 1,
									wrap: !0,
									align: "center",
									children: [_(e).map((e) => /* @__PURE__ */ f(u, {
										style: "caption",
										tone: v(e),
										children: e
									}, e)), /* @__PURE__ */ f(u, {
										style: "caption",
										tone: e.available ? "success" : "danger",
										children: e.available ? "ready" : "missing"
									})]
								})
							]
						}),
						/* @__PURE__ */ f(i, {
							variant: "ghost",
							tone: "default",
							agent: `open:${e.id}`,
							onPress: () => t?.(e),
							children: "Open"
						})
					]
				}, e.id))
			})
		]
	});
}
//#endregion
//#region src/views/viewManagerData.js
async function b(e) {
	let t = e ? `?viewType=${e}` : "", n = await fetch(`/api/views${t}`);
	if (!n.ok) throw Error(`HTTP ${n.status}`);
	let r = await n.json();
	return Array.isArray(r.views) ? r.views : [];
}
async function x(e) {
	await fetch(`/api/views/${encodeURIComponent(e.id)}/navigate${e.viewType ? `?viewType=${e.viewType}` : ""}`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			path: e.path,
			viewType: e.viewType
		})
	});
}
async function S(e, t) {
	if (e === "terminal-list-views") return { views: await b("tui") };
	if (e === "terminal-open-view") {
		let e = typeof t?.viewId == "string" ? t.viewId : null;
		if (!e) throw Error("viewId is required");
		let n = (await b("tui")).find((t) => t.id === e);
		if (!n) throw Error(`View "${e}" not found`);
		return await x(n), {
			opened: !0,
			viewId: e,
			viewType: n.viewType ?? "gui"
		};
	}
	throw Error(`Unsupported capability "${e}"`);
}
//#endregion
//#region src/views/ViewManagerView.tsx
var C = "inline-flex items-center justify-center rounded-md border border-border/60 px-3 py-1.5 text-xs font-medium text-muted-strong transition-colors hover:bg-bg-hover hover:text-txt disabled:pointer-events-none disabled:opacity-50";
function w() {
	let [i, a] = r([]), [o, s] = r(!0), [c, l] = r(null), u = t(async () => {
		s(!0), l(null);
		try {
			a(await b());
		} catch (e) {
			l(e instanceof Error ? e.message : "Failed to load views");
		} finally {
			s(!1);
		}
	}, []);
	n(() => {
		u();
	}, [u]);
	let d = t((e) => {
		x(e);
	}, []), m = e({
		id: "views-manager-refresh",
		role: "button",
		label: "Refresh views",
		group: "views-manager",
		description: "Reload the registered views list",
		status: o ? "active" : "inactive",
		onActivate: () => {
			u();
		}
	}), h = {
		views: i,
		loading: o,
		error: c
	};
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ f("div", {
			className: "flex justify-end",
			children: /* @__PURE__ */ f("button", {
				type: "button",
				ref: m.ref,
				...m.agentProps,
				onClick: () => void u(),
				disabled: o,
				"aria-label": "Refresh views",
				className: C,
				children: o ? "Refreshing…" : "Refresh"
			})
		}), /* @__PURE__ */ f(y, {
			snapshot: h,
			onOpenView: d
		})]
	});
}
//#endregion
export { w as ViewManagerView, w as default, S as interact };

//# sourceMappingURL=bundle.js.map