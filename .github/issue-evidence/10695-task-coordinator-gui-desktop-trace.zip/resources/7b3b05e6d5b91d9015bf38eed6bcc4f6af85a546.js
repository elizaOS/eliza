const __eliza_dynamic_view_host_external_0 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui");
const { AlertDialog: e, AlertDialogAction: t, AlertDialogCancel: n, AlertDialogContent: r, AlertDialogDescription: i, AlertDialogFooter: a, AlertDialogHeader: o, AlertDialogTitle: s, AlertDialogTrigger: c, ApiError: l, Button: u, ChatEmptyStateWithRecommendations: d, CockpitTierToggle: f, CockpitView: p, DiffReviewPanel: m, ELIZA_CLOUD_TIER_MODEL: h, client: g, useAppSelectorShallow: _, useRegisterViewChatBinding: v } = __eliza_dynamic_view_host_external_0;
const __eliza_dynamic_view_host_external_1 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("react");
const { useCallback: y, useDeferredValue: b, useEffect: x, useMemo: S, useRef: C, useState: w } = __eliza_dynamic_view_host_external_1;
const __eliza_dynamic_view_host_external_2 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("react/jsx-runtime");
const { Fragment: T, jsx: E, jsxs: D } = __eliza_dynamic_view_host_external_2;
const __eliza_dynamic_view_host_external_3 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("lucide-react");
const { Archive: O, ArrowDownToLine: ee, ArrowLeft: k, Bot: te, Brain: A, Check: j, ChevronDown: M, ChevronRight: N, ChevronUp: P, ChevronsUp: F, Circle: I, CircleAlert: ne, CircleCheck: L, CircleDashed: re, CirclePlay: ie, CircleStop: ae, CircleX: R, Copy: oe, FilePen: se, FilePlus: ce, FileText: le, Gauge: ue, GitBranch: de, GitFork: fe, Globe: pe, Layers: me, Loader: z, OctagonX: he, PanelRightOpen: ge, Pause: _e, Play: ve, RotateCcw: ye, ScrollText: be, Search: xe, Send: Se, Square: Ce, SquareTerminal: we, Terminal: Te, TerminalSquare: Ee, Trash2: De, UserPlus: Oe, UserRound: ke, Wrench: Ae, X: je } = __eliza_dynamic_view_host_external_3;
const __eliza_dynamic_view_host_external_4 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/agent-surface");
const { useAgentElement: B } = __eliza_dynamic_view_host_external_4;
const __eliza_dynamic_view_host_external_5 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/components/ui/select");
const { Select: Me, SelectContent: Ne, SelectItem: Pe, SelectTrigger: Fe } = __eliza_dynamic_view_host_external_5;
const __eliza_dynamic_view_host_external_6 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/components");
const { OrchestratorAccountsView: Ie } = __eliza_dynamic_view_host_external_6;
const __eliza_dynamic_view_host_external_7 = await globalThis.__ELIZA_DYNAMIC_VIEW_IMPORT__("@elizaos/ui/spatial");
const { Button: V, Card: Le, Divider: H, Escape: Re, Field: ze, HStack: U, List: W, Spacer: Be, Text: G, VStack: K } = __eliza_dynamic_view_host_external_7;
//#region \0rolldown/runtime.js
var Ve = Object.create, He = Object.defineProperty, Ue = Object.getOwnPropertyDescriptor, We = Object.getOwnPropertyNames, Ge = Object.getPrototypeOf, Ke = Object.prototype.hasOwnProperty, qe = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), Je = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = We(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !Ke.call(e, s) && s !== n && He(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = Ue(t, s)) || r.enumerable
	});
	return e;
}, Ye = (e, t, n) => (n = e == null ? {} : Ve(Ge(e)), Je(t || !e || !e.__esModule ? He(n, "default", {
	value: e,
	enumerable: !0
}) : n, e));
//#endregion
//#region src/PtyTerminalPane.tsx
function Xe({ sessionId: e, visible: t }) {
	let n = C(null), r = C(null), i = C(null), a = C(!1);
	return x(() => {
		if (a.current) return;
		a.current = !0;
		let t = !1, o, s;
		return (async () => {
			let [{ Terminal: a }, { FitAddon: c }] = await Promise.all([import("./xterm-CSb1Gh9p.js").then((e) => /* @__PURE__ */ Ye(e.default, 1)), import("./addon-fit-m6I4VupF.js").then((e) => /* @__PURE__ */ Ye(e.default, 1))]);
			if (t || !n.current) return;
			let l = getComputedStyle(n.current), u = (e, t) => l.getPropertyValue(e).trim() || t, d = new a({
				allowTransparency: !0,
				convertEol: !0,
				cursorBlink: !0,
				fontFamily: "var(--font-mono, monospace)",
				fontSize: 12,
				scrollback: 5e3,
				theme: {
					background: "rgba(0, 0, 0, 0)",
					black: "#1a1b26",
					blue: "#7aa2f7",
					brightBlack: "#6e7681",
					brightBlue: "#8fb3ff",
					brightCyan: "#a2e9ff",
					brightGreen: "#b9f27c",
					brightMagenta: "#caa9fa",
					brightRed: "#ff7a93",
					brightWhite: "#ffffff",
					brightYellow: "#ffd580",
					cursor: u("--accent", "#5a9a2a"),
					cyan: "#7dcfff",
					foreground: u("--txt", "#e4e4e7"),
					green: "#9ece6a",
					magenta: "#bb9af7",
					red: "#f7768e",
					selectionBackground: u("--accent-muted", "rgba(90, 154, 42, 0.3)"),
					white: "#c0caf5",
					yellow: "#e0af68"
				}
			}), f = new c();
			d.loadAddon(f), d.open(n.current), i.current = f, r.current = { dispose: () => {
				s?.disconnect(), d.dispose();
			} }, requestAnimationFrame(() => {
				requestAnimationFrame(() => {
					if (!t) try {
						f.fit();
					} catch {}
				});
			});
			try {
				let n = await g.getPtyBufferedOutput(e);
				!t && n && (d.write(n.replace(/\x1b\[3J/g, "")), d.scrollToBottom());
			} catch {}
			g.subscribePtyOutput(e), o = g.onWsEvent("pty-output", (n) => {
				n.sessionId === e && typeof n.data == "string" && !t && d.write(n.data.replace(/\x1b\[3J/g, ""));
			}), d.onData((n) => {
				if (!t) try {
					g.sendPtyInput(e, n);
				} catch {}
			}), s = new ResizeObserver(() => {
				if (!(t || !n.current) && !(n.current.clientHeight < 10)) try {
					f.fit(), g.resizePty(e, d.cols, d.rows);
				} catch {}
			}), s.observe(n.current);
		})(), () => {
			t = !0, o?.(), g.unsubscribePtyOutput(e), r.current?.dispose(), r.current = null, i.current = null, a.current = !1;
		};
	}, [e]), x(() => {
		if (!t || !i.current) return;
		let e = requestAnimationFrame(() => {
			try {
				i.current?.fit();
			} catch {}
		});
		return () => cancelAnimationFrame(e);
	}, [t]), /* @__PURE__ */ E("div", {
		ref: n,
		className: "h-full w-full",
		style: { display: t ? "block" : "none" }
	});
}
//#endregion
//#region src/CockpitInteractiveTerminal.tsx
var Ze = g;
function Qe({ tier: e, cwd: t, onClose: n }) {
	let [r, i] = w(null), [a, o] = w("spawning"), [s, c] = w(null), l = C(!1), d = C(null), f = y(async () => {
		o("spawning"), c(null);
		try {
			let { sessionId: n } = await Ze.spawnPtySession({
				kind: "eliza-code",
				tier: e,
				...t ? { cwd: t } : {}
			});
			d.current = n, i(n), o("ready");
		} catch (e) {
			c(e instanceof Error ? e.message : "Couldn't start the interactive terminal."), o("error");
		}
	}, [e, t]);
	x(() => {
		l.current || (l.current = !0, f());
	}, [f]), x(() => () => {
		let e = d.current;
		d.current = null, e && Ze.stopPtySession(e);
	}, []);
	let p = y(() => {
		f();
	}, [f]), m = y(() => {
		let e = d.current;
		d.current = null, e && Ze.stopPtySession(e), n?.();
	}, [n]);
	return /* @__PURE__ */ D("div", {
		"data-testid": "cockpit-interactive-terminal",
		style: {
			position: "relative",
			display: "flex",
			flexDirection: "column",
			height: "100%",
			minHeight: 0,
			background: "var(--bg, #0b0b0f)"
		},
		children: [/* @__PURE__ */ D("div", {
			style: {
				display: "flex",
				alignItems: "center",
				justifyContent: "space-between",
				padding: "6px 10px",
				borderBottom: "1px solid var(--border, rgba(255,255,255,0.08))",
				fontSize: 12,
				color: "var(--txt-muted, #9aa0aa)"
			},
			children: [/* @__PURE__ */ D("span", { children: [
				"eliza-code · ",
				e === "smart" ? "smart" : "fast",
				" · Cerebras"
			] }), /* @__PURE__ */ E("button", {
				type: "button",
				"data-testid": "cockpit-terminal-close",
				onClick: m,
				style: {
					background: "transparent",
					border: "none",
					color: "inherit",
					cursor: "pointer",
					fontSize: 12
				},
				children: "✕"
			})]
		}), /* @__PURE__ */ D("div", {
			style: {
				position: "relative",
				flex: 1,
				minHeight: 0
			},
			children: [
				a === "spawning" ? /* @__PURE__ */ E("div", {
					"data-testid": "cockpit-terminal-spawning",
					style: {
						padding: 16,
						fontSize: 13,
						color: "var(--txt-muted, #9aa0aa)"
					},
					children: "Starting interactive eliza-code on Cerebras…"
				}) : null,
				a === "error" ? /* @__PURE__ */ D("div", {
					"data-testid": "cockpit-terminal-error",
					style: {
						padding: 16,
						fontSize: 13,
						color: "var(--danger, #f7768e)"
					},
					children: [/* @__PURE__ */ E("div", { children: s }), /* @__PURE__ */ E(u, {
						type: "button",
						size: "sm",
						"data-testid": "cockpit-terminal-retry",
						onClick: p,
						style: { marginTop: 10 },
						children: "Retry"
					})]
				}) : null,
				r ? /* @__PURE__ */ E(Xe, {
					sessionId: r,
					visible: a === "ready"
				}) : null
			]
		})]
	});
}
//#endregion
//#region src/PtyConsoleBase.tsx
var $e = 2e5;
function et({ activeSessionId: e, sessions: t, onClose: n, variant: r }) {
	let [i, a] = w(""), [o, s] = w(""), c = C(null), l = S(() => t.find((t) => t.sessionId === e), [e, t]);
	x(() => {
		let t = !1;
		a(""), g.getPtyBufferedOutput(e).then((e) => {
			t || a(nt(e));
		});
		let n = g.onWsEvent("pty-output", (t) => {
			let n = t;
			n.sessionId !== e || !n.data || a((e) => nt(e + n.data));
		});
		return g.subscribePtyOutput(e), g.resizePty(e, r === "full" ? 120 : 96, 32), () => {
			t = !0, n(), g.unsubscribePtyOutput(e);
		};
	}, [e, r]), x(() => {
		let e = c.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [i]);
	let d = y((t) => {
		t && g.sendPtyInput(e, t);
	}, [e]), f = y(() => {
		let e = o;
		s(""), d(`${e}\n`);
	}, [o, d]), p = y((e) => {
		e.key === "Enter" && (e.preventDefault(), f());
	}, [f]), m = y(() => {
		g.stopCodingAgent(e);
	}, [e]);
	return /* @__PURE__ */ D("section", {
		className: tt(r),
		"aria-label": "Agent terminal",
		"data-testid": "pty-console-base",
		children: [
			/* @__PURE__ */ D("header", {
				className: "flex h-10 shrink-0 items-center gap-2 border-b border-border/60 px-3",
				children: [
					/* @__PURE__ */ E(Te, {
						className: "h-4 w-4 shrink-0 text-muted",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ D("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ E("div", {
							className: "truncate text-xs font-semibold text-txt",
							children: l?.label ?? "Terminal"
						}), /* @__PURE__ */ E("div", {
							className: "truncate text-[11px] text-muted",
							children: l?.workdir ?? e
						})]
					}),
					/* @__PURE__ */ E(u, {
						variant: "ghost",
						size: "icon",
						onClick: () => d(""),
						title: "Interrupt",
						"aria-label": "Interrupt terminal",
						children: /* @__PURE__ */ E(Ce, {
							className: "h-4 w-4",
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ E(u, {
						variant: "ghost",
						size: "icon",
						onClick: m,
						title: "Stop session",
						"aria-label": "Stop terminal session",
						children: /* @__PURE__ */ E(Ce, {
							className: "h-4 w-4 fill-current",
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ E(u, {
						variant: "ghost",
						size: "icon",
						onClick: n,
						title: "Close",
						"aria-label": "Close terminal",
						children: /* @__PURE__ */ E(je, {
							className: "h-4 w-4",
							"aria-hidden": !0
						})
					})
				]
			}),
			/* @__PURE__ */ E("div", {
				ref: c,
				className: "min-h-0 flex-1 overflow-auto bg-black p-3 font-mono text-[11px] leading-relaxed text-neutral-100",
				children: /* @__PURE__ */ E("pre", {
					className: "whitespace-pre-wrap break-words",
					children: i || "\x1B[2mConnecting to terminal...\x1B[0m"
				})
			}),
			/* @__PURE__ */ D("footer", {
				className: "flex h-11 shrink-0 items-center gap-2 border-t border-border/60 px-2",
				children: [/* @__PURE__ */ E("input", {
					value: o,
					onChange: (e) => s(e.currentTarget.value),
					onKeyDown: p,
					className: "min-w-0 flex-1 rounded-md border border-border/60 bg-bg px-2 py-1.5 font-mono text-xs text-txt outline-none focus:border-accent",
					"aria-label": "Terminal input",
					autoComplete: "off",
					spellCheck: !1
				}), /* @__PURE__ */ E(u, {
					variant: "ghost",
					size: "icon",
					onClick: f,
					title: "Send",
					"aria-label": "Send terminal input",
					children: /* @__PURE__ */ E(Se, {
						className: "h-4 w-4",
						"aria-hidden": !0
					})
				})]
			})
		]
	});
}
function tt(e) {
	let t = "flex min-h-0 min-w-0 flex-col overflow-hidden border border-border/70 bg-bg shadow-xl";
	return e === "full" ? `${t} h-full w-full rounded-none border-0 shadow-none` : e === "drawer" ? `${t} h-[min(70vh,40rem)] w-full rounded-t-lg` : `${t} h-[min(70vh,42rem)] w-[min(34rem,calc(100vw-1rem))] rounded-lg`;
}
function nt(e) {
	return e.length <= $e ? e : e.slice(e.length - $e);
}
//#endregion
//#region src/CockpitTerminalPanel.tsx
function rt({ activeSessionId: e, sessions: t, onClose: n }) {
	let [r, i] = w("pretty"), a = e ?? "", o = a.length > 0;
	return /* @__PURE__ */ D("div", {
		"data-testid": "cockpit-terminal-panel",
		className: "flex min-h-0 w-full flex-col overflow-hidden rounded-lg border border-border/70 bg-bg",
		children: [/* @__PURE__ */ D("header", {
			className: "flex h-10 shrink-0 items-center gap-2 border-b border-border/60 bg-black/20 px-3",
			children: [
				/* @__PURE__ */ E(Ee, {
					className: "h-4 w-4 shrink-0 text-accent",
					"aria-hidden": !0
				}),
				/* @__PURE__ */ E("span", {
					className: "min-w-0 flex-1 truncate text-xs font-semibold text-txt",
					children: "Terminal"
				}),
				/* @__PURE__ */ D("div", {
					role: "radiogroup",
					"aria-label": "Terminal view mode",
					className: "inline-flex items-center gap-0.5 rounded-md border border-border/60 bg-black/30 p-0.5",
					children: [/* @__PURE__ */ E(u, {
						type: "button",
						size: "sm",
						variant: r === "pretty" ? "default" : "ghost",
						role: "radio",
						"aria-checked": r === "pretty",
						"aria-pressed": r === "pretty",
						"data-testid": "cockpit-term-toggle-pretty",
						onClick: () => i("pretty"),
						children: "Pretty"
					}), /* @__PURE__ */ E(u, {
						type: "button",
						size: "sm",
						variant: r === "cli" ? "default" : "ghost",
						role: "radio",
						"aria-checked": r === "cli",
						"aria-pressed": r === "cli",
						"data-testid": "cockpit-term-toggle-cli",
						onClick: () => i("cli"),
						children: "CLI"
					})]
				})
			]
		}), /* @__PURE__ */ E("div", {
			className: "relative h-80 min-h-0 w-full bg-black/40",
			children: o ? r === "pretty" ? /* @__PURE__ */ E(et, {
				variant: "full",
				activeSessionId: a,
				sessions: t,
				onClose: n ?? it
			}) : /* @__PURE__ */ E("div", {
				"data-testid": "cockpit-term-cli",
				className: "h-full w-full",
				children: /* @__PURE__ */ E(Xe, {
					sessionId: a,
					visible: !0
				})
			}) : /* @__PURE__ */ D("div", {
				"data-testid": "cockpit-terminal-empty",
				className: "flex h-full w-full flex-col items-center justify-center gap-1 px-6 text-center",
				children: [
					/* @__PURE__ */ E(Ee, {
						className: "h-6 w-6 text-muted",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ E("p", {
						className: "text-sm font-medium text-txt",
						children: "No active session"
					}),
					/* @__PURE__ */ E("p", {
						className: "text-xs text-muted",
						children: "Start or select a coding session to attach a terminal."
					})
				]
			})
		})]
	});
}
function it() {}
//#endregion
//#region src/OrchestratorAccountHealthPanel.tsx
var at = (e, t) => typeof t?.defaultValue == "string" ? t.defaultValue : e;
function ot({ readiness: e, t }) {
	let n = e.ready;
	return /* @__PURE__ */ D("div", {
		className: `flex items-start gap-2 rounded-md px-3 py-2 text-2xs ${n ? "bg-ok/10 text-ok" : "bg-warn/10 text-warn"}`,
		"data-testid": "orchestrator-account-readiness",
		"data-ready": n ? "true" : "false",
		children: [E(n ? L : ne, { className: "mt-px h-3.5 w-3.5 shrink-0" }), /* @__PURE__ */ D("div", {
			className: "space-y-0.5",
			children: [/* @__PURE__ */ E("div", {
				className: "font-medium",
				children: n ? t("orchestrator.accountsReady", {
					defaultValue: `Pool ready — ${e.required}+ healthy per provider`,
					required: e.required
				}) : t("orchestrator.accountsNotReady", { defaultValue: "Account pool degraded" })
			}), !n && e.problems.map((e) => /* @__PURE__ */ E("div", {
				className: "text-warn/90",
				children: e
			}, e))]
		})]
	});
}
function st({ t: e = at, onConnect: t }) {
	let [n, r] = w(null), [i, a] = w(null), [o, s] = w(null), [c, l] = w(null), [u, d] = w(!0), f = y(async () => {
		let [e, t, n, i] = await Promise.allSettled([
			g.listAccounts(),
			g.getOrchestratorAccounts(),
			g.getOrchestratorRooms(),
			g.getOrchestratorAccountReadiness()
		]);
		e.status === "fulfilled" && r(e.value), t.status === "fulfilled" && a(t.value), n.status === "fulfilled" && s(n.value), i.status === "fulfilled" && l(i.value), d(!1);
	}, []);
	return x(() => {
		f();
		let e = window.setInterval(() => void f(), 15e3);
		return () => window.clearInterval(e);
	}, [f]), u ? null : /* @__PURE__ */ D("div", {
		className: "space-y-2",
		"data-testid": "orchestrator-account-health-panel",
		children: [c ? /* @__PURE__ */ E(ot, {
			readiness: c,
			t: e
		}) : null, /* @__PURE__ */ E(Ie, {
			accounts: n,
			overview: i,
			rooms: o,
			t: e,
			onConnect: t
		})]
	});
}
//#endregion
//#region src/orchestrator-params.ts
function q(e) {
	return typeof e == "string" && e.trim() ? e.trim() : void 0;
}
function ct(e) {
	return e === "low" || e === "normal" || e === "high" || e === "urgent" ? e : void 0;
}
function lt(e) {
	if (!Array.isArray(e)) return;
	let t = e.filter((e) => typeof e == "string" && e.trim() !== "");
	return t.length > 0 ? t.map((e) => e.trim()) : void 0;
}
function ut(e) {
	let t = q(e?.taskId);
	if (!t) throw Error("taskId is required for this capability.");
	return t;
}
//#endregion
//#region src/orchestrator-diff.helpers.ts
var dt = 800;
function ft(e, t) {
	let n = e.split("\n"), r = t.split("\n"), i = n.length, a = r.length;
	if (i + a > dt) {
		let e = [];
		for (let t = 0; t < i; t++) e.push({
			type: "remove",
			oldLine: t + 1,
			newLine: null,
			text: n[t]
		});
		for (let t = 0; t < a; t++) e.push({
			type: "add",
			oldLine: null,
			newLine: t + 1,
			text: r[t]
		});
		return e;
	}
	let o = Array.from({ length: i + 1 }, () => Array(a + 1).fill(0));
	for (let e = i - 1; e >= 0; e--) for (let t = a - 1; t >= 0; t--) o[e][t] = n[e] === r[t] ? o[e + 1][t + 1] + 1 : Math.max(o[e + 1][t], o[e][t + 1]);
	let s = [], c = 0, l = 0, u = 1, d = 1;
	for (; c < i && l < a;) n[c] === r[l] ? (s.push({
		type: "context",
		oldLine: u++,
		newLine: d++,
		text: n[c]
	}), c++, l++) : o[c + 1][l] >= o[c][l + 1] ? (s.push({
		type: "remove",
		oldLine: u++,
		newLine: null,
		text: n[c]
	}), c++) : (s.push({
		type: "add",
		oldLine: null,
		newLine: d++,
		text: r[l]
	}), l++);
	for (; c < i;) s.push({
		type: "remove",
		oldLine: u++,
		newLine: null,
		text: n[c++]
	});
	for (; l < a;) s.push({
		type: "add",
		oldLine: null,
		newLine: d++,
		text: r[l++]
	});
	return s;
}
function pt(e) {
	let t = 0, n = 0;
	for (let r of e) r.type === "add" ? t++ : r.type === "remove" && n++;
	return {
		added: t,
		removed: n
	};
}
//#endregion
//#region src/orchestrator-diff.tsx
function mt({ added: e, removed: t }) {
	return /* @__PURE__ */ D("span", {
		className: "inline-flex items-center gap-1 font-mono text-2xs tabular-nums",
		children: [/* @__PURE__ */ D("span", {
			className: "text-ok",
			children: ["+", e]
		}), /* @__PURE__ */ D("span", {
			className: "text-red-500",
			children: ["−", t]
		})]
	});
}
var ht = {
	context: "text-muted",
	add: "bg-ok/10 text-ok",
	remove: "bg-red-500/10 text-red-500"
}, gt = {
	context: "",
	add: "+",
	remove: "-"
}, _t = 6, vt = 3;
function yt(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		if (e[n].type !== "context") {
			t.push(e[n]), n++;
			continue;
		}
		let r = n;
		for (; r < e.length && e[r].type === "context";) r++;
		let i = e.slice(n, r), a = n === 0, o = r === e.length, s = a ? 0 : vt, c = o ? 0 : vt, l = i.length - s - c;
		if (i.length > _t && l > 0) {
			for (let e = 0; e < s; e++) t.push(i[e]);
			let e = s > 0 ? i[s - 1] : void 0, n = i[i.length - c] ?? i[i.length - 1];
			t.push({
				type: "fold",
				hidden: l,
				key: `fold:${e?.oldLine ?? "_"}:${n?.newLine ?? "_"}`
			});
			for (let e = i.length - c; e < i.length; e++) t.push(i[e]);
		} else for (let e of i) t.push(e);
		n = r;
	}
	return t;
}
function bt({ value: e }) {
	return /* @__PURE__ */ E("span", {
		className: "w-8 shrink-0 select-none px-1 text-right text-muted/40 tabular-nums",
		children: e ?? ""
	});
}
function xt({ hidden: e }) {
	return /* @__PURE__ */ D("div", {
		className: "flex items-center gap-2 border-border/30 border-y bg-bg-accent/40 px-2 py-0.5 text-muted/50 text-2xs",
		children: [/* @__PURE__ */ E("span", {
			className: "select-none",
			children: "&ctdot;"
		}), /* @__PURE__ */ D("span", {
			className: "select-none tabular-nums",
			children: [
				e,
				" unchanged ",
				e === 1 ? "line" : "lines"
			]
		})]
	});
}
function St({ oldText: e, newText: t }) {
	return /* @__PURE__ */ E("div", {
		className: "overflow-x-hidden overflow-y-auto rounded-sm border border-border/40 bg-bg-accent font-mono text-2xs leading-snug",
		style: { maxHeight: "18rem" },
		"data-testid": "orchestrator-diff",
		children: yt(e === void 0 ? t.split("\n").map((e, t) => ({
			type: "add",
			oldLine: null,
			newLine: t + 1,
			text: e
		})) : ft(e, t)).map((e) => e.type === "fold" ? /* @__PURE__ */ E(xt, { hidden: e.hidden }, e.key) : /* @__PURE__ */ D("div", {
			className: `flex ${ht[e.type]}`,
			children: [
				/* @__PURE__ */ E(bt, { value: e.oldLine }),
				/* @__PURE__ */ E(bt, { value: e.newLine }),
				/* @__PURE__ */ E("span", {
					className: "w-3 shrink-0 select-none text-center opacity-70",
					children: gt[e.type]
				}),
				/* @__PURE__ */ E("span", {
					className: "min-w-0 flex-1 whitespace-pre-wrap break-all pr-2",
					children: e.text
				})
			]
		}, `${e.oldLine ?? "_"}:${e.newLine ?? "_"}:${e.type}`))
	});
}
//#endregion
//#region ../../node_modules/.bun/marked@18.0.5/node_modules/marked/lib/marked.esm.js
function Ct() {
	return {
		async: !1,
		breaks: !1,
		extensions: null,
		gfm: !0,
		hooks: null,
		pedantic: !1,
		renderer: null,
		silent: !1,
		tokenizer: null,
		walkTokens: null
	};
}
var wt = Ct();
function Tt(e) {
	wt = e;
}
var Et = { exec: () => null };
function Dt(e) {
	let t = [];
	return (n) => {
		let r = Math.max(0, Math.min(3, n - 1)), i = t[r];
		return i || (i = e(r), t[r] = i), i;
	};
}
function J(e, t = "") {
	let n = typeof e == "string" ? e : e.source, r = {
		replace: (e, t) => {
			let i = typeof t == "string" ? t : t.source;
			return i = i.replace(Y.caret, "$1"), n = n.replace(e, i), r;
		},
		getRegex: () => new RegExp(n, t)
	};
	return r;
}
var Ot = ((e = "") => {
	try {
		return !!RegExp("(?<=1)(?<!1)" + e);
	} catch {
		return !1;
	}
})(), Y = {
	codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
	outputLinkReplace: /\\([\[\]])/g,
	indentCodeCompensation: /^(\s+)(?:```)/,
	beginningSpace: /^\s+/,
	endingHash: /#$/,
	startingSpaceChar: /^ /,
	endingSpaceChar: / $/,
	nonSpaceChar: /[^ ]/,
	newLineCharGlobal: /\n/g,
	tabCharGlobal: /\t/g,
	multipleSpaceGlobal: /\s+/g,
	blankLine: /^[ \t]*$/,
	doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
	blockquoteStart: /^ {0,3}>/,
	blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
	blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
	listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
	listIsTask: /^\[[ xX]\] +\S/,
	listReplaceTask: /^\[[ xX]\] +/,
	listTaskCheckbox: /\[[ xX]\]/,
	anyLine: /\n.*\n/,
	hrefBrackets: /^<(.*)>$/,
	tableDelimiter: /[:|]/,
	tableAlignChars: /^\||\| *$/g,
	tableRowBlankLine: /\n[ \t]*$/,
	tableAlignRight: /^ *-+: *$/,
	tableAlignCenter: /^ *:-+: *$/,
	tableAlignLeft: /^ *:-+ *$/,
	startATag: /^<a /i,
	endATag: /^<\/a>/i,
	startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
	endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
	startAngleBracket: /^</,
	endAngleBracket: />$/,
	pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
	unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
	escapeTest: /[&<>"']/,
	escapeReplace: /[&<>"']/g,
	escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
	escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
	caret: /(^|[^\[])\^/g,
	percentDecode: /%25/g,
	findPipe: /\|/g,
	splitPipe: / \|/,
	slashPipe: /\\\|/g,
	carriageReturn: /\r\n|\r/g,
	spaceLine: /^ +$/gm,
	notSpaceStart: /^\S*/,
	endingNewline: /\n$/,
	listItemRegex: (e) => RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),
	nextBulletRegex: Dt((e) => RegExp(`^ {0,${e}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)),
	hrRegex: Dt((e) => RegExp(`^ {0,${e}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`)),
	fencesBeginRegex: Dt((e) => RegExp(`^ {0,${e}}(?:\`\`\`|~~~)`)),
	headingBeginRegex: Dt((e) => RegExp(`^ {0,${e}}#`)),
	htmlBeginRegex: Dt((e) => RegExp(`^ {0,${e}}<(?:[a-z].*>|!--)`, "i")),
	blockquoteBeginRegex: Dt((e) => RegExp(`^ {0,${e}}>`))
}, kt = /^(?:[ \t]*(?:\n|$))+/, At = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, jt = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Mt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Nt = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Pt = / {0,3}(?:[*+-]|\d{1,9}[.)])/, Ft = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, It = J(Ft).replace(/bull/g, Pt).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Lt = J(Ft).replace(/bull/g, Pt).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), Rt = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, zt = /^[^\n]+/, Bt = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, Vt = J(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", Bt).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ht = J(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g, Pt).getRegex(), Ut = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Wt = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Gt = J("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", Wt).replace("tag", Ut).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Kt = J(Rt).replace("hr", Mt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex(), qt = {
	blockquote: J(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Kt).getRegex(),
	code: At,
	def: Vt,
	fences: jt,
	heading: Nt,
	hr: Mt,
	html: Gt,
	lheading: It,
	list: Ht,
	newline: kt,
	paragraph: Kt,
	table: Et,
	text: zt
}, Jt = J("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Mt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex(), Yt = {
	...qt,
	lheading: Lt,
	table: Jt,
	paragraph: J(Rt).replace("hr", Mt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Jt).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Ut).getRegex()
}, Xt = {
	...qt,
	html: J("^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))").replace("comment", Wt).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
	def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
	heading: /^(#{1,6})(.*)(?:\n+|$)/,
	fences: Et,
	lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
	paragraph: J(Rt).replace("hr", Mt).replace("heading", " *#{1,6} *[^\n]").replace("lheading", It).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Zt = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Qt = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, $t = /^( {2,}|\\)\n(?!\s*$)/, en = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, tn = /[\p{P}\p{S}]/u, nn = /[\s\p{P}\p{S}]/u, rn = /[^\s\p{P}\p{S}]/u, an = J(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, nn).getRegex(), on = /(?!~)[\p{P}\p{S}]/u, sn = /(?!~)[\s\p{P}\p{S}]/u, cn = /(?:[^\s\p{P}\p{S}]|~)/u, ln = J(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", Ot ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), un = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/, dn = J(un, "u").replace(/punct/g, tn).getRegex(), fn = J(un, "u").replace(/punct/g, on).getRegex(), pn = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", mn = J(pn, "gu").replace(/notPunctSpace/g, rn).replace(/punctSpace/g, nn).replace(/punct/g, tn).getRegex(), hn = J(pn, "gu").replace(/notPunctSpace/g, cn).replace(/punctSpace/g, sn).replace(/punct/g, on).getRegex(), gn = J("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, rn).replace(/punctSpace/g, nn).replace(/punct/g, tn).getRegex(), _n = J(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, tn).getRegex(), vn = J("^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)", "gu").replace(/notPunctSpace/g, rn).replace(/punctSpace/g, nn).replace(/punct/g, tn).getRegex(), yn = J(/\\(punct)/, "gu").replace(/punct/g, tn).getRegex(), bn = J(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), xn = J(Wt).replace("(?:-->|$)", "-->").getRegex(), Sn = J("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", xn).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Cn = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/, wn = J(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", Cn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Tn = J(/^!?\[(label)\]\[(ref)\]/).replace("label", Cn).replace("ref", Bt).getRegex(), En = J(/^!?\[(ref)\](?:\[\])?/).replace("ref", Bt).getRegex(), Dn = J("reflink|nolink(?!\\()", "g").replace("reflink", Tn).replace("nolink", En).getRegex(), On = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, kn = {
	_backpedal: Et,
	anyPunctuation: yn,
	autolink: bn,
	blockSkip: ln,
	br: $t,
	code: Qt,
	del: Et,
	delLDelim: Et,
	delRDelim: Et,
	emStrongLDelim: dn,
	emStrongRDelimAst: mn,
	emStrongRDelimUnd: gn,
	escape: Zt,
	link: wn,
	nolink: En,
	punctuation: an,
	reflink: Tn,
	reflinkSearch: Dn,
	tag: Sn,
	text: en,
	url: Et
}, An = {
	...kn,
	link: J(/^!?\[(label)\]\((.*?)\)/).replace("label", Cn).getRegex(),
	reflink: J(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Cn).getRegex()
}, jn = {
	...kn,
	emStrongRDelimAst: hn,
	emStrongLDelim: fn,
	delLDelim: _n,
	delRDelim: vn,
	url: J(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", On).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
	_backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
	del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,
	text: J(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", On).getRegex()
}, Mn = {
	...jn,
	br: J($t).replace("{2,}", "*").getRegex(),
	text: J(jn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Nn = {
	normal: qt,
	gfm: Yt,
	pedantic: Xt
}, Pn = {
	normal: kn,
	gfm: jn,
	breaks: Mn,
	pedantic: An
}, Fn = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
}, In = (e) => Fn[e];
function Ln(e, t) {
	if (t) {
		if (Y.escapeTest.test(e)) return e.replace(Y.escapeReplace, In);
	} else if (Y.escapeTestNoEncode.test(e)) return e.replace(Y.escapeReplaceNoEncode, In);
	return e;
}
function Rn(e) {
	try {
		e = encodeURI(e).replace(Y.percentDecode, "%");
	} catch {
		return null;
	}
	return e;
}
function zn(e, t) {
	let n = e.replace(Y.findPipe, (e, t, n) => {
		let r = !1, i = t;
		for (; --i >= 0 && n[i] === "\\";) r = !r;
		return r ? "|" : " |";
	}).split(Y.splitPipe), r = 0;
	if (n[0].trim() || n.shift(), n.length > 0 && !n.at(-1)?.trim() && n.pop(), t) if (n.length > t) n.splice(t);
	else for (; n.length < t;) n.push("");
	for (; r < n.length; r++) n[r] = n[r].trim().replace(Y.slashPipe, "|");
	return n;
}
function Bn(e, t, n) {
	let r = e.length;
	if (r === 0) return "";
	let i = 0;
	for (; i < r;) {
		let a = e.charAt(r - i - 1);
		if (a === t && !n) i++;
		else if (a !== t && n) i++;
		else break;
	}
	return e.slice(0, r - i);
}
function Vn(e) {
	let t = e.split("\n"), n = t.length - 1;
	for (; n >= 0 && Y.blankLine.test(t[n]);) n--;
	return t.length - n <= 2 ? e : t.slice(0, n + 1).join("\n");
}
function Hn(e, t) {
	if (e.indexOf(t[1]) === -1) return -1;
	let n = 0;
	for (let r = 0; r < e.length; r++) if (e[r] === "\\") r++;
	else if (e[r] === t[0]) n++;
	else if (e[r] === t[1] && (n--, n < 0)) return r;
	return n > 0 ? -2 : -1;
}
function Un(e, t = 0) {
	let n = t, r = "";
	for (let t of e) if (t === "	") {
		let e = 4 - n % 4;
		r += " ".repeat(e), n += e;
	} else r += t, n++;
	return r;
}
function Wn(e, t, n, r, i) {
	let a = t.href, o = t.title || null, s = e[1].replace(i.other.outputLinkReplace, "$1");
	r.state.inLink = !0;
	let c = {
		type: e[0].charAt(0) === "!" ? "image" : "link",
		raw: n,
		href: a,
		title: o,
		text: s,
		tokens: r.inlineTokens(s)
	};
	return r.state.inLink = !1, c;
}
function Gn(e, t, n) {
	let r = e.match(n.other.indentCodeCompensation);
	if (r === null) return t;
	let i = r[1];
	return t.split("\n").map((e) => {
		let t = e.match(n.other.beginningSpace);
		if (t === null) return e;
		let [r] = t;
		return r.length >= i.length ? e.slice(i.length) : e;
	}).join("\n");
}
var Kn = class {
	options;
	rules;
	lexer;
	constructor(e) {
		this.options = e || wt;
	}
	space(e) {
		let t = this.rules.block.newline.exec(e);
		if (t && t[0].length > 0) return {
			type: "space",
			raw: t[0]
		};
	}
	code(e) {
		let t = this.rules.block.code.exec(e);
		if (t) {
			let e = this.options.pedantic ? t[0] : Vn(t[0]);
			return {
				type: "code",
				raw: e,
				codeBlockStyle: "indented",
				text: e.replace(this.rules.other.codeRemoveIndent, "")
			};
		}
	}
	fences(e) {
		let t = this.rules.block.fences.exec(e);
		if (t) {
			let e = t[0], n = Gn(e, t[3] || "", this.rules);
			return {
				type: "code",
				raw: e,
				lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
				text: n
			};
		}
	}
	heading(e) {
		let t = this.rules.block.heading.exec(e);
		if (t) {
			let e = t[2].trim();
			if (this.rules.other.endingHash.test(e)) {
				let t = Bn(e, "#");
				(this.options.pedantic || !t || this.rules.other.endingSpaceChar.test(t)) && (e = t.trim());
			}
			return {
				type: "heading",
				raw: Bn(t[0], "\n"),
				depth: t[1].length,
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	hr(e) {
		let t = this.rules.block.hr.exec(e);
		if (t) return {
			type: "hr",
			raw: Bn(t[0], "\n")
		};
	}
	blockquote(e) {
		let t = this.rules.block.blockquote.exec(e);
		if (t) {
			let e = Bn(t[0], "\n").split("\n"), n = "", r = "", i = [];
			for (; e.length > 0;) {
				let t = !1, a = [], o;
				for (o = 0; o < e.length; o++) if (this.rules.other.blockquoteStart.test(e[o])) a.push(e[o]), t = !0;
				else if (!t) a.push(e[o]);
				else break;
				e = e.slice(o);
				let s = a.join("\n"), c = s.replace(this.rules.other.blockquoteSetextReplace, "\n    $1").replace(this.rules.other.blockquoteSetextReplace2, "");
				n = n ? `${n}
${s}` : s, r = r ? `${r}
${c}` : c;
				let l = this.lexer.state.top;
				if (this.lexer.state.top = !0, this.lexer.blockTokens(c, i, !0), this.lexer.state.top = l, e.length === 0) break;
				let u = i.at(-1);
				if (u?.type === "code") break;
				if (u?.type === "blockquote") {
					let t = u, a = t.raw + "\n" + e.join("\n"), o = this.blockquote(a);
					i[i.length - 1] = o, n = n.substring(0, n.length - t.raw.length) + o.raw, r = r.substring(0, r.length - t.text.length) + o.text;
					break;
				} else if (u?.type === "list") {
					let t = u, a = t.raw + "\n" + e.join("\n"), o = this.list(a);
					i[i.length - 1] = o, n = n.substring(0, n.length - u.raw.length) + o.raw, r = r.substring(0, r.length - t.raw.length) + o.raw, e = a.substring(i.at(-1).raw.length).split("\n");
					continue;
				}
			}
			return {
				type: "blockquote",
				raw: n,
				tokens: i,
				text: r
			};
		}
	}
	list(e) {
		let t = this.rules.block.list.exec(e);
		if (t) {
			let n = t[1].trim(), r = n.length > 1, i = {
				type: "list",
				raw: "",
				ordered: r,
				start: r ? +n.slice(0, -1) : "",
				loose: !1,
				items: []
			};
			n = r ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = r ? n : "[*+-]");
			let a = this.rules.other.listItemRegex(n), o = !1;
			for (; e;) {
				let n = !1, r = "", s = "";
				if (!(t = a.exec(e)) || this.rules.block.hr.test(e)) break;
				r = t[0], e = e.substring(r.length);
				let c = Un(t[2].split("\n", 1)[0], t[1].length), l = e.split("\n", 1)[0], u = !c.trim(), d = 0;
				if (this.options.pedantic ? (d = 2, s = c.trimStart()) : u ? d = t[1].length + 1 : (d = c.search(this.rules.other.nonSpaceChar), d = d > 4 ? 1 : d, s = c.slice(d), d += t[1].length), u && this.rules.other.blankLine.test(l) && (r += l + "\n", e = e.substring(l.length + 1), n = !0), !n) {
					let t = this.rules.other.nextBulletRegex(d), n = this.rules.other.hrRegex(d), i = this.rules.other.fencesBeginRegex(d), a = this.rules.other.headingBeginRegex(d), o = this.rules.other.htmlBeginRegex(d), f = this.rules.other.blockquoteBeginRegex(d);
					for (; e;) {
						let p = e.split("\n", 1)[0], m;
						if (l = p, this.options.pedantic ? (l = l.replace(this.rules.other.listReplaceNesting, "  "), m = l) : m = l.replace(this.rules.other.tabCharGlobal, "    "), i.test(l) || a.test(l) || o.test(l) || f.test(l) || t.test(l) || n.test(l)) break;
						if (m.search(this.rules.other.nonSpaceChar) >= d || !l.trim()) s += "\n" + m.slice(d);
						else {
							if (u || c.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || i.test(c) || a.test(c) || n.test(c)) break;
							s += "\n" + l;
						}
						u = !l.trim(), r += p + "\n", e = e.substring(p.length + 1), c = m.slice(d);
					}
				}
				i.loose || (o ? i.loose = !0 : this.rules.other.doubleBlankLine.test(r) && (o = !0)), i.items.push({
					type: "list_item",
					raw: r,
					task: !!this.options.gfm && this.rules.other.listIsTask.test(s),
					loose: !1,
					text: s,
					tokens: []
				}), i.raw += r;
			}
			let s = i.items.at(-1);
			if (s) s.raw = s.raw.trimEnd(), s.text = s.text.trimEnd();
			else return;
			i.raw = i.raw.trimEnd();
			for (let e of i.items) {
				this.lexer.state.top = !1, e.tokens = this.lexer.blockTokens(e.text, []);
				let t = e.tokens[0];
				if (e.task && (t?.type === "text" || t?.type === "paragraph")) {
					e.text = e.text.replace(this.rules.other.listReplaceTask, ""), t.raw = t.raw.replace(this.rules.other.listReplaceTask, ""), t.text = t.text.replace(this.rules.other.listReplaceTask, "");
					for (let e = this.lexer.inlineQueue.length - 1; e >= 0; e--) if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[e].src)) {
						this.lexer.inlineQueue[e].src = this.lexer.inlineQueue[e].src.replace(this.rules.other.listReplaceTask, "");
						break;
					}
					let n = this.rules.other.listTaskCheckbox.exec(e.raw);
					if (n) {
						let t = {
							type: "checkbox",
							raw: n[0] + " ",
							checked: n[0] !== "[ ]"
						};
						e.checked = t.checked, i.loose ? e.tokens[0] && ["paragraph", "text"].includes(e.tokens[0].type) && "tokens" in e.tokens[0] && e.tokens[0].tokens ? (e.tokens[0].raw = t.raw + e.tokens[0].raw, e.tokens[0].text = t.raw + e.tokens[0].text, e.tokens[0].tokens.unshift(t)) : e.tokens.unshift({
							type: "paragraph",
							raw: t.raw,
							text: t.raw,
							tokens: [t]
						}) : e.tokens.unshift(t);
					}
				} else e.task &&= !1;
				if (!i.loose) {
					let t = e.tokens.filter((e) => e.type === "space");
					i.loose = t.length > 0 && t.some((e) => this.rules.other.anyLine.test(e.raw));
				}
			}
			if (i.loose) for (let e of i.items) {
				e.loose = !0;
				for (let t of e.tokens) t.type === "text" && (t.type = "paragraph");
			}
			return i;
		}
	}
	html(e) {
		let t = this.rules.block.html.exec(e);
		if (t) {
			let e = Vn(t[0]);
			return {
				type: "html",
				block: !0,
				raw: e,
				pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
				text: e
			};
		}
	}
	def(e) {
		let t = this.rules.block.def.exec(e);
		if (t) {
			let e = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
			return {
				type: "def",
				tag: e,
				raw: Bn(t[0], "\n"),
				href: n,
				title: r
			};
		}
	}
	table(e) {
		let t = this.rules.block.table.exec(e);
		if (!t || !this.rules.other.tableDelimiter.test(t[2])) return;
		let n = zn(t[1]), r = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), i = t[3]?.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split("\n") : [], a = {
			type: "table",
			raw: Bn(t[0], "\n"),
			header: [],
			align: [],
			rows: []
		};
		if (n.length === r.length) {
			for (let e of r) this.rules.other.tableAlignRight.test(e) ? a.align.push("right") : this.rules.other.tableAlignCenter.test(e) ? a.align.push("center") : this.rules.other.tableAlignLeft.test(e) ? a.align.push("left") : a.align.push(null);
			for (let e = 0; e < n.length; e++) a.header.push({
				text: n[e],
				tokens: this.lexer.inline(n[e]),
				header: !0,
				align: a.align[e]
			});
			for (let e of i) a.rows.push(zn(e, a.header.length).map((e, t) => ({
				text: e,
				tokens: this.lexer.inline(e),
				header: !1,
				align: a.align[t]
			})));
			return a;
		}
	}
	lheading(e) {
		let t = this.rules.block.lheading.exec(e);
		if (t) {
			let e = t[1].trim();
			return {
				type: "heading",
				raw: Bn(t[0], "\n"),
				depth: t[2].charAt(0) === "=" ? 1 : 2,
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	paragraph(e) {
		let t = this.rules.block.paragraph.exec(e);
		if (t) {
			let e = t[1].charAt(t[1].length - 1) === "\n" ? t[1].slice(0, -1) : t[1];
			return {
				type: "paragraph",
				raw: t[0],
				text: e,
				tokens: this.lexer.inline(e)
			};
		}
	}
	text(e) {
		let t = this.rules.block.text.exec(e);
		if (t) return {
			type: "text",
			raw: t[0],
			text: t[0],
			tokens: this.lexer.inline(t[0])
		};
	}
	escape(e) {
		let t = this.rules.inline.escape.exec(e);
		if (t) return {
			type: "escape",
			raw: t[0],
			text: t[1]
		};
	}
	tag(e) {
		let t = this.rules.inline.tag.exec(e);
		if (t) return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
			type: "html",
			raw: t[0],
			inLink: this.lexer.state.inLink,
			inRawBlock: this.lexer.state.inRawBlock,
			block: !1,
			text: t[0]
		};
	}
	link(e) {
		let t = this.rules.inline.link.exec(e);
		if (t) {
			let e = t[2].trim();
			if (!this.options.pedantic && this.rules.other.startAngleBracket.test(e)) {
				if (!this.rules.other.endAngleBracket.test(e)) return;
				let t = Bn(e.slice(0, -1), "\\");
				if ((e.length - t.length) % 2 == 0) return;
			} else {
				let e = Hn(t[2], "()");
				if (e === -2) return;
				if (e > -1) {
					let n = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + e;
					t[2] = t[2].substring(0, e), t[0] = t[0].substring(0, n).trim(), t[3] = "";
				}
			}
			let n = t[2], r = "";
			if (this.options.pedantic) {
				let e = this.rules.other.pedanticHrefTitle.exec(n);
				e && (n = e[1], r = e[3]);
			} else r = t[3] ? t[3].slice(1, -1) : "";
			return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (n = this.options.pedantic && !this.rules.other.endAngleBracket.test(e) ? n.slice(1) : n.slice(1, -1)), Wn(t, {
				href: n && n.replace(this.rules.inline.anyPunctuation, "$1"),
				title: r && r.replace(this.rules.inline.anyPunctuation, "$1")
			}, t[0], this.lexer, this.rules);
		}
	}
	reflink(e, t) {
		let n;
		if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
			let e = t[(n[2] || n[1]).replace(this.rules.other.multipleSpaceGlobal, " ").toLowerCase()];
			if (!e) {
				let e = n[0].charAt(0);
				return {
					type: "text",
					raw: e,
					text: e
				};
			}
			return Wn(n, e, n[0], this.lexer, this.rules);
		}
	}
	emStrong(e, t, n = "") {
		let r = this.rules.inline.emStrongLDelim.exec(e);
		if (!(!r || !r[1] && !r[2] && !r[3] && !r[4] || r[4] && n.match(this.rules.other.unicodeAlphaNumeric)) && (!(r[1] || r[3]) || !n || this.rules.inline.punctuation.exec(n))) {
			let n = [...r[0]].length - 1, i, a, o = n, s = 0, c = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
			for (c.lastIndex = 0, t = t.slice(-1 * e.length + n); (r = c.exec(t)) !== null;) {
				if (i = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !i) continue;
				if (a = [...i].length, r[3] || r[4]) {
					o += a;
					continue;
				} else if ((r[5] || r[6]) && n % 3 && !((n + a) % 3)) {
					s += a;
					continue;
				}
				if (o -= a, o > 0) continue;
				a = Math.min(a, a + o + s);
				let t = [...r[0]][0].length, c = e.slice(0, n + r.index + t + a);
				if (Math.min(n, a) % 2) {
					let e = c.slice(1, -1);
					return {
						type: "em",
						raw: c,
						text: e,
						tokens: this.lexer.inlineTokens(e)
					};
				}
				let l = c.slice(2, -2);
				return {
					type: "strong",
					raw: c,
					text: l,
					tokens: this.lexer.inlineTokens(l)
				};
			}
		}
	}
	codespan(e) {
		let t = this.rules.inline.code.exec(e);
		if (t) {
			let e = t[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(e), r = this.rules.other.startingSpaceChar.test(e) && this.rules.other.endingSpaceChar.test(e);
			return n && r && (e = e.substring(1, e.length - 1)), {
				type: "codespan",
				raw: t[0],
				text: e
			};
		}
	}
	br(e) {
		let t = this.rules.inline.br.exec(e);
		if (t) return {
			type: "br",
			raw: t[0]
		};
	}
	del(e, t, n = "") {
		let r = this.rules.inline.delLDelim.exec(e);
		if (r && (!r[1] || !n || this.rules.inline.punctuation.exec(n))) {
			let n = [...r[0]].length - 1, i, a, o = n, s = this.rules.inline.delRDelim;
			for (s.lastIndex = 0, t = t.slice(-1 * e.length + n); (r = s.exec(t)) !== null;) {
				if (i = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !i || (a = [...i].length, a !== n)) continue;
				if (r[3] || r[4]) {
					o += a;
					continue;
				}
				if (o -= a, o > 0) continue;
				a = Math.min(a, a + o);
				let t = [...r[0]][0].length, s = e.slice(0, n + r.index + t + a), c = s.slice(n, -n);
				return {
					type: "del",
					raw: s,
					text: c,
					tokens: this.lexer.inlineTokens(c)
				};
			}
		}
	}
	autolink(e) {
		let t = this.rules.inline.autolink.exec(e);
		if (t) {
			let e, n;
			return t[2] === "@" ? (e = t[1], n = "mailto:" + e) : (e = t[1], n = e), {
				type: "link",
				raw: t[0],
				text: e,
				href: n,
				tokens: [{
					type: "text",
					raw: e,
					text: e
				}]
			};
		}
	}
	url(e) {
		let t;
		if (t = this.rules.inline.url.exec(e)) {
			let e, n;
			if (t[2] === "@") e = t[0], n = "mailto:" + e;
			else {
				let r;
				do
					r = t[0], t[0] = this.rules.inline._backpedal.exec(t[0])?.[0] ?? "";
				while (r !== t[0]);
				e = t[0], n = t[1] === "www." ? "http://" + t[0] : t[0];
			}
			return {
				type: "link",
				raw: t[0],
				text: e,
				href: n,
				tokens: [{
					type: "text",
					raw: e,
					text: e
				}]
			};
		}
	}
	inlineText(e) {
		let t = this.rules.inline.text.exec(e);
		if (t) {
			let e = this.lexer.state.inRawBlock;
			return {
				type: "text",
				raw: t[0],
				text: t[0],
				escaped: e
			};
		}
	}
}, qn = class e {
	tokens;
	options;
	state;
	inlineQueue;
	tokenizer;
	constructor(e) {
		this.tokens = [], this.tokens.links = Object.create(null), this.options = e || wt, this.options.tokenizer = this.options.tokenizer || new Kn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
			inLink: !1,
			inRawBlock: !1,
			top: !0
		};
		let t = {
			other: Y,
			block: Nn.normal,
			inline: Pn.normal
		};
		this.options.pedantic ? (t.block = Nn.pedantic, t.inline = Pn.pedantic) : this.options.gfm && (t.block = Nn.gfm, this.options.breaks ? t.inline = Pn.breaks : t.inline = Pn.gfm), this.tokenizer.rules = t;
	}
	static get rules() {
		return {
			block: Nn,
			inline: Pn
		};
	}
	static lex(t, n) {
		return new e(n).lex(t);
	}
	static lexInline(t, n) {
		return new e(n).inlineTokens(t);
	}
	lex(e) {
		e = e.replace(Y.carriageReturn, "\n"), this.blockTokens(e, this.tokens);
		for (let e = 0; e < this.inlineQueue.length; e++) {
			let t = this.inlineQueue[e];
			this.inlineTokens(t.src, t.tokens);
		}
		return this.inlineQueue = [], this.tokens;
	}
	blockTokens(e, t = [], n = !1) {
		this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(Y.tabCharGlobal, "    ").replace(Y.spaceLine, ""));
		let r = Infinity;
		for (; e;) {
			if (e.length < r) r = e.length;
			else {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
			let i;
			if (this.options.extensions?.block?.some((n) => (i = n.call({ lexer: this }, e, t)) ? (e = e.substring(i.raw.length), t.push(i), !0) : !1)) continue;
			if (i = this.tokenizer.space(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				i.raw.length === 1 && n !== void 0 ? n.raw += "\n" : t.push(i);
				continue;
			}
			if (i = this.tokenizer.code(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "paragraph" || n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.text, this.inlineQueue.at(-1).src = n.text) : t.push(i);
				continue;
			}
			if (i = this.tokenizer.fences(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.heading(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.hr(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.blockquote(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.list(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.html(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.def(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "paragraph" || n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.raw, this.inlineQueue.at(-1).src = n.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
					href: i.href,
					title: i.title
				}, t.push(i));
				continue;
			}
			if (i = this.tokenizer.table(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			if (i = this.tokenizer.lheading(e)) {
				e = e.substring(i.raw.length), t.push(i);
				continue;
			}
			let a = e;
			if (this.options.extensions?.startBlock) {
				let t = Infinity, n = e.slice(1), r;
				this.options.extensions.startBlock.forEach((e) => {
					r = e.call({ lexer: this }, n), typeof r == "number" && r >= 0 && (t = Math.min(t, r));
				}), t < Infinity && t >= 0 && (a = e.substring(0, t + 1));
			}
			if (this.state.top && (i = this.tokenizer.paragraph(a))) {
				let r = t.at(-1);
				n && r?.type === "paragraph" ? (r.raw += (r.raw.endsWith("\n") ? "" : "\n") + i.raw, r.text += "\n" + i.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = r.text) : t.push(i), n = a.length !== e.length, e = e.substring(i.raw.length);
				continue;
			}
			if (i = this.tokenizer.text(e)) {
				e = e.substring(i.raw.length);
				let n = t.at(-1);
				n?.type === "text" ? (n.raw += (n.raw.endsWith("\n") ? "" : "\n") + i.raw, n.text += "\n" + i.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = n.text) : t.push(i);
				continue;
			}
			if (e) {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
		}
		return this.state.top = !0, t;
	}
	inline(e, t = []) {
		return this.inlineQueue.push({
			src: e,
			tokens: t
		}), t;
	}
	inlineTokens(e, t = []) {
		this.tokenizer.lexer = this;
		let n = e, r = null;
		if (this.tokens.links) {
			let e = Object.keys(this.tokens.links);
			if (e.length > 0) for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(n)) !== null;) e.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (n = n.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + n.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
		}
		for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(n)) !== null;) n = n.slice(0, r.index) + "++" + n.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
		let i;
		for (; (r = this.tokenizer.rules.inline.blockSkip.exec(n)) !== null;) i = r[2] ? r[2].length : 0, n = n.slice(0, r.index + i) + "[" + "a".repeat(r[0].length - i - 2) + "]" + n.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
		n = this.options.hooks?.emStrongMask?.call({ lexer: this }, n) ?? n;
		let a = !1, o = "", s = Infinity;
		for (; e;) {
			if (e.length < s) s = e.length;
			else {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
			a || (o = ""), a = !1;
			let r;
			if (this.options.extensions?.inline?.some((n) => (r = n.call({ lexer: this }, e, t)) ? (e = e.substring(r.raw.length), t.push(r), !0) : !1)) continue;
			if (r = this.tokenizer.escape(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.tag(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.link(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.reflink(e, this.tokens.links)) {
				e = e.substring(r.raw.length);
				let n = t.at(-1);
				r.type === "text" && n?.type === "text" ? (n.raw += r.raw, n.text += r.text) : t.push(r);
				continue;
			}
			if (r = this.tokenizer.emStrong(e, n, o)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.codespan(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.br(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.del(e, n, o)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (r = this.tokenizer.autolink(e)) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			if (!this.state.inLink && (r = this.tokenizer.url(e))) {
				e = e.substring(r.raw.length), t.push(r);
				continue;
			}
			let i = e;
			if (this.options.extensions?.startInline) {
				let t = Infinity, n = e.slice(1), r;
				this.options.extensions.startInline.forEach((e) => {
					r = e.call({ lexer: this }, n), typeof r == "number" && r >= 0 && (t = Math.min(t, r));
				}), t < Infinity && t >= 0 && (i = e.substring(0, t + 1));
			}
			if (r = this.tokenizer.inlineText(i)) {
				e = e.substring(r.raw.length), r.raw.slice(-1) !== "_" && (o = r.raw.slice(-1)), a = !0;
				let n = t.at(-1);
				n?.type === "text" ? (n.raw += r.raw, n.text += r.text) : t.push(r);
				continue;
			}
			if (e) {
				this.infiniteLoopError(e.charCodeAt(0));
				break;
			}
		}
		return t;
	}
	infiniteLoopError(e) {
		let t = "Infinite loop on byte: " + e;
		if (this.options.silent) console.error(t);
		else throw Error(t);
	}
}, Jn = class {
	options;
	parser;
	constructor(e) {
		this.options = e || wt;
	}
	space(e) {
		return "";
	}
	code({ text: e, lang: t, escaped: n }) {
		let r = (t || "").match(Y.notSpaceStart)?.[0], i = e.replace(Y.endingNewline, "") + "\n";
		return r ? "<pre><code class=\"language-" + Ln(r) + "\">" + (n ? i : Ln(i, !0)) + "</code></pre>\n" : "<pre><code>" + (n ? i : Ln(i, !0)) + "</code></pre>\n";
	}
	blockquote({ tokens: e }) {
		return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
	}
	html({ text: e }) {
		return e;
	}
	def(e) {
		return "";
	}
	heading({ tokens: e, depth: t }) {
		return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
	}
	hr(e) {
		return "<hr>\n";
	}
	list(e) {
		let t = e.ordered, n = e.start, r = "";
		for (let t = 0; t < e.items.length; t++) {
			let n = e.items[t];
			r += this.listitem(n);
		}
		let i = t ? "ol" : "ul", a = t && n !== 1 ? " start=\"" + n + "\"" : "";
		return "<" + i + a + ">\n" + r + "</" + i + ">\n";
	}
	listitem(e) {
		return `<li>${this.parser.parse(e.tokens)}</li>
`;
	}
	checkbox({ checked: e }) {
		return "<input " + (e ? "checked=\"\" " : "") + "disabled=\"\" type=\"checkbox\"> ";
	}
	paragraph({ tokens: e }) {
		return `<p>${this.parser.parseInline(e)}</p>
`;
	}
	table(e) {
		let t = "", n = "";
		for (let t = 0; t < e.header.length; t++) n += this.tablecell(e.header[t]);
		t += this.tablerow({ text: n });
		let r = "";
		for (let t = 0; t < e.rows.length; t++) {
			let i = e.rows[t];
			n = "";
			for (let e = 0; e < i.length; e++) n += this.tablecell(i[e]);
			r += this.tablerow({ text: n });
		}
		return r &&= `<tbody>${r}</tbody>`, "<table>\n<thead>\n" + t + "</thead>\n" + r + "</table>\n";
	}
	tablerow({ text: e }) {
		return `<tr>
${e}</tr>
`;
	}
	tablecell(e) {
		let t = this.parser.parseInline(e.tokens), n = e.header ? "th" : "td";
		return (e.align ? `<${n} align="${e.align}">` : `<${n}>`) + t + `</${n}>
`;
	}
	strong({ tokens: e }) {
		return `<strong>${this.parser.parseInline(e)}</strong>`;
	}
	em({ tokens: e }) {
		return `<em>${this.parser.parseInline(e)}</em>`;
	}
	codespan({ text: e }) {
		return `<code>${Ln(e, !0)}</code>`;
	}
	br(e) {
		return "<br>";
	}
	del({ tokens: e }) {
		return `<del>${this.parser.parseInline(e)}</del>`;
	}
	link({ href: e, title: t, tokens: n }) {
		let r = this.parser.parseInline(n), i = Rn(e);
		if (i === null) return r;
		e = i;
		let a = "<a href=\"" + e + "\"";
		return t && (a += " title=\"" + Ln(t) + "\""), a += ">" + r + "</a>", a;
	}
	image({ href: e, title: t, text: n, tokens: r }) {
		r && (n = this.parser.parseInline(r, this.parser.textRenderer));
		let i = Rn(e);
		if (i === null) return Ln(n);
		e = i;
		let a = `<img src="${e}" alt="${Ln(n)}"`;
		return t && (a += ` title="${Ln(t)}"`), a += ">", a;
	}
	text(e) {
		return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : Ln(e.text);
	}
}, Yn = class {
	strong({ text: e }) {
		return e;
	}
	em({ text: e }) {
		return e;
	}
	codespan({ text: e }) {
		return e;
	}
	del({ text: e }) {
		return e;
	}
	html({ text: e }) {
		return e;
	}
	text({ text: e }) {
		return e;
	}
	link({ text: e }) {
		return "" + e;
	}
	image({ text: e }) {
		return "" + e;
	}
	br() {
		return "";
	}
	checkbox({ raw: e }) {
		return e;
	}
}, Xn = class e {
	options;
	renderer;
	textRenderer;
	constructor(e) {
		this.options = e || wt, this.options.renderer = this.options.renderer || new Jn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new Yn();
	}
	static parse(t, n) {
		return new e(n).parse(t);
	}
	static parseInline(t, n) {
		return new e(n).parseInline(t);
	}
	parse(e) {
		this.renderer.parser = this;
		let t = "";
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (this.options.extensions?.renderers?.[r.type]) {
				let e = r, n = this.options.extensions.renderers[e.type].call({ parser: this }, e);
				if (n !== !1 || ![
					"space",
					"hr",
					"heading",
					"code",
					"table",
					"blockquote",
					"list",
					"html",
					"def",
					"paragraph",
					"text"
				].includes(e.type)) {
					t += n || "";
					continue;
				}
			}
			let i = r;
			switch (i.type) {
				case "space":
					t += this.renderer.space(i);
					break;
				case "hr":
					t += this.renderer.hr(i);
					break;
				case "heading":
					t += this.renderer.heading(i);
					break;
				case "code":
					t += this.renderer.code(i);
					break;
				case "table":
					t += this.renderer.table(i);
					break;
				case "blockquote":
					t += this.renderer.blockquote(i);
					break;
				case "list":
					t += this.renderer.list(i);
					break;
				case "checkbox":
					t += this.renderer.checkbox(i);
					break;
				case "html":
					t += this.renderer.html(i);
					break;
				case "def":
					t += this.renderer.def(i);
					break;
				case "paragraph":
					t += this.renderer.paragraph(i);
					break;
				case "text":
					t += this.renderer.text(i);
					break;
				default: {
					let e = "Token with \"" + i.type + "\" type was not found.";
					if (this.options.silent) return console.error(e), "";
					throw Error(e);
				}
			}
		}
		return t;
	}
	parseInline(e, t = this.renderer) {
		this.renderer.parser = this;
		let n = "";
		for (let r = 0; r < e.length; r++) {
			let i = e[r];
			if (this.options.extensions?.renderers?.[i.type]) {
				let e = this.options.extensions.renderers[i.type].call({ parser: this }, i);
				if (e !== !1 || ![
					"escape",
					"html",
					"link",
					"image",
					"strong",
					"em",
					"codespan",
					"br",
					"del",
					"text"
				].includes(i.type)) {
					n += e || "";
					continue;
				}
			}
			let a = i;
			switch (a.type) {
				case "escape":
					n += t.text(a);
					break;
				case "html":
					n += t.html(a);
					break;
				case "link":
					n += t.link(a);
					break;
				case "image":
					n += t.image(a);
					break;
				case "checkbox":
					n += t.checkbox(a);
					break;
				case "strong":
					n += t.strong(a);
					break;
				case "em":
					n += t.em(a);
					break;
				case "codespan":
					n += t.codespan(a);
					break;
				case "br":
					n += t.br(a);
					break;
				case "del":
					n += t.del(a);
					break;
				case "text":
					n += t.text(a);
					break;
				default: {
					let e = "Token with \"" + a.type + "\" type was not found.";
					if (this.options.silent) return console.error(e), "";
					throw Error(e);
				}
			}
		}
		return n;
	}
}, Zn = class {
	options;
	block;
	constructor(e) {
		this.options = e || wt;
	}
	static passThroughHooks = new Set([
		"preprocess",
		"postprocess",
		"processAllTokens",
		"emStrongMask"
	]);
	static passThroughHooksRespectAsync = new Set([
		"preprocess",
		"postprocess",
		"processAllTokens"
	]);
	preprocess(e) {
		return e;
	}
	postprocess(e) {
		return e;
	}
	processAllTokens(e) {
		return e;
	}
	emStrongMask(e) {
		return e;
	}
	provideLexer(e = this.block) {
		return e ? qn.lex : qn.lexInline;
	}
	provideParser(e = this.block) {
		return e ? Xn.parse : Xn.parseInline;
	}
}, Qn = new class {
	defaults = Ct();
	options = this.setOptions;
	parse = this.parseMarkdown(!0);
	parseInline = this.parseMarkdown(!1);
	Parser = Xn;
	Renderer = Jn;
	TextRenderer = Yn;
	Lexer = qn;
	Tokenizer = Kn;
	Hooks = Zn;
	constructor(...e) {
		this.use(...e);
	}
	walkTokens(e, t) {
		let n = [];
		for (let r of e) switch (n = n.concat(t.call(this, r)), r.type) {
			case "table": {
				let e = r;
				for (let r of e.header) n = n.concat(this.walkTokens(r.tokens, t));
				for (let r of e.rows) for (let e of r) n = n.concat(this.walkTokens(e.tokens, t));
				break;
			}
			case "list": {
				let e = r;
				n = n.concat(this.walkTokens(e.items, t));
				break;
			}
			default: {
				let e = r;
				this.defaults.extensions?.childTokens?.[e.type] ? this.defaults.extensions.childTokens[e.type].forEach((r) => {
					let i = e[r].flat(Infinity);
					n = n.concat(this.walkTokens(i, t));
				}) : e.tokens && (n = n.concat(this.walkTokens(e.tokens, t)));
			}
		}
		return n;
	}
	use(...e) {
		let t = this.defaults.extensions || {
			renderers: {},
			childTokens: {}
		};
		return e.forEach((e) => {
			let n = { ...e };
			if (n.async = this.defaults.async || n.async || !1, e.extensions && (e.extensions.forEach((e) => {
				if (!e.name) throw Error("extension name required");
				if ("renderer" in e) {
					let n = t.renderers[e.name];
					n ? t.renderers[e.name] = function(...t) {
						let r = e.renderer.apply(this, t);
						return r === !1 && (r = n.apply(this, t)), r;
					} : t.renderers[e.name] = e.renderer;
				}
				if ("tokenizer" in e) {
					if (!e.level || e.level !== "block" && e.level !== "inline") throw Error("extension level must be 'block' or 'inline'");
					let n = t[e.level];
					n ? n.unshift(e.tokenizer) : t[e.level] = [e.tokenizer], e.start && (e.level === "block" ? t.startBlock ? t.startBlock.push(e.start) : t.startBlock = [e.start] : e.level === "inline" && (t.startInline ? t.startInline.push(e.start) : t.startInline = [e.start]));
				}
				"childTokens" in e && e.childTokens && (t.childTokens[e.name] = e.childTokens);
			}), n.extensions = t), e.renderer) {
				let t = this.defaults.renderer || new Jn(this.defaults);
				for (let n in e.renderer) {
					if (!(n in t)) throw Error(`renderer '${n}' does not exist`);
					if (["options", "parser"].includes(n)) continue;
					let r = n, i = e.renderer[r], a = t[r];
					t[r] = (...e) => {
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n || "";
					};
				}
				n.renderer = t;
			}
			if (e.tokenizer) {
				let t = this.defaults.tokenizer || new Kn(this.defaults);
				for (let n in e.tokenizer) {
					if (!(n in t)) throw Error(`tokenizer '${n}' does not exist`);
					if ([
						"options",
						"rules",
						"lexer"
					].includes(n)) continue;
					let r = n, i = e.tokenizer[r], a = t[r];
					t[r] = (...e) => {
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n;
					};
				}
				n.tokenizer = t;
			}
			if (e.hooks) {
				let t = this.defaults.hooks || new Zn();
				for (let n in e.hooks) {
					if (!(n in t)) throw Error(`hook '${n}' does not exist`);
					if (["options", "block"].includes(n)) continue;
					let r = n, i = e.hooks[r], a = t[r];
					Zn.passThroughHooks.has(n) ? t[r] = (e) => {
						if (this.defaults.async && Zn.passThroughHooksRespectAsync.has(n)) return (async () => {
							let n = await i.call(t, e);
							return a.call(t, n);
						})();
						let r = i.call(t, e);
						return a.call(t, r);
					} : t[r] = (...e) => {
						if (this.defaults.async) return (async () => {
							let n = await i.apply(t, e);
							return n === !1 && (n = await a.apply(t, e)), n;
						})();
						let n = i.apply(t, e);
						return n === !1 && (n = a.apply(t, e)), n;
					};
				}
				n.hooks = t;
			}
			if (e.walkTokens) {
				let t = this.defaults.walkTokens, r = e.walkTokens;
				n.walkTokens = function(e) {
					let n = [];
					return n.push(r.call(this, e)), t && (n = n.concat(t.call(this, e))), n;
				};
			}
			this.defaults = {
				...this.defaults,
				...n
			};
		}), this;
	}
	setOptions(e) {
		return this.defaults = {
			...this.defaults,
			...e
		}, this;
	}
	lexer(e, t) {
		return qn.lex(e, t ?? this.defaults);
	}
	parser(e, t) {
		return Xn.parse(e, t ?? this.defaults);
	}
	parseMarkdown(e) {
		return (t, n) => {
			let r = { ...n }, i = {
				...this.defaults,
				...r
			}, a = this.onError(!!i.silent, !!i.async);
			if (this.defaults.async === !0 && r.async === !1) return a(/* @__PURE__ */ Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
			if (typeof t > "u" || t === null) return a(/* @__PURE__ */ Error("marked(): input parameter is undefined or null"));
			if (typeof t != "string") return a(/* @__PURE__ */ Error("marked(): input parameter is of type " + Object.prototype.toString.call(t) + ", string expected"));
			if (i.hooks && (i.hooks.options = i, i.hooks.block = e), i.async) return (async () => {
				let n = i.hooks ? await i.hooks.preprocess(t) : t, r = await (i.hooks ? await i.hooks.provideLexer(e) : e ? qn.lex : qn.lexInline)(n, i), a = i.hooks ? await i.hooks.processAllTokens(r) : r;
				i.walkTokens && await Promise.all(this.walkTokens(a, i.walkTokens));
				let o = await (i.hooks ? await i.hooks.provideParser(e) : e ? Xn.parse : Xn.parseInline)(a, i);
				return i.hooks ? await i.hooks.postprocess(o) : o;
			})().catch(a);
			try {
				i.hooks && (t = i.hooks.preprocess(t));
				let n = (i.hooks ? i.hooks.provideLexer(e) : e ? qn.lex : qn.lexInline)(t, i);
				i.hooks && (n = i.hooks.processAllTokens(n)), i.walkTokens && this.walkTokens(n, i.walkTokens);
				let r = (i.hooks ? i.hooks.provideParser(e) : e ? Xn.parse : Xn.parseInline)(n, i);
				return i.hooks && (r = i.hooks.postprocess(r)), r;
			} catch (e) {
				return a(e);
			}
		};
	}
	onError(e, t) {
		return (n) => {
			if (n.message += "\nPlease report this to https://github.com/markedjs/marked.", e) {
				let e = "<p>An error occurred:</p><pre>" + Ln(n.message + "", !0) + "</pre>";
				return t ? Promise.resolve(e) : e;
			}
			if (t) return Promise.reject(n);
			throw n;
		};
	}
}();
function X(e, t) {
	return Qn.parse(e, t);
}
X.options = X.setOptions = function(e) {
	return Qn.setOptions(e), X.defaults = Qn.defaults, Tt(X.defaults), X;
}, X.getDefaults = Ct, X.defaults = wt, X.use = function(...e) {
	return Qn.use(...e), X.defaults = Qn.defaults, Tt(X.defaults), X;
}, X.walkTokens = function(e, t) {
	return Qn.walkTokens(e, t);
}, X.parseInline = Qn.parseInline, X.Parser = Xn, X.parser = Xn.parse, X.Renderer = Jn, X.TextRenderer = Yn, X.Lexer = qn, X.lexer = qn.lex, X.Tokenizer = Kn, X.Hooks = Zn, X.parse = X, X.options, X.setOptions, X.use, X.walkTokens, X.parseInline, Xn.parse, qn.lex;
//#endregion
//#region src/orchestrator-markdown.helpers.ts
function $n(e) {
	if (!e) return null;
	let t = e.trim();
	if (!t) return null;
	if (t.startsWith("/") && !t.startsWith("//") || t.startsWith("./") || t.startsWith("../") || t.startsWith("#")) return t;
	try {
		let e = new URL(t);
		if (e.protocol === "http:" || e.protocol === "https:" || e.protocol === "mailto:") return t;
	} catch {
		return null;
	}
	return null;
}
//#endregion
//#region src/orchestrator-markdown.tsx
function er(e) {
	return e ? { textAlign: e } : void 0;
}
function tr(e, t) {
	return !e || e.length === 0 ? null : e.map((e, n) => nr(e, `${t}.${n}`));
}
function nr(e, t) {
	switch (e.type) {
		case "space":
		case "def": return null;
		case "paragraph": return /* @__PURE__ */ E("p", {
			className: "my-1 leading-relaxed first:mt-0 last:mb-0",
			children: tr(e.tokens, t)
		}, t);
		case "heading": return /* @__PURE__ */ E(`h${Math.min(Math.max(e.depth, 1), 4)}`, {
			className: "mt-2 mb-1 font-semibold text-txt first:mt-0",
			children: tr(e.tokens, t)
		}, t);
		case "code": return /* @__PURE__ */ E(rr, {
			code: e.text,
			lang: e.lang
		}, t);
		case "blockquote": return /* @__PURE__ */ E("blockquote", {
			className: "my-1 border-l-2 border-border pl-3 text-muted-strong",
			children: tr(e.tokens, t)
		}, t);
		case "list": {
			let n = e.items.map((e, n) => {
				let r = `${t}.${n}`;
				return /* @__PURE__ */ D("li", {
					className: "my-0.5 marker:text-muted",
					children: [e.task ? /* @__PURE__ */ E("input", {
						type: "checkbox",
						checked: !!e.checked,
						readOnly: !0,
						"aria-hidden": !0,
						className: "mr-1.5 align-middle accent-accent"
					}) : null, tr(e.tokens, r)]
				}, r);
			});
			return e.ordered ? /* @__PURE__ */ E("ol", {
				start: typeof e.start == "number" ? e.start : void 0,
				className: "my-1 list-decimal space-y-0.5 pl-5",
				children: n
			}, t) : /* @__PURE__ */ E("ul", {
				className: "my-1 list-disc space-y-0.5 pl-5",
				children: n
			}, t);
		}
		case "table": return /* @__PURE__ */ E("div", {
			className: "my-1.5 overflow-x-auto",
			children: /* @__PURE__ */ D("table", {
				className: "w-full border-collapse text-2xs",
				children: [/* @__PURE__ */ E("thead", { children: /* @__PURE__ */ E("tr", { children: e.header.map((e, n) => {
					let r = `${t}.h${n}`;
					return /* @__PURE__ */ E("th", {
						style: er(e.align),
						className: "border border-border/60 bg-bg/40 px-2 py-1 text-left font-semibold text-txt",
						children: tr(e.tokens, r)
					}, r);
				}) }) }), /* @__PURE__ */ E("tbody", { children: e.rows.map((e, n) => {
					let r = `${t}.r${n}`;
					return /* @__PURE__ */ E("tr", { children: e.map((e, t) => {
						let n = `${r}c${t}`;
						return /* @__PURE__ */ E("td", {
							style: er(e.align),
							className: "border border-border/50 px-2 py-1 align-top",
							children: tr(e.tokens, n)
						}, n);
					}) }, r);
				}) })]
			})
		}, t);
		case "hr": return /* @__PURE__ */ E("hr", { className: "my-2 border-border/50" }, t);
		case "strong": return /* @__PURE__ */ E("strong", {
			className: "font-semibold text-txt",
			children: tr(e.tokens, t)
		}, t);
		case "em": return /* @__PURE__ */ E("em", {
			className: "italic",
			children: tr(e.tokens, t)
		}, t);
		case "del": return /* @__PURE__ */ E("del", {
			className: "line-through opacity-80",
			children: tr(e.tokens, t)
		}, t);
		case "codespan": return /* @__PURE__ */ E("code", {
			className: "break-words rounded-sm bg-bg/70 px-1 py-px font-mono text-[0.95em] text-txt-strong",
			children: e.text
		}, t);
		case "link": {
			let n = $n(e.href), r = n !== null && /^https?:/i.test(n);
			return /* @__PURE__ */ E("a", {
				href: n ?? void 0,
				title: e.title ?? void 0,
				target: r ? "_blank" : void 0,
				rel: r ? "noreferrer" : void 0,
				className: "text-txt-strong underline underline-offset-2 transition-colors hover:text-accent",
				children: tr(e.tokens, t)
			}, t);
		}
		case "image": {
			let n = $n(e.href);
			return n ? /* @__PURE__ */ E("img", {
				src: n,
				alt: e.text,
				title: e.title ?? void 0,
				className: "my-1 max-w-full rounded-sm border border-border/50"
			}, t) : e.text;
		}
		case "br": return /* @__PURE__ */ E("br", {}, t);
		case "escape": return e.text;
		case "text": return e.tokens && e.tokens.length > 0 ? tr(e.tokens, t) : e.text;
		default: return "raw" in e ? e.raw : null;
	}
}
function rr({ code: e, lang: t }) {
	let [n, r] = w(!1), i = C(null);
	return x(() => () => {
		i.current && clearTimeout(i.current);
	}, []), /* @__PURE__ */ D("div", {
		className: "group/code relative my-1 overflow-hidden rounded-sm border border-border/50 bg-bg/80",
		children: [
			t ? /* @__PURE__ */ E("div", {
				className: "border-b border-border/40 px-2.5 py-0.5 font-mono text-3xs uppercase tracking-wide text-muted",
				children: t
			}) : null,
			/* @__PURE__ */ E("button", {
				type: "button",
				onClick: () => {
					typeof navigator > "u" || !navigator.clipboard?.writeText || navigator.clipboard.writeText(e).then(() => {
						r(!0), i.current && clearTimeout(i.current), i.current = setTimeout(() => r(!1), 1200);
					}, () => void 0);
				},
				"aria-label": n ? "Copied" : "Copy code",
				className: `absolute right-1 top-1 z-10 rounded p-1 text-muted opacity-0 transition-[color,opacity] hover:bg-bg-hover/60 hover:text-txt focus-visible:opacity-100 group-hover/code:opacity-100 ${n ? "text-ok opacity-100" : ""}`,
				children: E(n ? j : oe, {
					className: "h-3.5 w-3.5",
					"aria-hidden": !0
				})
			}),
			/* @__PURE__ */ E("pre", {
				className: "max-h-72 overflow-auto px-2.5 py-1.5 font-mono text-2xs leading-relaxed text-txt",
				children: /* @__PURE__ */ E("code", {
					className: "whitespace-pre-wrap break-words",
					children: e
				})
			})
		]
	});
}
function ir({ text: e }) {
	let t;
	try {
		t = X.lexer(e);
	} catch {
		return /* @__PURE__ */ E("div", {
			className: "whitespace-pre-wrap break-words text-xs text-txt",
			children: e
		});
	}
	return /* @__PURE__ */ E("div", {
		className: "break-words text-xs text-txt",
		children: t.map((e, t) => nr(e, `t${t}`))
	});
}
//#endregion
//#region src/orchestrator-reasoning.tsx
var ar = "\n.orchestrator-reasoning-shimmer {\n  -webkit-mask-image: linear-gradient(\n    100deg,\n    rgba(0, 0, 0, 0.45) 30%,\n    rgba(0, 0, 0, 1) 50%,\n    rgba(0, 0, 0, 0.45) 70%\n  );\n  mask-image: linear-gradient(\n    100deg,\n    rgba(0, 0, 0, 0.45) 30%,\n    rgba(0, 0, 0, 1) 50%,\n    rgba(0, 0, 0, 0.45) 70%\n  );\n  -webkit-mask-size: 220% 100%;\n  mask-size: 220% 100%;\n  animation: orchestrator-reasoning-sweep 1.8s linear infinite;\n}\n@keyframes orchestrator-reasoning-sweep {\n  from {\n    -webkit-mask-position: 180% 0;\n    mask-position: 180% 0;\n  }\n  to {\n    -webkit-mask-position: -80% 0;\n    mask-position: -80% 0;\n  }\n}\n@media (prefers-reduced-motion: reduce) {\n  .orchestrator-reasoning-shimmer {\n    -webkit-mask-image: none;\n    mask-image: none;\n    animation: none;\n  }\n}\n";
function or(e) {
	let t = Math.max(0, Math.round(e / 1e3));
	if (t < 60) return `${t}s`;
	let n = Math.floor(t / 60), r = t % 60;
	return r === 0 ? `${n}m` : `${n}m ${r}s`;
}
function sr({ text: e, durationMs: t, streaming: n }) {
	let [r, i] = w(!1), a = n ? "Thinking…" : t === void 0 ? "Thought" : `Thought for ${or(t)}`;
	return /* @__PURE__ */ D("div", {
		className: "rounded-md border border-border/50 bg-card/50",
		"data-testid": "orchestrator-reasoning",
		children: [
			/* @__PURE__ */ D("button", {
				type: "button",
				onClick: () => i((e) => !e),
				"aria-expanded": r,
				className: "flex w-full items-center gap-2 px-2.5 py-1.5 text-left",
				children: [
					/* @__PURE__ */ E(N, { className: `h-3 w-3 shrink-0 text-muted transition-transform ${r ? "rotate-90" : ""}` }),
					/* @__PURE__ */ E(A, { className: "h-3.5 w-3.5 shrink-0 text-muted-strong" }),
					/* @__PURE__ */ E("span", {
						className: `min-w-0 flex-1 truncate text-2xs italic text-muted ${n ? "orchestrator-reasoning-shimmer" : ""}`,
						children: a
					})
				]
			}),
			r ? /* @__PURE__ */ E("div", {
				className: "px-2.5 pb-2",
				children: /* @__PURE__ */ E("div", {
					className: `text-2xs italic text-muted ${n ? "orchestrator-reasoning-shimmer" : ""}`,
					children: /* @__PURE__ */ E(ir, { text: e })
				})
			}) : null,
			/* @__PURE__ */ E("style", {
				href: "orchestrator-reasoning-shimmer",
				precedence: "default",
				children: ar
			})
		]
	});
}
//#endregion
//#region src/view-format.ts
var cr = new RegExp(["\\u001b(?:", "\\[[0-9;?]*[A-Za-z]|\\][^\\u0007]*\\u0007|[()][0-9A-Za-z])"].join(""), "g");
function lr(e) {
	return e.replace(cr, "").trim();
}
function ur(e, t) {
	let n = Math.max(0, Math.floor((Date.now() - e) / 1e3)), r = new Intl.RelativeTimeFormat(t, { numeric: "auto" });
	if (n < 5) return r.format(0, "second");
	if (n < 60) return r.format(-n, "second");
	let i = Math.floor(n / 60);
	if (i < 60) return r.format(-i, "minute");
	let a = Math.floor(i / 60);
	return a < 24 ? r.format(-a, "hour") : r.format(-Math.floor(a / 24), "day");
}
function dr(e, t, n) {
	if (!e) return n;
	let r = new Date(e);
	return Number.isNaN(r.getTime()) ? n : ur(r.getTime(), t);
}
function fr(e, t) {
	return new Intl.DateTimeFormat(t, {
		hour: "2-digit",
		minute: "2-digit"
	}).format(new Date(e));
}
function pr(e, t) {
	return new Intl.NumberFormat(t, {
		notation: "compact",
		maximumFractionDigits: 1
	}).format(e);
}
function mr(e, t) {
	return new Intl.NumberFormat(t, {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: e !== 0 && e < 1 ? 4 : 2
	}).format(e);
}
function hr(e) {
	if (e < 1e3) return `${Math.round(e)}ms`;
	let t = e / 1e3;
	if (t < 60) return `${t.toFixed(+(t < 10))}s`;
	let n = Math.floor(t / 60), r = Math.round(t % 60);
	return r ? `${n}m ${r}s` : `${n}m`;
}
//#endregion
//#region src/orchestrator-stream.tsx
var gr = {
	edit: se,
	read: le,
	execute: Te,
	search: xe,
	fetch: pe,
	move: se,
	delete: se,
	think: Ae
}, _r = {
	write: ce,
	edit: se,
	read: le,
	bash: Te,
	shell: Te,
	grep: xe,
	glob: xe,
	list: xe,
	webfetch: pe,
	fetch: pe
};
function vr(e) {
	return _r[e.title.toLowerCase()] ?? gr[e.kind.toLowerCase()] ?? Ae;
}
var yr = {
	execute: ["Running", "Ran"],
	read: ["Reading", "Read"],
	edit: ["Editing", "Edited"],
	search: ["Searching", "Searched"],
	fetch: ["Fetching", "Searched web"],
	move: ["Moving", "Moved"],
	delete: ["Deleting", "Deleted"],
	think: ["Thinking", "Thought"]
}, br = {
	write: ["Writing", "Wrote"],
	edit: ["Editing", "Edited"],
	read: ["Reading", "Read"],
	bash: ["Running", "Ran"],
	shell: ["Running", "Ran"],
	grep: ["Searching", "Searched"],
	glob: ["Searching", "Searched"],
	list: ["Listing", "Listed"],
	webfetch: ["Fetching", "Searched web"],
	fetch: ["Fetching", "Searched web"]
};
function xr(e) {
	let t = br[e.title.toLowerCase()] ?? yr[e.kind.toLowerCase()];
	return t ? e.status === "running" ? t[0] : t[1] : e.title;
}
function Sr(e) {
	if (e.filePath) {
		let t = e.filePath.split("/");
		return t[t.length - 1] || e.filePath;
	}
	if (e.command) return e.command;
	if (e.query) return e.query;
}
var Cr = {
	running: {
		icon: z,
		tone: "text-muted-strong",
		label: "Running",
		spin: !0
	},
	done: {
		icon: j,
		tone: "text-ok",
		label: "Done"
	},
	failed: {
		icon: R,
		tone: "text-red-500",
		label: "Failed"
	}
}, wr = 4e3;
function Tr(e) {
	return e.length <= wr ? {
		body: e,
		truncated: !1
	} : {
		body: e.slice(0, wr),
		truncated: !0
	};
}
function Er() {
	return /* @__PURE__ */ E("div", {
		className: "px-1 text-2xs text-muted/70",
		children: "… (truncated for display)"
	});
}
function Dr(e) {
	if (e.length <= wr) return e;
	let t = Math.ceil(wr * .6), n = wr - t, r = e.length - t - n;
	return `${e.slice(0, t).trimEnd()}\n\n… ${r.toLocaleString()} characters elided …\n\n${e.slice(-1600).trimStart()}`;
}
function Or({ tool: e }) {
	let t = [];
	if (e.oldText !== void 0 && e.newText !== void 0) {
		let n = Tr(e.oldText), r = Tr(e.newText);
		t.push(/* @__PURE__ */ E(St, {
			oldText: n.body,
			newText: r.body
		}, "diff")), (n.truncated || r.truncated) && t.push(/* @__PURE__ */ E(Er, {}, "diff-trunc"));
	} else if (e.newText !== void 0) {
		let { body: n, truncated: r } = Tr(e.newText);
		t.push(/* @__PURE__ */ E(St, { newText: n }, "content")), r && t.push(/* @__PURE__ */ E(Er, {}, "content-trunc"));
	}
	return e.output && t.push(/* @__PURE__ */ E("pre", {
		className: "overflow-auto rounded-md border border-border/40 bg-bg/60 px-2.5 py-1.5 font-mono text-2xs leading-relaxed text-muted",
		style: { maxHeight: "14rem" },
		children: Dr(e.output)
	}, "out")), t.length === 0 ? null : /* @__PURE__ */ E("div", {
		className: "mt-1.5 space-y-1.5",
		children: t
	});
}
function kr({ tool: e, onInspect: t }) {
	let n = vr(e), r = Cr[e.status], i = r.icon, a = Sr(e), o = !!(e.newText !== void 0 || e.output), s = S(() => e.newText === void 0 ? null : pt(ft(e.oldText ?? "", e.newText)), [e.oldText, e.newText]), c = [];
	typeof e.exitCode == "number" && e.exitCode !== 0 && c.push(`exit ${e.exitCode}`), e.durationMs !== void 0 && e.durationMs >= 1e3 && c.push(hr(e.durationMs));
	let [l, u] = w(() => o && e.kind !== "read" && e.kind !== "search");
	return /* @__PURE__ */ D("div", {
		className: "rounded-md border border-border/50 bg-card/50",
		"data-testid": "orchestrator-tool-call",
		children: [/* @__PURE__ */ D("button", {
			type: "button",
			disabled: !o,
			onClick: () => {
				t?.(), u((e) => !e);
			},
			className: "flex w-full items-center gap-2 px-2.5 py-1.5 text-left disabled:cursor-default",
			children: [
				o ? /* @__PURE__ */ E(N, { className: `h-3 w-3 shrink-0 text-muted transition-transform ${l ? "rotate-90" : ""}` }) : /* @__PURE__ */ E("span", { className: "w-3 shrink-0" }),
				/* @__PURE__ */ E(n, { className: "h-3.5 w-3.5 shrink-0 text-muted-strong" }),
				/* @__PURE__ */ E("span", {
					className: "shrink-0 text-xs font-semibold text-txt",
					children: xr(e)
				}),
				a && a !== e.title ? /* @__PURE__ */ E("span", {
					title: a,
					className: "min-w-0 flex-1 truncate font-mono text-2xs text-muted",
					children: a
				}) : /* @__PURE__ */ E("span", { className: "flex-1" }),
				s && (s.added > 0 || s.removed > 0) ? /* @__PURE__ */ E(mt, {
					added: s.added,
					removed: s.removed
				}) : null,
				/* @__PURE__ */ D("span", {
					className: `flex shrink-0 items-center gap-1 text-2xs ${r.tone}`,
					children: [/* @__PURE__ */ E(i, { className: `h-3 w-3 ${r.spin ? "animate-spin" : ""}` }), r.label]
				}),
				c.length > 0 ? /* @__PURE__ */ E("span", {
					className: "shrink-0 font-mono text-2xs tabular-nums text-muted/70",
					children: c.join(" · ")
				}) : null
			]
		}), l ? /* @__PURE__ */ E("div", {
			className: "px-2.5 pb-2",
			children: /* @__PURE__ */ E(Or, { tool: e })
		}) : null]
	});
}
function Ar({ block: e, locale: t, onInspect: n }) {
	if (e.kind === "user") return /* @__PURE__ */ E("div", {
		className: "flex flex-col items-end",
		"data-testid": "orchestrator-user-message",
		children: /* @__PURE__ */ D("div", {
			className: "rounded-lg border border-border/50 bg-surface px-3 py-2 text-xs text-txt",
			style: { maxWidth: "80%" },
			children: [/* @__PURE__ */ E("div", {
				className: "whitespace-pre-wrap break-words leading-relaxed",
				children: e.content
			}), /* @__PURE__ */ E("div", {
				className: "mt-1 text-3xs tabular-nums text-muted/70",
				children: fr(e.at, t)
			})]
		})
	});
	if (e.kind === "agent") return /* @__PURE__ */ D("div", {
		className: "flex w-full flex-col items-start",
		"data-testid": "orchestrator-agent-message",
		children: [/* @__PURE__ */ D("div", {
			className: "mb-1 flex items-center gap-2 text-3xs text-muted",
			children: [
				/* @__PURE__ */ E("span", {
					className: "inline-block h-1.5 w-1.5 rounded-full bg-muted-strong",
					"aria-hidden": !0
				}),
				/* @__PURE__ */ E("span", {
					className: "font-semibold tracking-tight text-txt/90",
					children: e.senderName
				}),
				/* @__PURE__ */ E("span", {
					className: "tabular-nums",
					children: fr(e.at, t)
				})
			]
		}), /* @__PURE__ */ E("div", {
			className: e.tone === "error" ? "w-full border-l-2 border-red-500/40 pl-2.5 text-red-500" : "w-full text-txt",
			children: /* @__PURE__ */ E(ir, { text: e.content })
		})]
	});
	if (e.kind === "tool") return /* @__PURE__ */ E(kr, {
		tool: e.tool,
		onInspect: n
	});
	if (e.kind === "reasoning") return /* @__PURE__ */ E(sr, {
		text: e.text,
		durationMs: e.durationMs,
		streaming: e.streaming
	});
	let r = e.icon;
	return /* @__PURE__ */ D("div", {
		className: "flex items-center gap-2 px-1 text-2xs text-muted",
		"data-testid": "orchestrator-notice",
		children: [
			/* @__PURE__ */ E("span", { className: "h-px flex-1 bg-border/40" }),
			/* @__PURE__ */ E(r, { className: `h-3 w-3 shrink-0 ${e.tone}` }),
			/* @__PURE__ */ E("span", {
				className: `min-w-0 shrink truncate font-medium ${e.tone}`,
				children: e.text
			}),
			/* @__PURE__ */ E("span", { className: "h-px flex-1 bg-border/40" })
		]
	});
}
//#endregion
//#region src/orchestrator-stream.helpers.ts
var jr = new Set([
	"message",
	"usage_update",
	"ready",
	"available_commands_update"
]), Mr = {
	task_registered: {
		icon: I,
		tone: "text-muted",
		label: "Task started"
	},
	task_complete: {
		icon: L,
		tone: "text-ok",
		label: "Completed"
	},
	stopped: {
		icon: ae,
		tone: "text-muted",
		label: "Stopped"
	},
	blocked: {
		icon: he,
		tone: "text-muted-strong",
		label: "Blocked"
	},
	blocked_auto_resolved: {
		icon: j,
		tone: "text-muted",
		label: "Auto-resolved"
	},
	escalation: {
		icon: ne,
		tone: "text-muted",
		label: "Escalation"
	},
	error: {
		icon: R,
		tone: "text-red-500",
		label: "Error"
	}
};
function Nr(e) {
	return Mr[e] ?? {
		icon: I,
		tone: "text-muted",
		label: e.replace(/_/g, " ")
	};
}
var Pr = {
	in_progress: "running",
	pending: "running",
	running: "running",
	queued: "running",
	completed: "done",
	success: "done",
	done: "done",
	ok: "done",
	failed: "failed",
	error: "failed",
	cancelled: "failed",
	skipped: "failed"
};
function Fr(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : void 0;
}
function Z(e, ...t) {
	if (e) for (let n of t) {
		let t = e[n];
		if (typeof t == "string" && t.trim() !== "") return t;
	}
}
function Ir(e, ...t) {
	if (e) for (let n of t) {
		let t = e[n];
		if (typeof t == "number" && Number.isFinite(t)) return t;
	}
}
function Lr(e) {
	let t;
	if (typeof e == "string" ? t = e : Array.isArray(e) && (t = e.map((e) => Z(Fr(e), "text", "content") ?? "").join("")), t === void 0) return;
	if (t.length >= 2 && t.startsWith("\"") && t.endsWith("\"") && !t.includes("\n")) try {
		let e = JSON.parse(t);
		typeof e == "string" && (t = e);
	} catch {}
	let n = lr(t).trim();
	return n === "" ? void 0 : n;
}
function Rr(e) {
	let t = e;
	if (typeof t == "string") {
		let n = t.trim();
		if (!n.startsWith("[") && !n.startsWith("{")) return { text: Lr(e) };
		try {
			t = JSON.parse(n);
		} catch {
			return { text: Lr(e) };
		}
	}
	let n = Array.isArray(t) ? t : [t], r = [], i, a;
	for (let e of n) {
		let t = Fr(e);
		if (!t) continue;
		if (t.type === "diff") {
			i = {
				path: Z(t, "path"),
				oldText: typeof t.oldText == "string" ? t.oldText : void 0,
				newText: typeof t.newText == "string" ? t.newText : void 0
			};
			continue;
		}
		let n = Fr(t.content) ?? t, o = Z(n, "text", "content", "output") ?? Z(t, "text", "output");
		o && r.push(o);
		let s = Ir(Fr(t.metadata) ?? Fr(n.metadata), "exitCode", "exit_code") ?? Ir(t, "exitCode", "exit_code") ?? Ir(n, "exitCode", "exit_code");
		s !== void 0 && (a = s);
	}
	let o = lr(r.join("\n")).trim();
	return {
		text: o === "" ? void 0 : o,
		diff: i,
		exitCode: a
	};
}
function zr(e) {
	return Fr(e.data?.toolCall);
}
function Br(e, t, n) {
	let r = "tool", i = "", a = "running", o, s, c, l, u, d;
	for (let e of n) {
		let t = zr(e);
		if (!t) continue;
		r = Z(t, "title", "name", "toolName") ?? r, i = Z(t, "kind") ?? i;
		let n = Z(t, "status");
		n && (o = n, a = Pr[n] ?? a);
		let f = Fr(t.rawInput) ?? Fr(t.input);
		f && (s = {
			...s,
			...f
		});
		let p = t.output ?? t.rawOutput;
		p !== void 0 && (c = p);
		let m = Rr(p);
		m.text && (l = m.text), (m.diff?.oldText !== void 0 || m.diff?.newText !== void 0) && (u = m.diff), m.exitCode !== void 0 && (d = m.exitCode);
		let h = Ir(Fr(t.exitStatus), "exitCode") ?? Ir(t, "exitCode");
		h !== void 0 && (d = h);
	}
	typeof d == "number" && (a = d === 0 ? "done" : "failed");
	let f = n.length > 1 ? n[n.length - 1].timestamp - n[0].timestamp : void 0;
	return {
		groupKey: t,
		id: e,
		eventIds: n.map((e) => e.id),
		sessionId: n[0]?.sessionId ?? null,
		title: r,
		kind: i,
		rawStatus: o,
		rawInput: s,
		rawOutput: c,
		status: a,
		filePath: Z(s, "filePath", "file_path", "path"),
		command: Z(s, "command", "cmd", "script"),
		newText: typeof s?.content == "string" ? s.content : typeof s?.new_string == "string" ? s.new_string : typeof s?.newString == "string" ? s.newString : Z(s, "newText") ?? u?.newText,
		oldText: typeof s?.old_string == "string" ? s.old_string : typeof s?.oldString == "string" ? s.oldString : Z(s, "oldText") ?? u?.oldText,
		query: Z(s, "pattern", "query", "regex", "glob"),
		output: l,
		exitCode: d,
		durationMs: f && f > 0 ? f : void 0
	};
}
function Vr(e) {
	if (e.senderKind === "user") return `user:${e.id}`;
	let t = e.direction === "stderr" ? "err" : "out";
	return `${e.senderKind}:${e.sessionId ?? e.id}:${t}`;
}
function Hr(e, t) {
	return `${e.sessionId ?? e.threadId ?? "sessionless"}:${t}`;
}
function Ur(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = [], s = 0;
	for (let t of e) t.senderKind !== "user" && (t.direction === "stdin" || t.direction === "keys") || lr(t.content).trim() !== "" && o.push({
		at: t.timestamp,
		order: s++,
		type: "message",
		message: t
	});
	for (let e of t) {
		let t = zr(e);
		if (t) {
			let n = Z(t, "id", "toolCallId", "callId") ?? `tool-${e.id}`, r = Hr(e, n), o = i.get(r);
			o ? o.events.push(e) : (i.set(r, {
				id: n,
				events: [e]
			}), a.set(r, e.timestamp));
			continue;
		}
		if (e.eventType === "reasoning") {
			let t = typeof e.data?.text == "string" ? e.data.text : "";
			t && o.push({
				at: e.timestamp,
				order: s++,
				type: "reasoning",
				eventId: e.id,
				text: t,
				sessionId: e.sessionId
			});
			continue;
		}
		jr.has(e.eventType) || o.push({
			at: e.timestamp,
			order: s++,
			type: "notice",
			eventId: e.id,
			sessionId: e.sessionId,
			eventType: e.eventType,
			summary: e.summary
		});
	}
	for (let [e, t] of i) {
		let n = t.events, i = Br(t.id, e, n), c = n[0].sessionId;
		i.status === "running" && c && r.has(c) && (i.status = "done"), o.push({
			at: a.get(e) ?? n[0].timestamp,
			order: s++,
			type: "tool",
			tool: i
		});
	}
	o.sort((e, t) => e.at - t.at || e.order - t.order);
	let c = [], l = null, u = null;
	for (let e of o) {
		if (e.type === "message") {
			u = null;
			let t = Vr(e.message), r = lr(e.message.content);
			if (l && l.lane === t) {
				l.block.content += r, l.block.messageIds.push(e.message.id);
				continue;
			}
			if (e.message.senderKind === "user") {
				let n = {
					kind: "user",
					key: `msg-${e.message.id}`,
					at: e.at,
					content: r,
					messageIds: [e.message.id],
					sessionId: e.message.sessionId
				};
				c.push(n), l = {
					lane: t,
					block: n
				};
			} else {
				let i = {
					kind: "agent",
					key: `msg-${e.message.id}`,
					at: e.at,
					senderName: n(e.message),
					content: r,
					tone: e.message.direction === "stderr" ? "error" : "normal",
					messageIds: [e.message.id],
					sessionId: e.message.sessionId
				};
				c.push(i), l = {
					lane: t,
					block: i
				};
			}
			continue;
		}
		if (l = null, e.type === "reasoning") {
			let t = e.sessionId ? !r.has(e.sessionId) : !1;
			if (u && u.sessionId === e.sessionId) u.text += e.text, u.eventIds.push(e.eventId), u.durationMs = e.at - u.at, u.streaming = t;
			else {
				let n = {
					kind: "reasoning",
					key: `reason-${e.eventId}`,
					at: e.at,
					text: e.text,
					eventIds: [e.eventId],
					sessionId: e.sessionId,
					durationMs: void 0,
					streaming: t
				};
				c.push(n), u = n;
			}
			continue;
		}
		if (u = null, e.type === "tool") c.push({
			kind: "tool",
			key: `tool-${e.tool.groupKey}`,
			at: e.at,
			tool: e.tool
		});
		else {
			let t = Nr(e.eventType);
			c.push({
				kind: "notice",
				key: `evt-${e.eventId}`,
				at: e.at,
				eventId: e.eventId,
				eventType: e.eventType,
				sessionId: e.sessionId,
				icon: t.icon,
				tone: t.tone,
				text: e.summary.trim() || t.label
			});
		}
	}
	return c;
}
//#endregion
//#region src/orchestrator-workbench-glyphs.tsx
var Wr = (e, t) => String(t?.defaultValue ?? e), Gr = {
	open: I,
	active: ie,
	waiting_on_user: ke,
	blocked: he,
	validating: re,
	done: L,
	failed: R,
	archived: O,
	interrupted: ne
}, Kr = {
	open: "text-muted",
	active: "text-ok",
	waiting_on_user: "text-warn",
	blocked: "text-warn",
	validating: "text-accent",
	done: "text-ok",
	failed: "text-danger",
	archived: "text-muted",
	interrupted: "text-warn"
}, qr = new Set(["active", "validating"]), Jr = new Set([
	"done",
	"failed",
	"archived"
]), Yr = {
	low: M,
	normal: null,
	high: P,
	urgent: F
}, Xr = {
	active: ie,
	running: ie,
	tool_running: ie,
	blocked: he,
	idle: I,
	completed: L,
	stopped: ae,
	error: R,
	errored: R
}, Zr = {
	active: "text-ok",
	running: "text-ok",
	tool_running: "text-ok",
	blocked: "text-warn",
	idle: "text-muted",
	completed: "text-ok",
	stopped: "text-muted",
	error: "text-danger",
	errored: "text-danger"
}, Qr = new Set([
	"active",
	"running",
	"tool_running"
]), $r = {
	passed: L,
	failed: R,
	pending: re,
	unknown: I
}, ei = {
	passed: "text-ok",
	failed: "text-danger",
	pending: "text-warn",
	unknown: "text-muted"
}, ti = {
	done: L,
	completed: L,
	passed: L,
	in_progress: re,
	active: re,
	running: re,
	blocked: he,
	failed: R,
	pending: I,
	todo: I
}, ni = {
	done: "text-ok",
	completed: "text-ok",
	passed: "text-ok",
	in_progress: "text-accent",
	active: "text-accent",
	running: "text-accent",
	blocked: "text-warn",
	failed: "text-danger",
	pending: "text-muted",
	todo: "text-muted"
}, ri = [
	"all",
	"active",
	"blocked",
	"validating",
	"waiting_on_user",
	"interrupted",
	"open",
	"done",
	"failed"
], ii = {
	open: "orchestrator.status.open",
	active: "orchestrator.status.active",
	waiting_on_user: "orchestrator.status.waitingOnUser",
	blocked: "orchestrator.status.blocked",
	validating: "orchestrator.status.validating",
	done: "orchestrator.status.done",
	failed: "orchestrator.status.failed",
	archived: "orchestrator.status.archived",
	interrupted: "orchestrator.status.interrupted"
};
function ai(e, t) {
	return t(ii[e], { defaultValue: e.replace(/_/g, " ") });
}
function oi(e, t) {
	return t(`orchestrator.priority.${e}`, { defaultValue: e });
}
function si(e, t) {
	return t(`orchestrator.sessionStatus.${e}`, { defaultValue: e.replace(/_/g, " ") });
}
function ci({ status: e, paused: t, t: n, size: r = "h-3.5 w-3.5" }) {
	let i = Gr[e], a = ai(e, n), o = qr.has(e) && !t ? " animate-pulse" : "";
	return /* @__PURE__ */ E("span", {
		className: "inline-flex shrink-0",
		title: a,
		"aria-label": a,
		role: "img",
		children: /* @__PURE__ */ E(i, {
			className: `${r} ${Kr[e]}${o}`,
			"aria-hidden": !0
		})
	});
}
function li({ status: e, t, size: n = "h-3.5 w-3.5" }) {
	let r = Xr[e] ?? I, i = Zr[e] ?? "text-muted", a = si(e, t);
	return /* @__PURE__ */ E("span", {
		className: "inline-flex shrink-0",
		title: a,
		"aria-label": a,
		role: "img",
		children: /* @__PURE__ */ E(r, {
			className: `${n} ${i}${Qr.has(e) ? " animate-pulse" : ""}`,
			"aria-hidden": !0
		})
	});
}
function ui({ status: e, t }) {
	let n = $r[e], r = t(`orchestrator.verification.${e}`, { defaultValue: e });
	return /* @__PURE__ */ E("span", {
		className: "inline-flex shrink-0",
		title: r,
		"aria-label": r,
		role: "img",
		children: /* @__PURE__ */ E(n, {
			className: `h-3.5 w-3.5 ${ei[e]}`,
			"aria-hidden": !0
		})
	});
}
function di({ status: e, t }) {
	let n = e.trim().toLowerCase().replace(/[\s-]+/g, "_"), r = ti[n] ?? I, i = ni[n] ?? "text-muted", a = t(`orchestrator.planStatus.${n}`, { defaultValue: e.replace(/_/g, " ") });
	return /* @__PURE__ */ E("span", {
		className: "mt-px inline-flex shrink-0",
		title: a,
		"aria-label": a,
		role: "img",
		children: /* @__PURE__ */ E(r, {
			className: `h-3.5 w-3.5 ${i}`,
			"aria-hidden": !0
		})
	});
}
var fi = {
	user: {
		key: "orchestrator.sender.user",
		fallback: "You"
	},
	orchestrator: {
		key: "orchestrator.sender.orchestrator",
		fallback: "Orchestrator"
	},
	sub_agent: {
		key: "orchestrator.sender.subAgent",
		fallback: "Sub-agent"
	},
	system: {
		key: "orchestrator.sender.system",
		fallback: "System"
	}
};
function pi(e, t) {
	let n = fi[e];
	return t(n.key, { defaultValue: n.fallback });
}
function mi(e, t, n, r) {
	return e.senderKind === "sub_agent" ? (e.sessionId ? t.get(e.sessionId)?.trim() : void 0) || pi("sub_agent", r) : e.senderKind === "orchestrator" ? n?.trim() || pi("orchestrator", r) : pi(e.senderKind, r);
}
//#endregion
//#region src/TaskCardList.tsx
var hi = {
	open: {
		icon: I,
		fg: "text-accent",
		dot: "bg-accent",
		pulse: !1
	},
	active: {
		icon: ie,
		fg: "text-ok",
		dot: "bg-ok",
		pulse: !0
	},
	validating: {
		icon: re,
		fg: "text-accent",
		dot: "bg-accent",
		pulse: !0
	},
	waiting_on_user: {
		icon: ke,
		fg: "text-warn",
		dot: "bg-warn",
		pulse: !1
	},
	blocked: {
		icon: he,
		fg: "text-warn",
		dot: "bg-warn",
		pulse: !1
	},
	interrupted: {
		icon: ne,
		fg: "text-warn",
		dot: "bg-warn",
		pulse: !1
	},
	done: {
		icon: L,
		fg: "text-ok",
		dot: "bg-ok",
		pulse: !1
	},
	failed: {
		icon: R,
		fg: "text-danger",
		dot: "bg-danger",
		pulse: !1
	},
	archived: {
		icon: O,
		fg: "text-muted",
		dot: "bg-muted",
		pulse: !1
	}
};
function gi(e) {
	return hi[e] ?? hi.open;
}
function _i(e, t) {
	return t(`orchestrator.status.${e}`, { defaultValue: e.replace(/_/g, " ") });
}
function vi({ status: e, size: t = "h-8 w-8", iconSize: n = "h-4 w-4" }) {
	let r = gi(e), i = r.icon;
	return /* @__PURE__ */ E("span", {
		className: `relative inline-flex shrink-0 items-center justify-center ${t}`,
		children: /* @__PURE__ */ E(i, {
			className: `${n} ${r.fg}${r.pulse ? " animate-pulse" : ""}`,
			"aria-hidden": !0
		})
	});
}
function yi({ status: e, t }) {
	let n = gi(e);
	return /* @__PURE__ */ D("span", {
		className: `inline-flex items-center gap-1.5 text-2xs font-medium ${n.fg}`,
		children: [/* @__PURE__ */ E("span", { className: `h-1.5 w-1.5 rounded-full ${n.dot}${n.pulse ? " animate-pulse" : ""}` }), _i(e, t)]
	});
}
function bi({ icon: e, children: t, tone: n = "muted" }) {
	return /* @__PURE__ */ D("span", {
		className: `inline-flex items-center gap-1 text-2xs tabular-nums ${n === "accent" ? "text-accent" : "text-muted"}`,
		children: [/* @__PURE__ */ E("span", {
			className: "inline-flex h-3 w-3 items-center justify-center",
			children: e
		}), t]
	});
}
function xi({ value: e, onChange: t, placeholder: n, inputRef: r, testId: i, className: a, agentProps: o }) {
	return /* @__PURE__ */ D("div", {
		className: `relative flex h-9 items-center border-border/35 border-b transition-colors focus-within:border-accent/60 ${a ?? "flex-1"}`,
		children: [/* @__PURE__ */ E(xe, {
			className: "pointer-events-none absolute left-1 h-3.5 w-3.5 text-muted",
			"aria-hidden": !0
		}), /* @__PURE__ */ E("input", {
			ref: r,
			value: e,
			onChange: (e) => t(e.target.value),
			placeholder: n,
			"aria-label": n,
			"data-testid": i,
			className: "h-full w-full bg-transparent pl-7 pr-1 text-sm text-txt outline-none placeholder:text-muted",
			...o
		})]
	});
}
function Si({ icon: e }) {
	return /* @__PURE__ */ E("div", {
		className: "pointer-events-none absolute bottom-6 right-4 select-none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ E(e, {
			className: "h-44 w-44 text-accent opacity-[0.05]",
			strokeWidth: 1
		})
	});
}
function Ci({ id: e, title: t, subtitle: n, status: r, chips: i, forked: a, onOpen: o, t: s }) {
	let { ref: c, agentProps: l } = B({
		id: `task-card-${e}`,
		role: "list-item",
		label: t,
		group: "task-cards",
		description: `Open the "${t}" task`
	});
	return /* @__PURE__ */ D("button", {
		ref: c,
		type: "button",
		onClick: () => o(e),
		"data-testid": "task-card",
		className: "group relative flex w-full items-start gap-2 px-1 py-2 text-left transition-colors hover:bg-bg-hover/30",
		...l,
		children: [/* @__PURE__ */ E(vi, { status: r }), /* @__PURE__ */ D("span", {
			className: "flex min-w-0 flex-1 flex-col gap-1.5",
			children: [
				/* @__PURE__ */ D("span", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ E("span", {
							className: "min-w-0 flex-1 truncate text-sm font-semibold text-txt-strong",
							children: t
						}),
						a ? /* @__PURE__ */ E(de, {
							className: "h-3.5 w-3.5 shrink-0 text-muted",
							"aria-hidden": !0
						}) : null,
						/* @__PURE__ */ E(yi, {
							status: r,
							t: s
						})
					]
				}),
				n ? /* @__PURE__ */ E("span", {
					className: "line-clamp-1 text-xs text-muted",
					children: n
				}) : null,
				/* @__PURE__ */ E("span", {
					className: "flex flex-wrap items-center gap-1.5",
					children: i
				})
			]
		})]
	});
}
function wi({ label: e, onClick: t, testId: n }) {
	let { ref: r, agentProps: i } = B({
		id: "task-back-chip",
		role: "button",
		label: e,
		group: "task-detail",
		description: "Return to the task list"
	});
	return /* @__PURE__ */ D("button", {
		ref: r,
		type: "button",
		onClick: t,
		"data-testid": n,
		className: "inline-flex items-center gap-1.5 py-1 text-xs font-medium text-muted transition-colors hover:text-txt",
		...i,
		children: [/* @__PURE__ */ E("span", {
			"aria-hidden": !0,
			children: "←"
		}), e]
	});
}
//#endregion
//#region src/use-orchestrator-data.ts
var Ti = 50, Ei = 5e3, Di = 1500;
function Oi(e, t) {
	return e instanceof Error && e.message ? e.message : t;
}
function ki(e) {
	if (e?.status === 404) return !0;
	let t = e instanceof Error ? e.message.toLowerCase() : "";
	return t === "not found" || t.includes("404");
}
function Ai(e, t) {
	if (t.length === 0) return e;
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.id, t);
	for (let e of t) n.set(e.id, e);
	return [...n.values()].sort((e, t) => e.timestamp - t.timestamp);
}
function ji(e) {
	let t = [], n = [];
	for (let r of e) r.kind === "message" ? t.push(r.message) : n.push(r.event);
	return {
		messages: t,
		events: n
	};
}
function Mi({ selectedId: e, showArchived: t, statusFilter: n, deferredSearch: r, t: i }) {
	let [a, o] = w(null), [s, c] = w([]), [l, u] = w(null), [d, f] = w([]), [p, m] = w([]), [h, _] = w(null), [v, b] = w(!0), [S, T] = w(!1), [E, D] = w(null), [O, ee] = w(!1), [k, te] = w(null), A = C(0), j = C(e);
	j.current = e;
	let M = y(async (e) => {
		e || b(!0);
		try {
			let [e, i] = await Promise.all([g.getOrchestratorStatus(), g.listCodingAgentTaskThreads({
				includeArchived: t,
				status: n === "all" ? void 0 : n,
				search: r || void 0,
				limit: 100
			})]);
			o(e), c(i), D(null), ee(!1);
		} catch (t) {
			e || (ki(t) ? (ee(!0), D(null)) : (ee(!1), D(Oi(t, i("orchestrator.loadFailed", { defaultValue: "Failed to load orchestrator state." })))));
		} finally {
			e || b(!1);
		}
	}, [
		r,
		t,
		n,
		i
	]), N = y(async (e, t) => {
		let n = ++A.current, [r, i] = await Promise.all([g.getCodingAgentTaskThread(e), g.listOrchestratorTaskTimeline(e, { limit: Ti })]);
		if (n !== A.current || e !== j.current) return;
		let a = ji(i.items);
		u(r), t ? (f(Ai([], a.messages)), m(Ai([], a.events)), _(i.nextCursor)) : (f((e) => Ai(e, a.messages)), m((e) => Ai(e, a.events)), _((e) => e ?? i.nextCursor));
	}, []);
	x(() => {
		M(!1);
		let e = window.setInterval(() => void M(!0), Ei);
		return () => window.clearInterval(e);
	}, [M]);
	let P = l !== null && (l.activeSessionCount > 0 || l.status === "active" || l.status === "validating") ? Di : Ei;
	x(() => {
		if (!e) {
			u(null), f([]), m([]), _(null);
			return;
		}
		N(e, !0).catch((e) => {
			console.error("[useOrchestratorData] fetchDetail (initial)", { err: e });
		});
	}, [e, N]), x(() => {
		if (!e) return;
		let t = window.setInterval(() => void N(e, !1).catch((e) => {
			console.error("[useOrchestratorData] fetchDetail (poll)", { err: e });
		}), P);
		return () => window.clearInterval(t);
	}, [
		e,
		P,
		N
	]);
	let F = C(null), I = y(() => {
		F.current ??= window.setTimeout(() => {
			F.current = null;
			let e = j.current;
			e && N(e, !1).catch((e) => {
				console.error("[useOrchestratorData] fetchDetail (debounced)", { err: e });
			});
		}, 150);
	}, [N]);
	return x(() => {
		if (!e) return;
		let t = g.streamOrchestratorTask(e, I);
		return () => {
			t(), F.current != null && (window.clearTimeout(F.current), F.current = null);
		};
	}, [e, I]), {
		status: a,
		tasks: s,
		detail: l,
		messages: d,
		events: p,
		timelineCursor: h,
		loading: v,
		mutating: S,
		loadError: E,
		backendAbsent: O,
		actionError: k,
		refresh: M,
		runMutation: y(async (e) => {
			T(!0), te(null);
			try {
				await e(), await M(!0);
				let t = j.current;
				t && await N(t, !1).catch((e) => {
					console.error("[useOrchestratorData] fetchDetail (mutation)", { err: e });
				});
			} catch (e) {
				te(Oi(e, i("orchestrator.actionFailed", { defaultValue: "Action failed." })));
			} finally {
				T(!1);
			}
		}, [
			M,
			N,
			i
		]),
		loadOlderTimeline: y(async () => {
			let e = j.current;
			if (!e || !h) return;
			let t = await g.listOrchestratorTaskTimeline(e, {
				cursor: h,
				limit: Ti
			});
			if (e !== j.current) return;
			let n = ji(t.items);
			f((e) => Ai(e, n.messages)), m((e) => Ai(e, n.events)), _(t.nextCursor);
		}, [h])
	};
}
//#endregion
//#region src/OrchestratorWorkbench.tsx
function Ni(e) {
	if (!e) return null;
	let t = typeof e.summary == "string" ? e.summary : null, n = Array.isArray(e.steps) ? e.steps : [], r = [];
	for (let e of n) {
		if (typeof e == "string" && e.trim()) {
			r.push({
				key: `step-${r.length}`,
				label: e.trim(),
				status: null
			});
			continue;
		}
		if (e && typeof e == "object") {
			let t = e, n = typeof t.title == "string" && t.title || typeof t.label == "string" && t.label || typeof t.description == "string" && t.description || null;
			if (!n) continue;
			r.push({
				key: `step-${r.length}`,
				label: n,
				status: typeof t.status == "string" ? t.status : null
			});
		}
	}
	return !t && r.length === 0 ? null : {
		summary: t,
		steps: r
	};
}
function Pi(e, t, n, r) {
	if (e === "unavailable") return n("orchestrator.usage.unavailable", { defaultValue: "—" });
	let i = pr(t, r);
	return e === "estimated" ? n("orchestrator.usage.estimatedTokens", {
		defaultValue: "~{{value}}",
		value: i
	}) : i;
}
function Fi(e, t, n) {
	return Pi(e.state, e.totalTokens, t, n);
}
function Ii(e, t, n) {
	if (e.state === "unavailable") return t("orchestrator.usage.unavailable", { defaultValue: "—" });
	let r = mr(e.costUsd, n);
	return e.state === "estimated" ? t("orchestrator.usage.estimatedCost", {
		defaultValue: "~{{value}}",
		value: r
	}) : r;
}
function Li({ value: e, label: t, toneClass: n = "text-txt-strong" }) {
	return /* @__PURE__ */ D("span", {
		className: "inline-flex shrink-0 items-baseline gap-1",
		title: t,
		children: [/* @__PURE__ */ E("span", {
			className: `text-sm font-semibold tabular-nums ${n}`,
			children: e
		}), /* @__PURE__ */ E("span", {
			className: "text-2xs text-muted",
			children: t
		})]
	});
}
function Q({ title: e, action: t, children: n }) {
	return /* @__PURE__ */ D("section", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ D("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ E("h3", {
				className: "text-xs font-medium text-muted",
				children: e
			}), t]
		}), n]
	});
}
function Ri({ status: e, busy: t, isMobile: n, onPauseAll: r, onResumeAll: i, accountsOpen: a, onToggleAccounts: o, t: s, locale: c }) {
	let l = /* @__PURE__ */ D("div", {
		className: "flex shrink-0 items-center gap-2",
		children: [/* @__PURE__ */ E(me, { className: "h-4 w-4 text-accent" }), /* @__PURE__ */ E("span", {
			className: "text-sm font-semibold text-txt-strong",
			children: s("orchestrator.title", { defaultValue: "Orchestrator" })
		})]
	}), d = /* @__PURE__ */ D("div", {
		className: "flex min-w-0 items-center gap-4 overflow-x-auto",
		style: n ? void 0 : { flex: "1 1 0%" },
		children: [
			/* @__PURE__ */ E(Li, {
				value: String(e?.taskCount ?? 0),
				label: "tasks"
			}),
			e?.activeTaskCount ? /* @__PURE__ */ E(Li, {
				value: String(e.activeTaskCount),
				label: "active",
				toneClass: "text-ok"
			}) : null,
			e?.blockedTaskCount ? /* @__PURE__ */ E(Li, {
				value: String(e.blockedTaskCount),
				label: "blocked",
				toneClass: "text-warn"
			}) : null,
			e?.validatingTaskCount ? /* @__PURE__ */ E(Li, {
				value: String(e.validatingTaskCount),
				label: "validating",
				toneClass: "text-accent"
			}) : null,
			e?.activeSessionCount ? /* @__PURE__ */ E(Li, {
				value: `${e.activeSessionCount}/${e.sessionCount}`,
				label: "agents"
			}) : null
		]
	}), f = e && e.usage.state !== "unavailable" ? /* @__PURE__ */ D("span", {
		className: "flex shrink-0 items-center gap-1.5 text-xs tabular-nums text-muted",
		title: s("orchestrator.stat.usage", { defaultValue: "Usage" }),
		children: [
			/* @__PURE__ */ E(ue, { className: "h-3 w-3 text-muted/70" }),
			Fi(e.usage, s, c),
			/* @__PURE__ */ E("span", {
				className: "text-muted/50",
				children: "·"
			}),
			Ii(e.usage, s, c)
		]
	}) : null, p = s("orchestrator.action.pauseAll", { defaultValue: "Pause all" }), m = s("orchestrator.action.resumeAll", { defaultValue: "Resume all" }), { ref: h, agentProps: g } = B({
		id: "header-pause-all",
		role: "button",
		label: p,
		group: "orchestrator-header",
		description: "Pause every active orchestrator task"
	}), { ref: _, agentProps: v } = B({
		id: "header-resume-all",
		role: "button",
		label: m,
		group: "orchestrator-header",
		description: "Resume every paused orchestrator task"
	}), y = s("orchestrator.toggleAccounts", { defaultValue: "Coding accounts & pool health" }), b = /* @__PURE__ */ E(u, {
		variant: "ghost",
		size: "sm",
		onClick: o,
		className: "h-7 w-7 shrink-0 p-0",
		"aria-label": y,
		"aria-pressed": a,
		title: y,
		"data-testid": "orchestrator-accounts-toggle",
		children: /* @__PURE__ */ E(ue, { className: "h-3.5 w-3.5" })
	}), x = e?.activeTaskCount || e?.pausedTaskCount ? /* @__PURE__ */ D("div", {
		className: "ml-auto flex shrink-0 items-center gap-1.5",
		children: [e?.activeTaskCount ? /* @__PURE__ */ E(u, {
			ref: h,
			variant: "ghost",
			size: "sm",
			disabled: t,
			onClick: r,
			className: "h-7 w-7 p-0",
			"aria-label": p,
			title: p,
			"data-testid": "orchestrator-pause-all",
			...g,
			children: /* @__PURE__ */ E(_e, { className: "h-3.5 w-3.5" })
		}) : null, e?.pausedTaskCount ? /* @__PURE__ */ E(u, {
			ref: _,
			variant: "ghost",
			size: "sm",
			disabled: t,
			onClick: i,
			className: "h-7 w-7 p-0",
			"aria-label": m,
			title: m,
			"data-testid": "orchestrator-resume-all",
			...v,
			children: /* @__PURE__ */ E(ve, { className: "h-3.5 w-3.5" })
		}) : null]
	}) : null;
	return n ? /* @__PURE__ */ D("header", {
		className: "flex flex-col gap-2 bg-bg px-4 py-2.5",
		children: [/* @__PURE__ */ D("div", {
			className: "flex items-center gap-2",
			children: [l, /* @__PURE__ */ D("div", {
				className: "ml-auto flex items-center gap-1.5",
				children: [b, x]
			})]
		}), /* @__PURE__ */ D("div", {
			className: "flex items-center justify-between gap-2",
			children: [d, f]
		})]
	}) : /* @__PURE__ */ D("header", {
		className: "flex items-center gap-4 bg-bg px-4 py-2.5",
		children: [
			l,
			d,
			f,
			b,
			x
		]
	});
}
function zi({ status: e, active: t, onSelect: n, t: r }) {
	let i = (t) => e ? t === "all" ? e.taskCount : e.byStatus[t] ?? 0 : 0, a = r("orchestrator.filter.label", { defaultValue: "Filter by status" }), { ref: o, agentProps: s } = B({
		id: "rail-filter-status",
		role: "select",
		label: a,
		group: "orchestrator-rail",
		description: "Filter the task list by status",
		options: ri,
		getValue: () => t,
		onFill: (e) => {
			ri.includes(e) && n(e);
		}
	}), c = (e) => e === "all" ? r("orchestrator.filter.all", { defaultValue: "All" }) : ai(e, r);
	return /* @__PURE__ */ D(Me, {
		value: t,
		onValueChange: (e) => n(e),
		children: [/* @__PURE__ */ E(Fe, {
			ref: o,
			"aria-label": a,
			"data-testid": "orchestrator-filter",
			className: "h-9 border-0 bg-transparent px-1 text-xs",
			...s,
			children: /* @__PURE__ */ D("span", {
				className: "flex items-center gap-2",
				children: [t === "all" ? /* @__PURE__ */ E("span", {
					className: "text-txt",
					children: c("all")
				}) : /* @__PURE__ */ E(yi, {
					status: t,
					t: r
				}), /* @__PURE__ */ D("span", {
					className: "text-muted tabular-nums",
					children: [
						"(",
						i(t),
						")"
					]
				})]
			})
		}), /* @__PURE__ */ E(Ne, { children: ri.map((e) => /* @__PURE__ */ E(Pe, {
			value: e,
			className: "text-xs",
			children: /* @__PURE__ */ D("span", {
				className: "flex items-center gap-2",
				children: [e === "all" ? /* @__PURE__ */ E("span", { children: c("all") }) : /* @__PURE__ */ E(yi, {
					status: e,
					t: r
				}), /* @__PURE__ */ D("span", {
					className: "text-muted tabular-nums",
					children: [
						"(",
						i(e),
						")"
					]
				})]
			})
		}, e)) })]
	});
}
function Bi(e, t, n) {
	let r = e.latestActivityAt == null ? dr(e.updatedAt, n, t("orchestrator.unknown", { defaultValue: "—" })) : ur(e.latestActivityAt, n), i = Yr[e.priority];
	return /* @__PURE__ */ D(T, { children: [
		e.sessionCount > 0 ? /* @__PURE__ */ E(bi, {
			icon: /* @__PURE__ */ E(te, { className: "h-3 w-3" }),
			tone: e.activeSessionCount > 0 ? "accent" : "muted",
			children: t("orchestrator.chip.agents", {
				defaultValue: "{{active}}/{{total}} agents",
				active: e.activeSessionCount,
				total: e.sessionCount
			})
		}) : null,
		e.paused ? /* @__PURE__ */ E(bi, {
			icon: /* @__PURE__ */ E(_e, { className: "h-3 w-3" }),
			children: t("orchestrator.status.paused", { defaultValue: "Paused" })
		}) : null,
		i && e.priority !== "normal" ? /* @__PURE__ */ E(bi, {
			icon: /* @__PURE__ */ E(i, { className: "h-3 w-3" }),
			children: oi(e.priority, t)
		}) : null,
		/* @__PURE__ */ E("span", {
			className: "text-2xs text-muted/80",
			children: r
		})
	] });
}
function Vi({ session: e, busy: t, onInspect: n, onStop: r, t: i, locale: a }) {
	let o = e.stoppedAt == null && e.status !== "completed", s = [e.framework, e.model].filter((e) => !!e).join(" · "), c = e.repo || e.workdir || i("orchestrator.noWorkspace", { defaultValue: "None" }), l = i("orchestrator.action.stopAgent", { defaultValue: "Stop agent" }), u = i("orchestrator.action.inspectAgent", { defaultValue: "Inspect agent" }), { ref: d, agentProps: f } = B({
		id: `sub-agent-inspect-${e.sessionId}`,
		role: "button",
		label: `${u}: ${e.label}`,
		group: "orchestrator-sub-agents",
		description: `Open recovery and event details for the "${e.label}" sub-agent`
	}), { ref: p, agentProps: m } = B({
		id: `sub-agent-stop-${e.sessionId}`,
		role: "button",
		label: `${l}: ${e.label}`,
		group: "orchestrator-sub-agents",
		description: `Stop the "${e.label}" sub-agent`
	});
	return /* @__PURE__ */ D("div", {
		className: "py-1",
		children: [
			/* @__PURE__ */ D("div", {
				className: "flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ E(li, {
						status: e.status,
						t: i
					}),
					/* @__PURE__ */ E("span", {
						className: "min-w-0 flex-1 truncate text-xs font-medium text-txt",
						children: e.label
					}),
					/* @__PURE__ */ E("button", {
						ref: d,
						type: "button",
						onClick: () => n(e.sessionId),
						className: "flex items-center gap-0.5 px-1 py-0.5 text-2xs text-muted transition-colors hover:text-txt",
						"data-testid": "orchestrator-inspect-session",
						"aria-label": u,
						title: u,
						...f,
						children: /* @__PURE__ */ E(ge, { className: "h-3 w-3" })
					}),
					o ? /* @__PURE__ */ E("button", {
						ref: p,
						type: "button",
						disabled: t,
						onClick: () => r(e.sessionId),
						className: "flex items-center gap-0.5 px-1 py-0.5 text-2xs text-muted transition-colors hover:text-danger disabled:opacity-50",
						"data-testid": "orchestrator-stop-agent",
						"aria-label": l,
						...m,
						children: /* @__PURE__ */ E(ae, { className: "h-3 w-3" })
					}) : null
				]
			}),
			s ? /* @__PURE__ */ E("div", {
				className: "mt-0.5 truncate text-2xs text-muted",
				children: s
			}) : null,
			/* @__PURE__ */ D("div", {
				className: "mt-0.5 flex items-center gap-2 text-2xs text-muted",
				children: [e.activeTool ? /* @__PURE__ */ E("span", {
					className: "truncate text-warn",
					children: e.activeTool
				}) : null, /* @__PURE__ */ E("span", {
					className: "ml-auto tabular-nums",
					children: Pi(e.usageState, e.totalTokens, i, a)
				})]
			}),
			/* @__PURE__ */ E("div", {
				className: "mt-0.5 truncate text-2xs text-muted/80",
				children: c
			})
		]
	});
}
function Hi({ plan: e, t }) {
	return /* @__PURE__ */ D(Q, {
		title: t("orchestrator.plan", { defaultValue: "Plan" }),
		children: [e.summary ? /* @__PURE__ */ E("p", {
			className: "mb-2 text-xs-tight text-txt",
			children: e.summary
		}) : null, e.steps.length > 0 ? /* @__PURE__ */ E("ol", {
			className: "space-y-1",
			children: e.steps.map((e, n) => /* @__PURE__ */ D("li", {
				className: "flex items-start gap-1.5 text-xs-tight text-txt",
				children: [
					/* @__PURE__ */ D("span", {
						className: "mt-px shrink-0 tabular-nums text-muted",
						children: [n + 1, "."]
					}),
					/* @__PURE__ */ E("span", {
						className: "min-w-0 flex-1",
						children: e.label
					}),
					e.status ? /* @__PURE__ */ E(di, {
						status: e.status,
						t
					}) : null
				]
			}, e.key))
		}) : null]
	});
}
function Ui({ plan: e, latestPlanRevisionId: t, busy: n, onSubmit: r, t: i }) {
	let a = S(() => JSON.stringify(e, null, 2), [e]), [o, s] = w(!1), [c, l] = w(a), [d, f] = w(""), [p, m] = w(null), h = i("orchestrator.action.editPlan", { defaultValue: "Edit plan" }), g = i("orchestrator.action.restartWithPlan", { defaultValue: "Restart with plan" }), _ = i("orchestrator.planEdit.summary", { defaultValue: "Edit summary" }), v = i("orchestrator.planEdit.draft", { defaultValue: "Plan JSON" }), y = i("orchestrator.planEdit.base", { defaultValue: "Base revision" }), b = i("orchestrator.planEdit.currentPlan", { defaultValue: "Current plan" }), { ref: C, agentProps: T } = B({
		id: "inspector-plan-edit-toggle",
		role: "button",
		label: h,
		group: "orchestrator-inspector",
		description: "Open the plan JSON editor"
	}), { ref: O, agentProps: ee } = B({
		id: "inspector-restart-edited-plan",
		role: "button",
		label: g,
		group: "orchestrator-inspector",
		description: "Restart this task with the edited plan"
	});
	x(() => {
		l(a), f(""), m(null);
	}, [a]);
	let k = () => {
		let e;
		try {
			e = JSON.parse(c);
		} catch {
			m(i("orchestrator.planEdit.invalidJson", { defaultValue: "Plan must be valid JSON." }));
			return;
		}
		if (!e || typeof e != "object" || Array.isArray(e)) {
			m(i("orchestrator.planEdit.invalidObject", { defaultValue: "Plan must be a JSON object." }));
			return;
		}
		(typeof window > "u" || window.confirm(i("orchestrator.confirmRestartWithPlan", { defaultValue: "Restart this task with the edited plan? Active agents will be stopped first." }))) && (m(null), r({
			plan: e,
			basePlanRevisionId: t,
			editSummary: d.trim() || void 0,
			stopActive: !0
		}));
	};
	return /* @__PURE__ */ D(Q, {
		title: i("orchestrator.planEdit.title", { defaultValue: "Plan editor" }),
		children: [/* @__PURE__ */ D("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ D("div", {
				className: "min-w-0 text-2xs text-muted",
				children: [/* @__PURE__ */ E("span", {
					className: "font-semibold text-muted-strong",
					children: y
				}), /* @__PURE__ */ E("span", {
					className: "ml-1 truncate",
					children: t ?? b
				})]
			}), /* @__PURE__ */ D("button", {
				ref: C,
				type: "button",
				disabled: n,
				onClick: () => s((e) => !e),
				className: "inline-flex h-7 shrink-0 items-center gap-1.5 px-1 text-2xs font-semibold text-muted transition-colors hover:text-txt disabled:opacity-50",
				"data-testid": "orchestrator-plan-edit-toggle",
				...T,
				children: [E(o ? P : M, { className: "h-3 w-3" }), h]
			})]
		}), o ? /* @__PURE__ */ D("div", {
			className: "mt-2 space-y-2",
			children: [
				/* @__PURE__ */ D("label", {
					className: "block",
					children: [/* @__PURE__ */ E(Ji, { children: _ }), /* @__PURE__ */ E("input", {
						value: d,
						onChange: (e) => f(e.target.value),
						className: qi,
						placeholder: i("orchestrator.planEdit.summaryPlaceholder", { defaultValue: "What changed" }),
						"data-testid": "orchestrator-plan-edit-summary"
					})]
				}),
				/* @__PURE__ */ D("label", {
					className: "block",
					children: [/* @__PURE__ */ E(Ji, { children: v }), /* @__PURE__ */ E("textarea", {
						value: c,
						onChange: (e) => l(e.target.value),
						rows: 8,
						className: `${qi} resize-y font-mono leading-relaxed`,
						spellCheck: !1,
						"data-testid": "orchestrator-plan-draft"
					})]
				}),
				p ? /* @__PURE__ */ E("p", {
					className: "text-2xs text-danger",
					children: p
				}) : null,
				/* @__PURE__ */ E("div", {
					className: "flex justify-end",
					children: /* @__PURE__ */ D(u, {
						ref: O,
						type: "button",
						size: "sm",
						disabled: n,
						onClick: k,
						className: "h-7 gap-1.5 px-2.5 text-xs-tight",
						"data-testid": "orchestrator-plan-restart",
						...ee,
						children: [/* @__PURE__ */ E(ye, { className: "h-3 w-3" }), g]
					})
				})
			]
		}) : null]
	});
}
function Wi({ criteria: e, t }) {
	return /* @__PURE__ */ E(Q, {
		title: t("orchestrator.acceptance", { defaultValue: "Acceptance" }),
		children: /* @__PURE__ */ E("ul", {
			className: "space-y-1",
			children: e.map((e, t) => /* @__PURE__ */ D("li", {
				className: "flex items-start gap-1.5 text-xs-tight text-txt",
				children: [/* @__PURE__ */ E("span", { className: "mt-1 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-accent/60" }), /* @__PURE__ */ E("span", { children: e })]
			}, `${e}-${t}`))
		})
	});
}
function Gi({ artifacts: e, t }) {
	return /* @__PURE__ */ E(Q, {
		title: t("orchestrator.artifacts", { defaultValue: "Artifacts" }),
		children: /* @__PURE__ */ E("div", {
			className: "space-y-1.5",
			children: e.map((e) => /* @__PURE__ */ D("div", {
				className: "text-xs-tight",
				children: [/* @__PURE__ */ D("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ E("span", {
						className: "min-w-0 flex-1 truncate font-medium text-txt",
						children: e.title
					}), /* @__PURE__ */ E(ui, {
						status: e.verificationStatus,
						t
					})]
				}), /* @__PURE__ */ D("div", {
					className: "truncate text-muted",
					children: [e.artifactType, e.path || e.uri ? ` · ${e.path ?? e.uri}` : ""]
				})]
			}, e.id))
		})
	});
}
function Ki({ usage: e, t, locale: n }) {
	return /* @__PURE__ */ D(Q, {
		title: t("orchestrator.usage.title", { defaultValue: "Tokens & cost" }),
		children: [/* @__PURE__ */ D("div", {
			className: "mb-2 flex items-center gap-3 text-xs",
			children: [/* @__PURE__ */ D("span", {
				className: "text-txt",
				children: [
					/* @__PURE__ */ E("span", {
						className: "font-semibold tabular-nums",
						children: Fi(e, t, n)
					}),
					" ",
					/* @__PURE__ */ E("span", {
						className: "text-muted",
						children: t("orchestrator.usage.tokens", { defaultValue: "tokens" })
					})
				]
			}), /* @__PURE__ */ E("span", {
				className: "text-txt",
				children: /* @__PURE__ */ E("span", {
					className: "font-semibold tabular-nums",
					children: Ii(e, t, n)
				})
			})]
		}), e.byProvider.length > 1 ? /* @__PURE__ */ E("div", {
			className: "space-y-1",
			children: e.byProvider.map((e) => /* @__PURE__ */ D("div", {
				className: "flex items-center gap-2 text-2xs text-muted",
				children: [
					/* @__PURE__ */ D("span", {
						className: "min-w-0 flex-1 truncate",
						children: [e.provider, e.model ? ` · ${e.model}` : ""]
					}),
					/* @__PURE__ */ E("span", {
						className: "shrink-0 tabular-nums",
						children: Pi(e.state, e.totalTokens, t, n)
					}),
					/* @__PURE__ */ E("span", {
						className: "shrink-0 tabular-nums",
						children: e.state === "unavailable" ? t("orchestrator.usage.unavailable", { defaultValue: "—" }) : mr(e.costUsd, n)
					})
				]
			}, `${e.provider}-${e.model ?? "default"}`))
		}) : null]
	});
}
var qi = "w-full border-border/35 border-b bg-transparent px-1 py-1.5 text-xs text-txt outline-none transition-colors placeholder:text-muted focus:border-accent/60";
function Ji({ children: e }) {
	return /* @__PURE__ */ E("span", {
		className: "mb-1 block text-xs font-medium text-muted",
		children: e
	});
}
function Yi({ busy: e, onClose: t, onSubmit: n, t: r }) {
	let [i, a] = w(""), [o, s] = w(""), [c, l] = w(""), [d, f] = w(""), [p, m] = w(""), [h, g] = w(""), _ = {
		label: r("orchestrator.addAgent.label", { defaultValue: "Label (optional)" }),
		framework: r("orchestrator.addAgent.framework", { defaultValue: "Framework" }),
		model: r("orchestrator.addAgent.model", { defaultValue: "Model" }),
		workdir: r("orchestrator.addAgent.workdir", { defaultValue: "Workdir (optional)" }),
		repo: r("orchestrator.addAgent.repo", { defaultValue: "Repo URL (optional)" }),
		task: r("orchestrator.addAgent.task", { defaultValue: "Sub-task for this agent (optional)" })
	}, v = r("orchestrator.action.spawn", { defaultValue: "Spawn agent" }), y = r("orchestrator.action.cancel", { defaultValue: "Cancel" }), b = () => n({
		label: i.trim() || void 0,
		framework: o.trim() || void 0,
		model: c.trim() || void 0,
		workdir: d.trim() || void 0,
		repo: p.trim() || void 0,
		task: h.trim() || void 0
	}), { ref: x, agentProps: S } = B({
		id: "add-agent-label",
		role: "text-input",
		label: _.label,
		group: "orchestrator-add-agent",
		description: "Optional label for the spawned sub-agent",
		getValue: () => i,
		onFill: (e) => a(e)
	}), { ref: C, agentProps: T } = B({
		id: "add-agent-framework",
		role: "text-input",
		label: _.framework,
		group: "orchestrator-add-agent",
		description: "Coding-agent framework for the sub-agent",
		getValue: () => o,
		onFill: (e) => s(e)
	}), { ref: O, agentProps: ee } = B({
		id: "add-agent-model",
		role: "text-input",
		label: _.model,
		group: "orchestrator-add-agent",
		description: "Model for the sub-agent",
		getValue: () => c,
		onFill: (e) => l(e)
	}), { ref: k, agentProps: te } = B({
		id: "add-agent-workdir",
		role: "text-input",
		label: _.workdir,
		group: "orchestrator-add-agent",
		description: "Optional working directory for the sub-agent",
		getValue: () => d,
		onFill: (e) => f(e)
	}), { ref: A, agentProps: j } = B({
		id: "add-agent-repo",
		role: "text-input",
		label: _.repo,
		group: "orchestrator-add-agent",
		description: "Optional repo URL for the sub-agent",
		getValue: () => p,
		onFill: (e) => m(e)
	}), { ref: M, agentProps: N } = B({
		id: "add-agent-task",
		role: "textarea",
		label: _.task,
		group: "orchestrator-add-agent",
		description: "Optional sub-task description for the sub-agent",
		getValue: () => h,
		onFill: (e) => g(e)
	}), { ref: P, agentProps: F } = B({
		id: "add-agent-cancel",
		role: "button",
		label: y,
		group: "orchestrator-add-agent",
		description: "Cancel adding a sub-agent"
	}), { ref: I, agentProps: ne } = B({
		id: "add-agent-spawn",
		role: "button",
		label: v,
		group: "orchestrator-add-agent",
		description: "Spawn a new sub-agent on this task",
		onActivate: () => {
			e || b();
		}
	});
	return /* @__PURE__ */ D("div", {
		className: "mt-1.5 space-y-1.5",
		children: [
			/* @__PURE__ */ E("input", {
				ref: x,
				value: i,
				onChange: (e) => a(e.target.value),
				className: qi,
				placeholder: _.label,
				"aria-label": _.label,
				"data-testid": "orchestrator-add-agent-label",
				...S
			}),
			/* @__PURE__ */ D("div", {
				className: "flex gap-1.5",
				children: [/* @__PURE__ */ E("input", {
					ref: C,
					value: o,
					onChange: (e) => s(e.target.value),
					className: qi,
					placeholder: _.framework,
					"aria-label": _.framework,
					...T
				}), /* @__PURE__ */ E("input", {
					ref: O,
					value: c,
					onChange: (e) => l(e.target.value),
					className: qi,
					placeholder: _.model,
					"aria-label": _.model,
					...ee
				})]
			}),
			/* @__PURE__ */ E("input", {
				ref: k,
				value: d,
				onChange: (e) => f(e.target.value),
				className: qi,
				placeholder: _.workdir,
				"aria-label": _.workdir,
				...te
			}),
			/* @__PURE__ */ E("input", {
				ref: A,
				value: p,
				onChange: (e) => m(e.target.value),
				className: qi,
				placeholder: _.repo,
				"aria-label": _.repo,
				...j
			}),
			/* @__PURE__ */ E("textarea", {
				ref: M,
				value: h,
				onChange: (e) => g(e.target.value),
				rows: 2,
				className: `${qi} resize-none`,
				placeholder: _.task,
				"aria-label": _.task,
				...N
			}),
			/* @__PURE__ */ D("div", {
				className: "flex justify-end gap-2",
				children: [/* @__PURE__ */ E(u, {
					ref: P,
					variant: "secondary",
					size: "sm",
					onClick: t,
					className: "h-6 px-2 text-2xs",
					...F,
					children: y
				}), /* @__PURE__ */ E(u, {
					ref: I,
					size: "sm",
					disabled: e,
					onClick: b,
					className: "h-6 px-2 text-2xs",
					"data-testid": "orchestrator-add-agent-submit",
					...ne,
					children: v
				})]
			})
		]
	});
}
function Xi({ agentId: e, description: t, icon: n, label: r, onClick: i, disabled: a, tone: o = "neutral", testId: s }) {
	let { ref: c, agentProps: l } = B({
		id: e,
		role: "button",
		label: r,
		group: "orchestrator-inspector",
		description: t
	});
	return /* @__PURE__ */ E("button", {
		ref: c,
		type: "button",
		disabled: a,
		onClick: i,
		"aria-label": r,
		title: r,
		className: `flex items-center justify-center p-1.5 transition-colors disabled:opacity-50 ${o === "danger" ? "text-muted hover:text-danger" : "text-muted hover:text-txt"}`,
		"data-testid": s,
		...l,
		children: n
	});
}
function Zi({ agentId: e, description: t, icon: n, label: r, onClick: i, disabled: a, testId: o }) {
	let { ref: s, agentProps: c } = B({
		id: e,
		role: "button",
		label: r,
		group: "orchestrator-operator-detail",
		description: t
	});
	return /* @__PURE__ */ D("button", {
		ref: s,
		type: "button",
		disabled: a,
		onClick: i,
		className: "inline-flex h-7 items-center gap-1.5 px-1 text-2xs font-semibold text-muted transition-colors hover:text-txt disabled:opacity-50",
		"data-testid": o,
		...c,
		children: [n, r]
	});
}
function Qi({ detail: l, className: u, style: d, onClose: f, busy: p, addAgentOpen: h, onPause: g, onResume: _, onArchive: v, onReopen: y, onDelete: b, onFork: x, onRestart: S, onRestartWithEditedPlan: C, onValidate: w, onSetPriority: ee, onToggleAddAgent: k, onAddAgent: te, onInspectSession: A, onStopAgent: M, onCopyLink: N, t: P, locale: F }) {
	let I = Ni(l.currentPlan), ne = [...l.sessions].sort((e, t) => t.lastActivityAt - e.lastActivityAt), L = ne.map((e) => ta(e.metadata)).find((e) => e !== void 0), re = [...l.artifacts].reverse().slice(0, 12), ie = l.planRevisions.length > 0 ? l.planRevisions[l.planRevisions.length - 1]?.id : void 0, ae = l.status === "archived", R = Jr.has(l.status), se = l.providerPolicy ? [
		l.providerPolicy.preferredFramework,
		l.providerPolicy.providerSource,
		l.providerPolicy.model
	].filter((e) => !!e).join(" · ") : "", ce = P("orchestrator.action.closeDetails", { defaultValue: "Close details" }), le = P("orchestrator.action.setPriority", { defaultValue: "Set priority" }), { ref: ue, agentProps: de } = B({
		id: "inspector-close",
		role: "button",
		label: ce,
		group: "orchestrator-inspector",
		description: "Close the task details panel"
	}), { ref: pe, agentProps: me } = B({
		id: "inspector-priority",
		role: "select",
		label: le,
		group: "orchestrator-inspector",
		description: "Set the priority of this task",
		options: [
			"low",
			"normal",
			"high",
			"urgent"
		],
		getValue: () => l.priority,
		onFill: (e) => {
			let t = ct(e);
			t && t !== l.priority && ee(t);
		}
	});
	return /* @__PURE__ */ D("div", {
		className: `shrink-0 flex-col gap-4 overflow-y-auto bg-bg p-3 ${u ?? "flex w-80"}`,
		style: d,
		"data-testid": "orchestrator-inspector",
		children: [
			f ? /* @__PURE__ */ D("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ E("h3", {
					className: "text-xs font-medium text-muted",
					children: P("orchestrator.inspector.title", { defaultValue: "Details" })
				}), /* @__PURE__ */ E("button", {
					ref: ue,
					type: "button",
					onClick: f,
					className: "-mr-1 p-1 text-muted transition-colors hover:text-txt",
					"aria-label": ce,
					"data-testid": "orchestrator-close-inspector",
					...de,
					children: /* @__PURE__ */ E(je, { className: "h-4 w-4" })
				})]
			}) : null,
			/* @__PURE__ */ D("div", {
				className: "flex flex-wrap gap-1",
				children: [
					l.status === "validating" ? /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E(Xi, {
						agentId: "inspector-approve",
						description: "Approve the task validation",
						icon: /* @__PURE__ */ E(j, { className: "h-3 w-3" }),
						label: P("orchestrator.action.approve", { defaultValue: "Approve" }),
						onClick: () => w(!0),
						disabled: p,
						testId: "orchestrator-approve"
					}), /* @__PURE__ */ E(Xi, {
						agentId: "inspector-reject",
						description: "Reject the task validation",
						icon: /* @__PURE__ */ E(je, { className: "h-3 w-3" }),
						label: P("orchestrator.action.reject", { defaultValue: "Reject" }),
						onClick: () => w(!1),
						disabled: p,
						tone: "danger",
						testId: "orchestrator-reject"
					})] }) : null,
					ae ? /* @__PURE__ */ E(Xi, {
						agentId: "inspector-reopen",
						description: "Reopen this archived task",
						icon: /* @__PURE__ */ E(ye, { className: "h-3 w-3" }),
						label: P("orchestrator.action.reopen", { defaultValue: "Reopen" }),
						onClick: y,
						disabled: p,
						testId: "orchestrator-reopen"
					}) : R ? null : l.paused ? /* @__PURE__ */ E(Xi, {
						agentId: "inspector-resume",
						description: "Resume this paused task",
						icon: /* @__PURE__ */ E(ve, { className: "h-3 w-3" }),
						label: P("orchestrator.action.resume", { defaultValue: "Resume" }),
						onClick: _,
						disabled: p,
						testId: "orchestrator-inspector-resume"
					}) : /* @__PURE__ */ E(Xi, {
						agentId: "inspector-pause",
						description: "Pause this task",
						icon: /* @__PURE__ */ E(_e, { className: "h-3 w-3" }),
						label: P("orchestrator.action.pause", { defaultValue: "Pause" }),
						onClick: g,
						disabled: p,
						testId: "orchestrator-inspector-pause"
					}),
					ae ? null : /* @__PURE__ */ E(Xi, {
						agentId: "inspector-archive",
						description: "Archive this task",
						icon: /* @__PURE__ */ E(O, { className: "h-3 w-3" }),
						label: P("orchestrator.action.archive", { defaultValue: "Archive" }),
						onClick: v,
						disabled: p,
						testId: "orchestrator-inspector-archive"
					}),
					R ? null : /* @__PURE__ */ E(Xi, {
						agentId: "inspector-fork",
						description: "Fork this task into a new task",
						icon: /* @__PURE__ */ E(fe, { className: "h-3 w-3" }),
						label: P("orchestrator.action.fork", { defaultValue: "Fork" }),
						onClick: x,
						disabled: p,
						testId: "orchestrator-fork"
					}),
					R ? null : /* @__PURE__ */ E(Xi, {
						agentId: "inspector-restart",
						description: "Restart this task with a fresh worker",
						icon: /* @__PURE__ */ E(ye, { className: "h-3 w-3" }),
						label: P("orchestrator.action.restart", { defaultValue: "Restart" }),
						onClick: S,
						disabled: p,
						testId: "orchestrator-inspector-restart"
					}),
					R ? null : /* @__PURE__ */ E(Xi, {
						agentId: "inspector-add-agent",
						description: "Open the add-agent form for this task",
						icon: /* @__PURE__ */ E(Oe, { className: "h-3 w-3" }),
						label: P("orchestrator.action.addAgent", { defaultValue: "Add agent" }),
						onClick: k,
						disabled: p,
						testId: "orchestrator-add-agent"
					}),
					/* @__PURE__ */ E(Xi, {
						agentId: "inspector-copy-link",
						description: "Copy a deep link to this task",
						icon: /* @__PURE__ */ E(oe, { className: "h-3 w-3" }),
						label: P("orchestrator.action.copyLink", { defaultValue: "Copy link" }),
						onClick: N,
						disabled: p,
						testId: "orchestrator-copy-link"
					}),
					R ? null : /* @__PURE__ */ D("select", {
						ref: pe,
						"aria-label": le,
						value: l.priority,
						disabled: p,
						onChange: (e) => {
							let t = ct(e.target.value);
							t && t !== l.priority && ee(t);
						},
						className: "border-border/35 border-b bg-transparent px-1 py-1 text-2xs text-muted transition-colors hover:border-accent/60 hover:text-txt disabled:opacity-50",
						"data-testid": "orchestrator-priority-select",
						...me,
						children: [
							/* @__PURE__ */ E("option", {
								value: "low",
								children: oi("low", P)
							}),
							/* @__PURE__ */ E("option", {
								value: "normal",
								children: oi("normal", P)
							}),
							/* @__PURE__ */ E("option", {
								value: "high",
								children: oi("high", P)
							}),
							/* @__PURE__ */ E("option", {
								value: "urgent",
								children: oi("urgent", P)
							})
						]
					}),
					/* @__PURE__ */ D(e, { children: [/* @__PURE__ */ E(c, {
						asChild: !0,
						children: /* @__PURE__ */ E(Xi, {
							agentId: "inspector-delete",
							description: "Delete this task",
							icon: /* @__PURE__ */ E(De, { className: "h-3 w-3" }),
							label: P("orchestrator.action.delete", { defaultValue: "Delete" }),
							onClick: () => {},
							disabled: p,
							tone: "danger",
							testId: "orchestrator-delete"
						})
					}), /* @__PURE__ */ D(r, { children: [/* @__PURE__ */ D(o, { children: [/* @__PURE__ */ E(s, { children: P("orchestrator.confirmDeleteTitle", { defaultValue: "Delete task?" }) }), /* @__PURE__ */ E(i, { children: P("orchestrator.confirmDelete", { defaultValue: "Delete this task and its transcript? This can't be undone." }) })] }), /* @__PURE__ */ D(a, { children: [/* @__PURE__ */ E(n, { children: P("orchestrator.action.cancel", { defaultValue: "Cancel" }) }), /* @__PURE__ */ E(t, {
						onClick: b,
						className: "bg-red-600 hover:bg-red-700",
						children: P("orchestrator.action.delete", { defaultValue: "Delete" })
					})] })] })] })
				]
			}),
			h && !R ? /* @__PURE__ */ E(Yi, {
				busy: p,
				onClose: k,
				onSubmit: te,
				t: P
			}) : null,
			/* @__PURE__ */ D(Q, {
				title: P("orchestrator.goal", { defaultValue: "Goal" }),
				children: [/* @__PURE__ */ E("p", {
					className: "whitespace-pre-wrap text-xs-tight text-txt",
					children: l.goal || l.originalRequest
				}), l.parentTaskId ? /* @__PURE__ */ E("p", {
					className: "mt-1.5 text-2xs text-muted",
					children: P("orchestrator.forkedFrom", {
						defaultValue: "Forked from {{id}}",
						id: l.parentTaskId
					})
				}) : null]
			}),
			/* @__PURE__ */ E(Q, {
				title: P("orchestrator.subAgents", { defaultValue: "Sub-agents" }),
				children: ne.length === 0 ? /* @__PURE__ */ E("p", {
					className: "text-xs-tight text-muted",
					children: P("orchestrator.noSubAgents", { defaultValue: "No sub-agents spawned yet." })
				}) : /* @__PURE__ */ E("div", {
					className: "space-y-1.5",
					children: ne.map((e) => /* @__PURE__ */ E(Vi, {
						session: e,
						busy: p,
						onInspect: A,
						onStop: M,
						t: P,
						locale: F
					}, e.id))
				})
			}),
			L ? /* @__PURE__ */ E(Q, {
				title: P("orchestrator.changes", { defaultValue: "Changes" }),
				children: /* @__PURE__ */ E(m, { changeSet: L })
			}) : null,
			I ? /* @__PURE__ */ E(Hi, {
				plan: I,
				t: P
			}) : null,
			l.currentPlan && !R ? /* @__PURE__ */ E(Ui, {
				plan: l.currentPlan,
				latestPlanRevisionId: ie,
				busy: p,
				onSubmit: C,
				t: P
			}) : null,
			l.acceptanceCriteria.length > 0 ? /* @__PURE__ */ E(Wi, {
				criteria: l.acceptanceCriteria,
				t: P
			}) : null,
			re.length > 0 ? /* @__PURE__ */ E(Gi, {
				artifacts: re,
				t: P
			}) : null,
			/* @__PURE__ */ E(Ki, {
				usage: l.usage,
				t: P,
				locale: F
			}),
			se ? /* @__PURE__ */ E(Q, {
				title: P("orchestrator.providerPolicy", { defaultValue: "Provider policy" }),
				children: /* @__PURE__ */ E("p", {
					className: "text-xs-tight text-txt",
					children: se
				})
			}) : null
		]
	});
}
function $i(e, t = 6e3) {
	return e.length <= t ? e : `${e.slice(0, t).trimEnd()}\n\n… ${(e.length - t).toLocaleString()} characters truncated`;
}
function ea(e) {
	return !!(e && Object.keys(e).length > 0);
}
function ta(e) {
	let t = e.lastChangeSet;
	if (!t || typeof t != "object") return;
	let n = t;
	if (Array.isArray(n.changedFiles) && typeof n.diff == "string" && typeof n.diffStat == "string" && typeof n.truncated == "boolean" && typeof n.capturedAt == "number") return n;
}
function na({ value: e, emptyLabel: t }) {
	return e == null || Array.isArray(e) && e.length === 0 || typeof e == "object" && !Array.isArray(e) && Object.keys(e).length === 0 ? /* @__PURE__ */ E("p", {
		className: "text-xs-tight text-muted",
		children: t
	}) : /* @__PURE__ */ E("pre", {
		className: "max-h-72 overflow-auto bg-bg/60 px-2.5 py-1.5 font-mono text-2xs leading-relaxed text-muted",
		"data-testid": "orchestrator-detail-json",
		children: $i(typeof e == "string" ? e : JSON.stringify(e, null, 2))
	});
}
function $({ label: e, value: t }) {
	return t == null || t === "" ? null : /* @__PURE__ */ D("div", {
		className: "grid grid-cols-[5.25rem_minmax(0,1fr)] gap-2 text-xs-tight",
		children: [/* @__PURE__ */ E("span", {
			className: "text-muted",
			children: e
		}), /* @__PURE__ */ E("span", {
			className: "min-w-0 break-words text-txt",
			children: t
		})]
	});
}
function ra({ active: e, onSelect: t, t: n }) {
	let r = [
		{
			id: "input",
			label: n("orchestrator.detail.tabs.input", { defaultValue: "Input" })
		},
		{
			id: "output",
			label: n("orchestrator.detail.tabs.output", { defaultValue: "Output" })
		},
		{
			id: "events",
			label: n("orchestrator.detail.tabs.events", { defaultValue: "Events" })
		},
		{
			id: "usage",
			label: n("orchestrator.detail.tabs.usage", { defaultValue: "Usage" })
		}
	];
	return /* @__PURE__ */ E("div", {
		className: "flex gap-2",
		role: "tablist",
		"aria-label": n("orchestrator.detail.tabsLabel", { defaultValue: "Detail tabs" }),
		children: r.map((n) => /* @__PURE__ */ E("button", {
			type: "button",
			role: "tab",
			"aria-selected": e === n.id,
			onClick: () => t(n.id),
			className: `flex-1 px-1 py-1 text-xs font-medium transition-colors ${e === n.id ? "text-accent" : "text-muted hover:text-txt"}`,
			children: n.label
		}, n.id))
	});
}
function ia(e) {
	return {
		inputTokens: e.inputTokens,
		outputTokens: e.outputTokens,
		reasoningTokens: e.reasoningTokens,
		cacheTokens: e.cacheTokens,
		totalTokens: e.totalTokens,
		costUsd: e.costUsd,
		state: e.usageState,
		byProvider: [{
			provider: e.providerSource ?? e.framework,
			model: e.model ?? void 0,
			inputTokens: e.inputTokens,
			outputTokens: e.outputTokens,
			reasoningTokens: e.reasoningTokens,
			cacheTokens: e.cacheTokens,
			totalTokens: e.totalTokens,
			costUsd: e.costUsd,
			state: e.usageState
		}]
	};
}
function aa(e) {
	return e.kind === "tool" ? e.tool.eventIds : e.kind === "reasoning" ? e.eventIds : e.kind === "notice" ? [e.eventId] : [];
}
function oa(e) {
	return e.kind === "user" || e.kind === "agent" ? e.messageIds : [];
}
function sa(e) {
	return {
		kind: "block",
		blockKey: e.key,
		blockKind: e.kind,
		eventIds: aa(e),
		messageIds: oa(e)
	};
}
function ca(e, t) {
	if (e.key === t.blockKey) return !0;
	if (e.kind !== t.blockKind) return !1;
	let n = aa(e);
	if (t.eventIds.length > 0 && t.eventIds.some((e) => n.includes(e))) return !0;
	let r = oa(e);
	return t.messageIds.length > 0 && t.messageIds.some((e) => r.includes(e));
}
function la(e) {
	return e.kind === "session" ? `session:${e.sessionId}` : [
		"block",
		e.blockKey,
		e.blockKind,
		e.eventIds.join(","),
		e.messageIds.join(",")
	].join(":");
}
function ua(e, t) {
	return e.kind === "tool" ? e.tool.title : e.kind === "agent" ? e.senderName : e.kind === "user" ? t("orchestrator.detail.userTurn", { defaultValue: "User turn" }) : e.kind === "reasoning" ? t("orchestrator.detail.reasoning", { defaultValue: "Reasoning" }) : e.eventType.replace(/_/g, " ");
}
function da(e, t) {
	let n = e.find((e) => e.eventType === "error");
	return n ? (typeof n.data?.message == "string" ? n.data.message : typeof n.data?.error == "string" ? n.data.error : n.summary).trim() || t("orchestrator.detail.errorFallback", { defaultValue: "Error" }) : null;
}
function fa(e, t, n) {
	return da(t, n) || (e ? e.kind === "agent" && e.tone === "error" ? $i(e.content, 600) : e.kind === "notice" && e.eventType === "error" ? e.text : e.kind === "tool" && e.tool.status === "failed" ? e.tool.output ? $i(e.tool.output, 600) : typeof e.tool.exitCode == "number" ? n("orchestrator.detail.toolExited", {
		defaultValue: `Tool exited with code ${e.tool.exitCode}.`,
		code: e.tool.exitCode
	}) : e.tool.rawStatus ?? n("orchestrator.detail.toolFailed", { defaultValue: "Tool failed." }) : null : null);
}
function pa(e, t) {
	return e.status !== "error" && e.status !== "errored" ? null : e.completionSummary ?? e.activeTool ?? t("orchestrator.detail.sessionFailed", { defaultValue: "Session failed." });
}
function ma({ text: e }) {
	return e ? /* @__PURE__ */ E("div", {
		className: "rounded-md bg-red-500/10 px-2.5 py-2 text-xs-tight text-red-500",
		children: e
	}) : null;
}
function ha({ title: e, subtitle: t, closeLabel: n, className: r, style: i, onClose: a, children: o }) {
	return /* @__PURE__ */ D("div", {
		className: `shrink-0 flex-col gap-2.5 overflow-y-auto bg-bg p-3 ${r ?? "flex w-80"}`,
		style: i,
		"data-testid": "orchestrator-operator-detail",
		children: [/* @__PURE__ */ D("div", {
			className: "flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ D("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ E("h3", {
					className: "truncate text-xs font-medium text-muted",
					children: e
				}), /* @__PURE__ */ E("p", {
					className: "mt-0.5 truncate text-xs-tight font-medium text-txt",
					children: t
				})]
			}), /* @__PURE__ */ E("button", {
				type: "button",
				onClick: a,
				className: "-mr-1 p-1 text-muted transition-colors hover:text-txt",
				"aria-label": n,
				"data-testid": "orchestrator-close-operator-detail",
				children: /* @__PURE__ */ E(je, { className: "h-4 w-4" })
			})]
		}), o]
	});
}
function ga({ events: e, messages: t, locale: n, t: r }) {
	return e.length === 0 && t.length === 0 ? /* @__PURE__ */ E("p", {
		className: "text-xs-tight text-muted",
		children: r("orchestrator.detail.noEvents", { defaultValue: "No events captured." })
	}) : /* @__PURE__ */ E("div", {
		className: "space-y-1.5",
		children: [...t.map((e) => ({
			kind: "message",
			id: e.id,
			timestamp: e.timestamp,
			record: e
		})), ...e.map((e) => ({
			kind: "event",
			id: e.id,
			timestamp: e.timestamp,
			record: e
		}))].sort((e, t) => e.timestamp - t.timestamp).map((e) => {
			if (e.kind === "message") {
				let t = e.record;
				return /* @__PURE__ */ D("div", {
					className: "py-1",
					children: [/* @__PURE__ */ D("div", {
						className: "mb-1 flex items-center gap-2 text-2xs text-muted",
						children: [
							/* @__PURE__ */ E("span", {
								className: "font-semibold text-txt",
								children: t.senderKind
							}),
							/* @__PURE__ */ E("span", { children: t.direction }),
							/* @__PURE__ */ E("span", {
								className: "ml-auto tabular-nums",
								children: fr(t.timestamp, n)
							})
						]
					}), /* @__PURE__ */ E(na, {
						value: t,
						emptyLabel: r("orchestrator.detail.noMessagePayload", { defaultValue: "No message payload." })
					})]
				}, `message-${t.id}`);
			}
			let t = e.record;
			return /* @__PURE__ */ D("div", {
				className: "py-1",
				children: [
					/* @__PURE__ */ D("div", {
						className: "mb-1 flex items-center gap-2 text-2xs text-muted",
						children: [/* @__PURE__ */ E("span", {
							className: "font-semibold text-txt",
							children: t.eventType.replace(/_/g, " ")
						}), /* @__PURE__ */ E("span", {
							className: "ml-auto tabular-nums",
							children: fr(t.timestamp, n)
						})]
					}),
					t.summary ? /* @__PURE__ */ E("p", {
						className: "mb-1 text-xs-tight text-txt",
						children: t.summary
					}) : null,
					/* @__PURE__ */ E(na, {
						value: t.data,
						emptyLabel: r("orchestrator.detail.noEventData", { defaultValue: "No event data." })
					})
				]
			}, `event-${t.id}`);
		})
	});
}
function _a({ selection: e, block: t, session: n, events: r, messages: i, taskUsage: a, busy: o, className: s, style: c, onClose: l, onRetry: u, onRerun: d, t: f, locale: p }) {
	let [m, h] = w("input"), g = f("orchestrator.detail.close", { defaultValue: "Close details" }), _ = (e, t) => f(`orchestrator.detail.${e}`, { defaultValue: t });
	if (e.kind === "session" && !n) return /* @__PURE__ */ E(ha, {
		title: f("orchestrator.detail.session", { defaultValue: "Session" }),
		subtitle: f("orchestrator.detail.noLongerAvailable", { defaultValue: "No longer available" }),
		closeLabel: g,
		className: s,
		style: c,
		onClose: l,
		children: /* @__PURE__ */ E("p", {
			className: "text-xs-tight text-muted",
			children: f("orchestrator.detail.sessionDataChanged", { defaultValue: "Session data changed." })
		})
	});
	if (e.kind === "block" && !t) return /* @__PURE__ */ E(ha, {
		title: f("orchestrator.detail.event", { defaultValue: "Event" }),
		subtitle: f("orchestrator.detail.noLongerAvailable", { defaultValue: "No longer available" }),
		closeLabel: g,
		className: s,
		style: c,
		onClose: l,
		children: /* @__PURE__ */ E("p", {
			className: "text-xs-tight text-muted",
			children: f("orchestrator.detail.timelineDataChanged", { defaultValue: "Timeline data changed." })
		})
	});
	let v = e.kind === "session", y = v ? f("orchestrator.detail.sessionDetail", { defaultValue: "Session detail" }) : f("orchestrator.detail.timelineDetail", { defaultValue: "Timeline detail" }), b = v ? n?.label ?? f("orchestrator.detail.session", { defaultValue: "Session" }) : t ? ua(t, f) : f("orchestrator.detail.event", { defaultValue: "Event" }), x = n ? ia(n) : a, S = n ? _("perToolUsageUnavailable", "Per-tool usage is not emitted yet; showing the owning session total.") : _("perToolUsageTaskFallback", "Per-tool usage is not emitted yet; showing the task total."), C = v && n ? pa(n, f) : t ? fa(t, r, f) : null, O = v ? null : i[0], ee = v ? null : r[0], k = _("retry", "Retry"), te = _("rerun", "Rerun"), A = [];
	v && n ? A.push(/* @__PURE__ */ E(Zi, {
		agentId: "operator-retry-session",
		description: "Retry this session's work in a new worker",
		icon: /* @__PURE__ */ E(ye, { className: "h-3 w-3" }),
		label: k,
		onClick: () => u({
			sessionId: n.sessionId,
			mode: "new-session",
			instruction: `Retry work from session ${n.label ?? n.sessionId}.`
		}),
		disabled: o,
		testId: "orchestrator-detail-retry"
	}, "retry-session")) : O && A.push(/* @__PURE__ */ E(Zi, {
		agentId: "operator-retry-message",
		description: "Retry this selected turn in a new worker",
		icon: /* @__PURE__ */ E(ye, { className: "h-3 w-3" }),
		label: k,
		onClick: () => u({
			messageId: O.id,
			sessionId: O.sessionId ?? void 0,
			mode: "new-session",
			instruction: "Retry this selected turn."
		}),
		disabled: o,
		testId: "orchestrator-detail-retry"
	}, "retry-message")), ee && A.push(/* @__PURE__ */ E(Zi, {
		agentId: "operator-rerun-event",
		description: "Rerun from this selected event without rewriting history",
		icon: /* @__PURE__ */ E(F, { className: "h-3 w-3" }),
		label: te,
		onClick: () => d({
			eventId: ee.id,
			instruction: `Rerun from ${ee.eventType.replace(/_/g, " ")}.`,
			stopActive: !1,
			preserveHistory: !0
		}),
		disabled: o,
		testId: "orchestrator-detail-rerun"
	}, "rerun-event"));
	let j;
	if (m === "input") if (v && n) j = /* @__PURE__ */ D("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ E($, {
				label: _("status", "Status"),
				value: n.status.replace(/_/g, " ")
			}),
			/* @__PURE__ */ E($, {
				label: _("framework", "Framework"),
				value: n.framework
			}),
			/* @__PURE__ */ E($, {
				label: _("provider", "Provider"),
				value: n.providerSource
			}),
			/* @__PURE__ */ E($, {
				label: _("model", "Model"),
				value: n.model
			}),
			/* @__PURE__ */ E($, {
				label: _("workdir", "Workdir"),
				value: n.workdir
			}),
			/* @__PURE__ */ E($, {
				label: _("repo", "Repo"),
				value: n.repo
			}),
			/* @__PURE__ */ E(Q, {
				title: _("originalTask", "Original task"),
				children: /* @__PURE__ */ E("p", {
					className: "whitespace-pre-wrap text-xs-tight text-txt",
					children: n.originalTask
				})
			}),
			ea(n.metadata) ? /* @__PURE__ */ E(Q, {
				title: _("metadata", "Metadata"),
				children: /* @__PURE__ */ E(na, {
					value: n.metadata,
					emptyLabel: _("noMetadata", "No metadata.")
				})
			}) : null
		]
	});
	else if (t?.kind === "tool") {
		let e = t.tool.rawInput ?? {};
		j = /* @__PURE__ */ D("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ E($, {
					label: _("toolId", "Tool id"),
					value: t.tool.id
				}),
				/* @__PURE__ */ E($, {
					label: _("kind", "Kind"),
					value: t.tool.kind || "tool"
				}),
				/* @__PURE__ */ E($, {
					label: _("status", "Status"),
					value: t.tool.rawStatus ?? t.tool.status
				}),
				/* @__PURE__ */ E($, {
					label: _("file", "File"),
					value: t.tool.filePath
				}),
				/* @__PURE__ */ E($, {
					label: _("command", "Command"),
					value: t.tool.command
				}),
				/* @__PURE__ */ E($, {
					label: _("query", "Query"),
					value: t.tool.query
				}),
				/* @__PURE__ */ E(na, {
					value: e,
					emptyLabel: _("noToolInput", "No tool input captured.")
				})
			]
		});
	} else j = t?.kind === "user" ? /* @__PURE__ */ E("pre", {
		className: "whitespace-pre-wrap bg-bg/60 px-2.5 py-1.5 text-xs-tight text-txt",
		children: t.content
	}) : t?.kind === "agent" ? /* @__PURE__ */ E(na, {
		value: i.map((e) => e.metadata),
		emptyLabel: _("noInputMetadata", "No input metadata captured.")
	}) : /* @__PURE__ */ E(na, {
		value: r.map((e) => e.data),
		emptyLabel: _("noInput", "No input captured.")
	});
	else j = m === "output" ? v && n ? /* @__PURE__ */ D("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ E($, {
				label: _("activeTool", "Active tool"),
				value: n.activeTool
			}),
			/* @__PURE__ */ E($, {
				label: _("decisions", "Decisions"),
				value: f("orchestrator.detail.decisionCounts", {
					defaultValue: `${n.decisionCount} total · ${n.autoResolvedCount} auto`,
					count: n.decisionCount,
					auto: n.autoResolvedCount
				})
			}),
			/* @__PURE__ */ E($, {
				label: _("lastInput", "Last input"),
				value: n.lastInputSentAt ? fr(n.lastInputSentAt, p) : null
			}),
			/* @__PURE__ */ E(Q, {
				title: _("completion", "Completion"),
				children: n.completionSummary ? /* @__PURE__ */ E("p", {
					className: "whitespace-pre-wrap text-xs-tight text-txt",
					children: n.completionSummary
				}) : /* @__PURE__ */ E("p", {
					className: "text-xs-tight text-muted",
					children: _("noCompletion", "No completion yet.")
				})
			})
		]
	}) : t?.kind === "tool" ? /* @__PURE__ */ D("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ E($, {
				label: _("exit", "Exit"),
				value: t.tool.exitCode
			}),
			/* @__PURE__ */ E($, {
				label: _("duration", "Duration"),
				value: t.tool.durationMs ? hr(t.tool.durationMs) : null
			}),
			/* @__PURE__ */ E(Or, { tool: t.tool }),
			/* @__PURE__ */ E(na, {
				value: t.tool.rawOutput,
				emptyLabel: _("noRawOutput", "No raw output payload captured.")
			})
		]
	}) : t?.kind === "agent" || t?.kind === "user" ? /* @__PURE__ */ E("pre", {
		className: "whitespace-pre-wrap bg-bg/60 px-2.5 py-1.5 text-xs-tight text-txt",
		children: $i(t.content)
	}) : t?.kind === "reasoning" ? /* @__PURE__ */ E("pre", {
		className: "whitespace-pre-wrap bg-bg/60 px-2.5 py-1.5 text-xs-tight text-txt",
		children: $i(t.text)
	}) : t ? /* @__PURE__ */ E("p", {
		className: "text-xs-tight text-txt",
		children: t.text
	}) : null : m === "events" ? /* @__PURE__ */ E(ga, {
		events: r,
		messages: i,
		locale: p,
		t: f
	}) : /* @__PURE__ */ D("div", {
		className: "space-y-2",
		children: [t?.kind === "tool" ? /* @__PURE__ */ E("p", {
			className: "text-xs-tight text-muted",
			children: S
		}) : null, /* @__PURE__ */ E(Ki, {
			usage: x,
			t: f,
			locale: p
		})]
	});
	return /* @__PURE__ */ D(ha, {
		title: y,
		subtitle: b,
		closeLabel: g,
		className: s,
		style: c,
		onClose: l,
		children: [
			/* @__PURE__ */ E(ma, { text: C }),
			/* @__PURE__ */ D("div", {
				className: "space-y-1.5",
				children: [n ? /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E($, {
					label: _("session", "Session"),
					value: n.sessionId
				}), /* @__PURE__ */ E($, {
					label: _("activity", "Activity"),
					value: fr(n.lastActivityAt, p)
				})] }) : null, t ? /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E($, {
					label: _("kind", "Kind"),
					value: t.kind
				}), /* @__PURE__ */ E($, {
					label: _("time", "Time"),
					value: fr(t.at, p)
				})] }) : null]
			}),
			A.length > 0 ? /* @__PURE__ */ D("div", {
				className: "space-y-1.5",
				"data-testid": "orchestrator-detail-recovery",
				children: [/* @__PURE__ */ E("div", {
					className: "text-xs font-medium text-muted",
					children: _("recovery", "Recovery")
				}), /* @__PURE__ */ E("div", {
					className: "flex flex-wrap gap-1.5",
					children: A
				})]
			}) : null,
			/* @__PURE__ */ E(ra, {
				active: m,
				onSelect: h,
				t: f
			}),
			/* @__PURE__ */ E("div", {
				className: "min-h-0",
				children: j
			})
		]
	});
}
function va() {
	if (typeof window > "u") return null;
	let e = new URLSearchParams(window.location.search);
	return e.get("task") ?? e.get("taskId");
}
var ya = "(max-width: 767px)";
function ba() {
	let [e, t] = w(() => typeof window > "u" || !window.matchMedia ? !1 : window.matchMedia(ya).matches);
	return x(() => {
		if (typeof window > "u" || !window.matchMedia) return;
		let e = window.matchMedia(ya), n = (e) => t(e.matches);
		return t(e.matches), e.addEventListener("change", n), () => e.removeEventListener("change", n);
	}, []), e;
}
var xa = {
	position: "absolute",
	insetBlock: 0,
	right: 0,
	zIndex: 30,
	width: "86%",
	maxWidth: "22rem",
	boxShadow: "0 10px 30px rgba(0, 0, 0, 0.45)"
}, Sa = { display: "none" };
function Ca({ detail: e, isMobile: t, onBack: n, onOpenInspector: r, t: i }) {
	let a = /* @__PURE__ */ E(ci, {
		status: e.status,
		paused: e.paused,
		t: i,
		size: "h-4 w-4"
	}), o = /* @__PURE__ */ E("span", {
		className: "min-w-0 flex-1 truncate text-sm font-semibold text-txt",
		children: e.title
	}), s = i("orchestrator.status.paused", { defaultValue: "Paused" }), c = e.paused ? /* @__PURE__ */ E("span", {
		className: "inline-flex shrink-0 text-warn",
		title: s,
		"aria-label": s,
		role: "img",
		children: /* @__PURE__ */ E(_e, {
			className: "h-3.5 w-3.5",
			"aria-hidden": !0
		})
	}) : null, l = i("orchestrator.action.details", { defaultValue: "Details" }), u = i("orchestrator.action.backToList", { defaultValue: "Back to tasks" }), { ref: d, agentProps: f } = B({
		id: "timeline-back",
		role: "button",
		label: u,
		group: "orchestrator-timeline",
		description: "Go back to the task list"
	}), { ref: p, agentProps: m } = B({
		id: "timeline-open-inspector",
		role: "button",
		label: l,
		group: "orchestrator-timeline",
		description: "Open the task details panel"
	});
	return t ? /* @__PURE__ */ D("div", {
		className: "px-3 py-2",
		children: [/* @__PURE__ */ D("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ E("button", {
					ref: d,
					type: "button",
					onClick: n,
					className: "-ml-1 shrink-0 p-1 text-muted transition-colors hover:text-txt",
					"aria-label": u,
					"data-testid": "orchestrator-back",
					...f,
					children: /* @__PURE__ */ E(k, { className: "h-4 w-4" })
				}),
				a,
				o,
				/* @__PURE__ */ E("button", {
					ref: p,
					type: "button",
					onClick: r,
					className: "shrink-0 p-1 text-muted transition-colors hover:text-txt",
					"aria-label": l,
					title: l,
					"data-testid": "orchestrator-open-inspector",
					...m,
					children: /* @__PURE__ */ E(ge, {
						className: "h-4 w-4",
						"aria-hidden": !0
					})
				})
			]
		}), c ? /* @__PURE__ */ E("div", {
			className: "mt-1.5 flex items-center gap-1.5",
			children: c
		}) : null]
	}) : /* @__PURE__ */ D("div", {
		className: "flex items-center gap-2.5 px-4 py-2.5",
		children: [
			/* @__PURE__ */ E(wi, {
				label: u,
				onClick: n,
				testId: "orchestrator-back"
			}),
			a,
			o,
			c,
			/* @__PURE__ */ E("button", {
				ref: p,
				type: "button",
				onClick: r,
				className: "shrink-0 p-1 text-muted transition-colors hover:text-txt",
				"aria-label": l,
				title: l,
				"data-testid": "orchestrator-open-inspector",
				...m,
				children: /* @__PURE__ */ E(ge, {
					className: "h-4 w-4",
					"aria-hidden": !0
				})
			})
		]
	});
}
function wa() {
	let { t: e, uiLanguage: t, copyToClipboard: n, agentStatus: r, setTab: i } = _((e) => ({
		t: e.t,
		uiLanguage: e.uiLanguage,
		copyToClipboard: e.copyToClipboard,
		agentStatus: e.agentStatus,
		setTab: e.setTab
	})), a = e ?? Wr, o = typeof t == "string" ? t : void 0, s = typeof r?.agentName == "string" ? r.agentName : void 0, [c, l] = w(va), [u, f] = w(""), [p, m] = w("all"), [h, v] = w(!1), [k, te] = w(!1), [A, j] = w(!1), [M, N] = w(!1), [P, F] = w(null), I = ba(), ne = b(u.trim()), L = C(c);
	L.current = c;
	let { status: re, tasks: ie, detail: R, messages: oe, events: se, timelineCursor: ce, loading: le, mutating: ue, loadError: de, backendAbsent: fe, actionError: pe, runMutation: z, loadOlderTimeline: he } = Mi({
		selectedId: c,
		showArchived: h,
		statusFilter: p,
		deferredSearch: ne,
		t: a
	}), _e = C(null), ve = C(!0), ye = y((e) => {
		let t = e.currentTarget;
		ve.current = t.scrollHeight - t.scrollTop - t.clientHeight < 80;
	}, []);
	x(() => {
		N(!1), te(!1), F(null), ve.current = !0;
	}, [c]);
	let be = y(() => {
		let e = R;
		if (!e) return;
		let t = e.sessions.filter((e) => e.sessionId && e.stoppedAt == null && e.status !== "completed");
		t.length !== 0 && z(async () => {
			for (let n of t) await g.stopOrchestratorAgent(e.id, n.sessionId);
		});
	}, [R, z]), xe = C({
		addAgentOpen: k,
		inspectorOpen: M,
		detailDrawer: P,
		stop: be
	});
	xe.current = {
		addAgentOpen: k,
		inspectorOpen: M,
		detailDrawer: P,
		stop: be
	}, x(() => {
		let e = (e) => {
			if (e.key !== "Escape") return;
			let t = xe.current;
			if (t.addAgentOpen) {
				te(!1);
				return;
			}
			if (t.inspectorOpen) {
				N(!1);
				return;
			}
			if (t.detailDrawer) {
				F(null);
				return;
			}
			t.stop();
		};
		return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e);
	}, []);
	let Se = y(() => {
		let e = L.current;
		!e || !n || typeof window > "u" || n(`${window.location.origin}/orchestrator?task=${encodeURIComponent(e)}`);
	}, [n]), Ce = S(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of R?.sessions ?? []) {
			let n = t.label?.trim();
			t.sessionId && n && e.set(t.sessionId, n);
		}
		return e;
	}, [R?.sessions]), we = S(() => {
		let e = /* @__PURE__ */ new Set();
		for (let t of R?.sessions ?? []) t.sessionId && (t.stoppedAt != null || t.status === "completed") && e.add(t.sessionId);
		return e;
	}, [R?.sessions]), Te = S(() => Ur(oe, se, (e) => mi(e, Ce, s, a), we), [
		oe,
		se,
		Ce,
		s,
		we,
		a
	]), Ee = S(() => P?.kind === "block" ? Te.find((e) => ca(e, P)) ?? null : null, [Te, P]), De = S(() => P?.kind !== "session" || !R ? null : R.sessions.find((e) => e.sessionId === P.sessionId) ?? null, [R, P]), Oe = S(() => {
		if (!P) return [];
		if (P.kind === "session") return se.filter((e) => e.sessionId === P.sessionId);
		let e = new Set(P.eventIds);
		return se.filter((t) => e.has(t.id));
	}, [P, se]), ke = S(() => {
		if (!P) return [];
		if (P.kind === "session") return oe.filter((e) => e.sessionId === P.sessionId);
		let e = new Set(P.messageIds);
		return oe.filter((t) => e.has(t.id));
	}, [P, oe]), Ae = y((e) => {
		F(sa(e)), I && N(!0);
	}, [I]), je = y((e) => {
		F({
			kind: "session",
			sessionId: e
		}), I && N(!0);
	}, [I]);
	x(() => {
		let e = _e.current;
		e && ve.current && (e.scrollTop = e.scrollHeight);
	}, [Te]);
	let Me = JSON.stringify({
		selectedId: c,
		taskCount: re?.taskCount ?? ie.length,
		activeTaskCount: re?.activeTaskCount ?? 0,
		statusFilter: p,
		showArchived: h
	}), Ne = a("orchestrator.searchPlaceholder", { defaultValue: "Search tasks" }), Pe = a("orchestrator.showArchived", { defaultValue: "Show archived" }), Fe = a("orchestrator.loadOlder", { defaultValue: "Load older" }), Ie = a("orchestrator.action.stop", { defaultValue: "Stop" }), { ref: V, agentProps: Le } = B({
		id: "rail-search",
		role: "text-input",
		label: Ne,
		group: "orchestrator-rail",
		description: "Filter the task list by title or request text",
		getValue: () => u,
		onFill: (e) => f(e)
	}), { ref: H, agentProps: Re } = B({
		id: "rail-show-archived",
		role: "toggle",
		label: Pe,
		group: "orchestrator-rail",
		status: h ? "active" : "inactive",
		description: "Toggle showing archived tasks in the list",
		onActivate: () => v((e) => !e)
	}), { ref: ze, agentProps: U } = B({
		id: "timeline-load-older",
		role: "button",
		label: Fe,
		group: "orchestrator-timeline",
		description: "Load older entries in the task timeline"
	}), { ref: W, agentProps: Be } = B({
		id: "timeline-stop-active",
		role: "button",
		label: Ie,
		group: "orchestrator-timeline",
		description: "Stop the running sub-agents on this task"
	});
	return /* @__PURE__ */ D("div", {
		className: "relative flex h-full min-h-0 w-full flex-col bg-bg text-txt",
		"data-testid": "orchestrator-workbench",
		children: [
			/* @__PURE__ */ E("span", {
				"data-view-state": Me,
				hidden: !0
			}),
			/* @__PURE__ */ E(Ri, {
				status: re,
				busy: ue,
				isMobile: I,
				onPauseAll: () => z(() => g.pauseAllOrchestratorTasks()),
				onResumeAll: () => z(() => g.resumeAllOrchestratorTasks()),
				accountsOpen: A,
				onToggleAccounts: () => j((e) => !e),
				t: a,
				locale: o
			}),
			A ? /* @__PURE__ */ E("div", {
				className: "border-b border-border/40 px-4 py-2",
				children: /* @__PURE__ */ E(st, {
					t: a,
					onConnect: () => i?.("settings")
				})
			}) : null,
			fe ? /* @__PURE__ */ E("div", {
				className: "px-4 py-1.5 text-2xs text-muted",
				children: a("orchestrator.backendAbsent", { defaultValue: "Connect a cloud or desktop agent to run tasks." })
			}) : null,
			de ? /* @__PURE__ */ E("div", {
				className: "bg-danger/10 px-3 py-1.5 text-xs text-danger",
				children: de
			}) : null,
			pe ? /* @__PURE__ */ E("div", {
				className: "bg-danger/10 px-3 py-1.5 text-xs text-danger",
				children: pe
			}) : null,
			/* @__PURE__ */ D("div", {
				className: "relative flex min-h-0 flex-1 flex-col overflow-y-auto",
				children: [
					c ? null : /* @__PURE__ */ D("div", {
						className: "relative flex flex-1 flex-col gap-3 px-4 pb-28 pt-4",
						"data-testid": "orchestrator-rail",
						children: [ie.length > 0 || le ? /* @__PURE__ */ D("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ E(xi, {
								value: u,
								onChange: f,
								placeholder: Ne,
								inputRef: V,
								testId: "orchestrator-search",
								className: "min-w-[12rem] flex-1",
								agentProps: Le
							}), /* @__PURE__ */ D("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ E("div", {
									className: "w-40",
									children: /* @__PURE__ */ E(zi, {
										status: re,
										active: p,
										onSelect: m,
										t: a
									})
								}), /* @__PURE__ */ D("button", {
									ref: H,
									type: "button",
									onClick: () => v((e) => !e),
									"aria-pressed": h,
									className: `inline-flex h-9 items-center gap-2 px-2 text-xs font-medium transition-colors ${h ? "text-accent" : "text-muted hover:text-txt"}`,
									"data-testid": "orchestrator-show-archived",
									...Re,
									children: [/* @__PURE__ */ E(O, { className: "h-3.5 w-3.5" }), Pe]
								})]
							})]
						}) : null, ie.length === 0 ? le ? /* @__PURE__ */ E("p", {
							className: "p-2 text-sm text-muted",
							children: a("orchestrator.loadingTasks", { defaultValue: "Loading" })
						}) : /* @__PURE__ */ E(d, {
							icon: me,
							testId: "task-empty-state",
							title: fe ? a("orchestrator.empty.setupTitle", { defaultValue: "Connect a cloud or desktop agent, then describe a task in the chat below." }) : a("orchestrator.empty.title", { defaultValue: "Describe a task in the chat below and it will appear here." }),
							recommendations: [
								a("orchestrator.empty.rec.fixBug", { defaultValue: "Ask Eliza to fix a bug" }),
								a("orchestrator.empty.rec.tests", { defaultValue: "Ask Eliza to write tests for a module" }),
								a("orchestrator.empty.rec.feature", { defaultValue: "Ask Eliza to build a small feature" })
							]
						}) : /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E("div", {
							className: "flex flex-col gap-2.5",
							children: ie.map((e) => /* @__PURE__ */ E(Ci, {
								id: e.id,
								title: e.title,
								subtitle: e.summary || e.originalRequest,
								status: e.status,
								chips: Bi(e, a, o),
								onOpen: (e) => l(e),
								t: a
							}, e.id))
						}), ie.length < 4 ? /* @__PURE__ */ E(Si, { icon: me }) : null] })]
					}),
					/* @__PURE__ */ E("main", {
						className: "flex min-h-0 min-w-0 flex-1 flex-col bg-bg",
						"data-testid": "orchestrator-timeline",
						style: c ? { minHeight: "20rem" } : Sa,
						children: R ? /* @__PURE__ */ D(T, { children: [
							/* @__PURE__ */ E(Ca, {
								detail: R,
								isMobile: I,
								onBack: () => l(null),
								onOpenInspector: () => {
									F(null), N(!0);
								},
								t: a
							}),
							/* @__PURE__ */ D("div", {
								ref: _e,
								onScroll: ye,
								className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4",
								"data-testid": "orchestrator-message-list",
								children: [ce ? /* @__PURE__ */ E("div", {
									className: "flex justify-center",
									children: /* @__PURE__ */ D("button", {
										ref: ze,
										type: "button",
										onClick: () => void he(),
										className: "flex items-center gap-1 px-1 py-0.5 text-2xs text-muted transition-colors hover:text-txt",
										"data-testid": "orchestrator-load-older",
										"aria-label": Fe,
										...U,
										children: [/* @__PURE__ */ E(ee, { className: "h-3 w-3" }), Fe]
									})
								}) : null, Te.length === 0 ? /* @__PURE__ */ E("p", {
									className: "p-4 text-center text-xs text-muted",
									children: a("orchestrator.noMessages", { defaultValue: "No messages yet." })
								}) : Te.map((e) => /* @__PURE__ */ D("div", {
									className: `group flex gap-1.5 transition-colors ${P?.kind === "block" && ca(e, P) ? "text-accent" : "hover:bg-bg-hover/30"}`,
									"data-testid": "orchestrator-conversation-block",
									children: [/* @__PURE__ */ E("button", {
										type: "button",
										onClick: () => Ae(e),
										className: "mt-1.5 flex h-6 w-6 shrink-0 items-center justify-center text-muted opacity-0 transition-colors hover:text-txt focus:opacity-100 group-hover:opacity-100 group-focus-within:opacity-100",
										"aria-label": a("orchestrator.action.inspectBlock", { defaultValue: `Inspect ${ua(e, a)}` }),
										title: a("orchestrator.action.inspectBlock", { defaultValue: `Inspect ${ua(e, a)}` }),
										"data-testid": "orchestrator-inspect-block",
										children: /* @__PURE__ */ E(ge, { className: "h-3.5 w-3.5" })
									}), /* @__PURE__ */ E("div", {
										className: "min-w-0 flex-1",
										children: /* @__PURE__ */ E(Ar, {
											block: e,
											locale: o,
											onInspect: () => Ae(e)
										})
									})]
								}, e.key))]
							}),
							R.activeSessionCount > 0 ? /* @__PURE__ */ D("div", {
								className: "flex items-center justify-between gap-2 bg-warn/5 px-3 py-1.5",
								"data-testid": "orchestrator-running-bar",
								children: [/* @__PURE__ */ D("span", {
									className: "flex items-center gap-1.5 text-2xs font-medium text-warn",
									children: [/* @__PURE__ */ E("span", { className: "h-1.5 w-1.5 animate-pulse rounded-full bg-warn" }), a("orchestrator.agentsWorking", { defaultValue: "Agent working…" })]
								}), /* @__PURE__ */ D("button", {
									ref: W,
									type: "button",
									onClick: be,
									disabled: ue,
									className: "flex items-center gap-1 px-1 py-0.5 text-2xs text-txt transition-colors hover:text-danger disabled:opacity-50",
									"data-testid": "orchestrator-stop-active",
									"aria-label": Ie,
									...Be,
									children: [
										/* @__PURE__ */ E(ae, { className: "h-3 w-3" }),
										Ie,
										/* @__PURE__ */ E("kbd", {
											className: "ml-0.5 px-1 text-[0.9em] text-muted",
											children: "Esc"
										})
									]
								})]
							}) : null,
							/* @__PURE__ */ E("div", { className: "pb-24" })
						] }) : /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ D("div", {
							className: "flex items-center gap-2.5 px-4 py-2.5",
							children: [/* @__PURE__ */ E(wi, {
								label: a("orchestrator.action.backToList", { defaultValue: "Tasks" }),
								onClick: () => l(null),
								testId: "orchestrator-back-loading"
							}), /* @__PURE__ */ E("span", {
								className: "text-sm font-medium text-muted",
								children: a("orchestrator.loadingTask", { defaultValue: "Loading task…" })
							})]
						}), /* @__PURE__ */ E("div", {
							className: "flex flex-1 items-center justify-center p-6",
							children: /* @__PURE__ */ E("p", {
								className: "text-xs text-muted",
								children: a("orchestrator.loadingTask", { defaultValue: "Loading task…" })
							})
						})] })
					}),
					R && I && M ? /* @__PURE__ */ E("button", {
						type: "button",
						"aria-label": a("orchestrator.action.closeDetails", { defaultValue: "Close details" }),
						onClick: () => {
							N(!1), F(null);
						},
						className: "absolute inset-0 z-20 bg-black/40",
						"data-testid": "orchestrator-inspector-backdrop"
					}) : null,
					R && P ? /* @__PURE__ */ E(_a, {
						selection: P,
						block: Ee,
						session: De,
						events: Oe,
						messages: ke,
						taskUsage: R.usage,
						busy: ue,
						className: "flex",
						style: I ? M ? xa : Sa : void 0,
						onClose: () => {
							F(null), I && N(!1);
						},
						onRetry: (e) => z(() => g.retryOrchestratorTaskTurn(R.id, e)),
						onRerun: (e) => z(() => g.rerunOrchestratorTaskFromEvent(R.id, e)),
						t: a,
						locale: o
					}, la(P)) : R ? /* @__PURE__ */ E(Qi, {
						detail: R,
						className: "flex",
						style: I ? M ? xa : Sa : void 0,
						onClose: I ? () => N(!1) : void 0,
						busy: ue,
						addAgentOpen: k,
						onPause: () => z(() => g.pauseOrchestratorTask(R.id)),
						onResume: () => z(() => g.resumeOrchestratorTask(R.id)),
						onArchive: () => z(async () => {
							await g.archiveCodingAgentTaskThread(R.id), h || l(null);
						}),
						onReopen: () => z(() => g.reopenCodingAgentTaskThread(R.id)),
						onDelete: () => z(async () => {
							await g.deleteOrchestratorTask(R.id), l(null);
						}),
						onFork: () => z(async () => {
							let e = await g.forkOrchestratorTask(R.id);
							e && l(e.id);
						}),
						onRestart: () => {
							(typeof window > "u" || window.confirm(a("orchestrator.confirmRestart", { defaultValue: "Restart this task with a fresh worker? Active agents will be stopped first." }))) && z(() => g.restartOrchestratorTask(R.id, { stopActive: !0 }));
						},
						onRestartWithEditedPlan: (e) => z(() => g.restartOrchestratorTaskWithEditedPlan(R.id, e)),
						onValidate: (e) => z(() => g.validateOrchestratorTask(R.id, {
							passed: e,
							humanOverride: !0
						})),
						onSetPriority: (e) => z(() => g.updateOrchestratorTask(R.id, { priority: e })),
						onToggleAddAgent: () => te((e) => !e),
						onAddAgent: (e) => z(async () => {
							await g.addOrchestratorAgent(R.id, e), te(!1);
						}),
						onInspectSession: je,
						onStopAgent: (e) => z(() => g.stopOrchestratorAgent(R.id, e)),
						onCopyLink: Se,
						t: a,
						locale: o
					}) : null
				]
			})
		]
	});
}
//#endregion
//#region src/CockpitSessionPane.tsx
function Ta({ taskId: e, onBack: t, t: n = Wr, locale: r }) {
	let { detail: i, messages: a, events: o, mutating: s, runMutation: c } = Mi({
		selectedId: e,
		showArchived: !1,
		statusFilter: "all",
		deferredSearch: "",
		t: n
	}), [l, u] = w(!1), [d, p] = w("transcript"), [m, _] = w([]), b = C(!1);
	x(() => {
		let e = !0, t = async () => {
			try {
				let t = await g.getCodingAgentStatus();
				if (!e) return;
				_(t?.tasks ?? []), b.current = !1;
			} catch (e) {
				b.current || (b.current = !0, console.warn("[cockpit] coding-agent status poll failed; terminal sessions unavailable", e));
			}
		};
		t();
		let n = setInterval(() => void t(), 3e3);
		return () => {
			e = !1, clearInterval(n);
		};
	}, []);
	let T = S(() => new Set((i?.sessions ?? []).map((e) => e.sessionId).filter((e) => !!e)), [i?.sessions]), O = S(() => m.filter((e) => T.has(e.sessionId)), [m, T]), ee = S(() => O.find((e) => e.status === "active" || e.status === "tool_running")?.sessionId ?? O[0]?.sessionId ?? null, [O]), te = i?.providerPolicy?.preferredFramework === "elizaos" && i?.providerPolicy?.providerSource === "eliza-cloud", A = h.small === h.large ? "small" : i?.providerPolicy?.model === h.large ? "large" : "small", j = y((t) => {
		let n = h[t];
		c(async () => {
			await g.updateOrchestratorTask(e, { providerPolicy: {
				preferredFramework: "elizaos",
				providerSource: "eliza-cloud",
				model: n
			} }), await g.restartOrchestratorTask(e, { stopActive: !0 });
		});
	}, [e, c]), M = S(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of i?.sessions ?? []) {
			let n = t.label?.trim();
			t.sessionId && n && e.set(t.sessionId, n);
		}
		return e;
	}, [i?.sessions]), N = S(() => {
		let e = /* @__PURE__ */ new Set();
		for (let t of i?.sessions ?? []) t.sessionId && (t.stoppedAt != null || t.status === "completed") && e.add(t.sessionId);
		return e;
	}, [i?.sessions]), P = S(() => Ur(a, o, (e) => mi(e, M, void 0, n), N), [
		a,
		o,
		M,
		N,
		n
	]), [F, I] = w(null), ne = y((t) => (I(null), g.postOrchestratorTaskMessage(e, t).catch((e) => {
		I(e instanceof Error ? `Couldn't deliver your message: ${e.message}` : "Couldn't deliver your message.");
	}), !0), [e]);
	return v({
		placeholder: n("cockpit.session.composer", { defaultValue: `Message ${i?.title ?? "agent"}` }),
		onSubmit: ne
	}), /* @__PURE__ */ D("div", {
		className: "flex h-full min-h-0 w-full flex-col bg-bg",
		"data-testid": "cockpit-session-pane",
		children: [
			/* @__PURE__ */ D("header", {
				className: "flex shrink-0 items-center gap-2 border-border/40 border-b px-3 py-2",
				children: [
					/* @__PURE__ */ E("button", {
						type: "button",
						onClick: t,
						className: "-ml-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-muted transition-colors hover:bg-bg-hover/40 hover:text-txt",
						"aria-label": n("cockpit.session.back", { defaultValue: "Back to all rooms" }),
						"data-testid": "cockpit-session-back",
						children: /* @__PURE__ */ E(k, {
							className: "h-4 w-4",
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ E("h2", {
						className: "min-w-0 flex-1 truncate text-sm font-semibold text-txt",
						children: i?.title ?? n("cockpit.session.loading", { defaultValue: "Loading room…" })
					}),
					te ? /* @__PURE__ */ E(f, {
						value: A,
						onChange: j,
						disabled: s,
						className: "shrink-0"
					}) : null,
					/* @__PURE__ */ D("fieldset", {
						className: "flex shrink-0 items-center gap-1 border-0 p-0",
						"aria-label": n("cockpit.session.viewMode", { defaultValue: "View mode" }),
						children: [/* @__PURE__ */ E("button", {
							type: "button",
							onClick: () => p("transcript"),
							"aria-pressed": d === "transcript",
							"data-testid": "cockpit-view-transcript",
							title: n("cockpit.session.transcript", { defaultValue: "Transcript" }),
							className: `inline-flex h-8 w-8 items-center justify-center rounded-md transition-colors ${d === "transcript" ? "bg-accent/15 text-accent" : "text-muted hover:bg-bg-hover/40 hover:text-txt"}`,
							children: /* @__PURE__ */ E(be, {
								className: "h-4 w-4",
								"aria-hidden": !0
							})
						}), /* @__PURE__ */ E("button", {
							type: "button",
							onClick: () => p("terminal"),
							"aria-pressed": d === "terminal",
							"data-testid": "cockpit-view-terminal",
							title: n("cockpit.session.watch", { defaultValue: "Watch (terminal output)" }),
							className: `inline-flex h-8 w-8 items-center justify-center rounded-md transition-colors ${d === "terminal" ? "bg-accent/15 text-accent" : "text-muted hover:bg-bg-hover/40 hover:text-txt"}`,
							children: /* @__PURE__ */ E(we, {
								className: "h-4 w-4",
								"aria-hidden": !0
							})
						})]
					})
				]
			}),
			F ? /* @__PURE__ */ E("div", {
				role: "alert",
				"data-testid": "cockpit-session-error",
				className: "shrink-0 border-destructive/40 border-b bg-destructive/10 px-3 py-2 text-xs text-destructive",
				children: F
			}) : null,
			/* @__PURE__ */ D("div", {
				className: "flex min-h-0 flex-1 overflow-hidden",
				children: [d === "terminal" ? /* @__PURE__ */ E("div", {
					className: "min-w-0 flex-1 overflow-hidden p-2",
					"data-testid": "cockpit-session-terminal",
					children: /* @__PURE__ */ E(rt, {
						activeSessionId: ee,
						sessions: O
					})
				}) : /* @__PURE__ */ E("div", {
					className: "min-w-0 flex-1 space-y-3 overflow-y-auto px-3 py-3",
					"data-testid": "cockpit-session-transcript",
					children: P.length === 0 ? /* @__PURE__ */ E("p", {
						className: "px-1 text-xs text-muted",
						children: n("cockpit.session.empty", { defaultValue: "No messages yet." })
					}) : P.map((e) => /* @__PURE__ */ E(Ar, {
						block: e,
						locale: r
					}, e.key))
				}), i ? /* @__PURE__ */ E(Qi, {
					detail: i,
					busy: s,
					addAgentOpen: l,
					onPause: () => c(() => g.pauseOrchestratorTask(e)),
					onResume: () => c(() => g.resumeOrchestratorTask(e)),
					onArchive: () => c(async () => {
						await g.archiveCodingAgentTaskThread(e), t();
					}),
					onReopen: () => c(() => g.reopenCodingAgentTaskThread(e)),
					onDelete: () => c(async () => {
						await g.deleteOrchestratorTask(e), t();
					}),
					onFork: () => c(() => g.forkOrchestratorTask(e)),
					onRestart: () => {
						(typeof window > "u" || window.confirm(n("orchestrator.confirmRestart", { defaultValue: "Restart this task with a fresh worker? Active agents will be stopped first." }))) && c(() => g.restartOrchestratorTask(e, { stopActive: !0 }));
					},
					onRestartWithEditedPlan: (t) => c(() => g.restartOrchestratorTaskWithEditedPlan(e, t)),
					onValidate: (t) => c(() => g.validateOrchestratorTask(e, {
						passed: t,
						humanOverride: !0
					})),
					onSetPriority: (t) => c(() => g.updateOrchestratorTask(e, { priority: t })),
					onToggleAddAgent: () => u((e) => !e),
					onAddAgent: (t) => c(async () => {
						await g.addOrchestratorAgent(e, t), u(!1);
					}),
					onInspectSession: () => {},
					onStopAgent: (t) => c(() => g.stopOrchestratorAgent(e, t)),
					onCopyLink: () => {
						typeof window > "u" || !navigator.clipboard || navigator.clipboard.writeText(`${window.location.origin}/orchestrator?task=${encodeURIComponent(e)}`);
					},
					t: n,
					locale: r
				}) : null]
			})
		]
	});
}
//#endregion
//#region src/CockpitRoute.tsx
var Ea = 4e3;
function Da() {
	let [e, t] = w(null), [n, r] = w(null), [i, a] = w(!1), [o, s] = w(null), [c, l] = w(null), d = y(async () => {
		try {
			t(await g.getOrchestratorRooms()), r(null);
		} catch (e) {
			r(e instanceof Error ? e.message : "Couldn't load task rooms.");
		}
	}, []);
	x(() => {
		d();
		let e = setInterval(() => {
			d();
		}, Ea);
		return () => clearInterval(e);
	}, [d]);
	let f = y(async (e) => {
		a(!0);
		try {
			let t = await g.createOrchestratorTask(e), n = e.providerPolicy;
			await g.addOrchestratorAgent(t.id, {
				framework: n?.preferredFramework,
				providerSource: n?.providerSource,
				model: n?.model,
				task: e.goal
			}), r(null), await d();
		} catch (e) {
			r(e instanceof Error ? e.message : "Couldn't start the session.");
		} finally {
			a(!1);
		}
	}, [d]);
	return o ? /* @__PURE__ */ E(Ta, {
		taskId: o,
		onBack: () => s(null)
	}) : /* @__PURE__ */ D("div", {
		style: {
			position: "relative",
			height: "100%",
			minHeight: 0
		},
		children: [/* @__PURE__ */ E(p, {
			rooms: e,
			onCreateSession: f,
			busy: i,
			error: n,
			onSelectRoom: s
		}), c === null ? /* @__PURE__ */ D("div", {
			style: {
				position: "absolute",
				right: 16,
				bottom: 16,
				display: "flex",
				gap: 8,
				zIndex: 10
			},
			children: [/* @__PURE__ */ E(u, {
				type: "button",
				size: "sm",
				"data-testid": "cockpit-open-terminal-fast",
				onClick: () => l("fast"),
				children: "⌨ Terminal · Fast"
			}), /* @__PURE__ */ E(u, {
				type: "button",
				size: "sm",
				"data-testid": "cockpit-open-terminal-smart",
				onClick: () => l("smart"),
				children: "⌨ Terminal · Smart"
			})]
		}) : /* @__PURE__ */ E("div", {
			"data-testid": "cockpit-terminal-overlay",
			style: {
				position: "absolute",
				inset: 0,
				zIndex: 20
			},
			children: /* @__PURE__ */ E(Qe, {
				tier: c,
				onClose: () => l(null)
			})
		})]
	});
}
//#endregion
//#region src/orchestrator-capabilities.ts
var Oa = new Set([
	"orchestrator-status",
	"orchestrator-list-tasks",
	"orchestrator-open-task",
	"orchestrator-create-task",
	"orchestrator-pause-task",
	"orchestrator-resume-task",
	"orchestrator-pause-all",
	"orchestrator-resume-all",
	"orchestrator-delete-task",
	"orchestrator-fork-task",
	"orchestrator-update-task",
	"orchestrator-validate-task",
	"orchestrator-add-agent",
	"orchestrator-stop-agent",
	"orchestrator-send-message"
]);
async function ka(e, t) {
	switch (e) {
		case "orchestrator-status": return g.getOrchestratorStatus();
		case "orchestrator-list-tasks": return g.listCodingAgentTaskThreads({
			includeArchived: t?.includeArchived === !0,
			status: q(t?.status),
			search: q(t?.search),
			limit: typeof t?.limit == "number" ? t.limit : 100
		});
		case "orchestrator-open-task": {
			let e = q(t?.taskId);
			if (e) return g.getCodingAgentTaskThread(e);
			let [n] = await g.listCodingAgentTaskThreads({ limit: 1 });
			return n ? g.getCodingAgentTaskThread(n.id) : null;
		}
		case "orchestrator-create-task": {
			let e = q(t?.title), n = q(t?.goal);
			if (!e || !n) throw Error("title and goal are required to create a task.");
			return g.createOrchestratorTask({
				title: e,
				goal: n,
				originalRequest: q(t?.originalRequest),
				kind: q(t?.kind),
				priority: ct(t?.priority),
				acceptanceCriteria: lt(t?.acceptanceCriteria)
			});
		}
		case "orchestrator-pause-task": return g.pauseOrchestratorTask(ut(t));
		case "orchestrator-resume-task": return g.resumeOrchestratorTask(ut(t));
		case "orchestrator-pause-all": return { paused: await g.pauseAllOrchestratorTasks() };
		case "orchestrator-resume-all": return { resumed: await g.resumeAllOrchestratorTasks() };
		case "orchestrator-delete-task": return { deleted: await g.deleteOrchestratorTask(ut(t)) };
		case "orchestrator-fork-task": return g.forkOrchestratorTask(ut(t), {
			title: q(t?.title),
			goal: q(t?.goal),
			priority: ct(t?.priority),
			acceptanceCriteria: lt(t?.acceptanceCriteria)
		});
		case "orchestrator-update-task": return g.updateOrchestratorTask(ut(t), {
			title: q(t?.title),
			goal: q(t?.goal),
			summary: q(t?.summary),
			priority: ct(t?.priority),
			acceptanceCriteria: lt(t?.acceptanceCriteria)
		});
		case "orchestrator-validate-task":
			if (typeof t?.passed != "boolean") throw Error("passed (boolean) is required to validate a task.");
			return g.validateOrchestratorTask(ut(t), {
				passed: t.passed,
				summary: q(t?.summary),
				evidence: q(t?.evidence),
				verifier: q(t?.verifier),
				humanOverride: t?.humanOverride === !0
			});
		case "orchestrator-add-agent": return g.addOrchestratorAgent(ut(t), {
			framework: q(t?.framework),
			providerSource: q(t?.providerSource),
			model: q(t?.model),
			workdir: q(t?.workdir),
			repo: q(t?.repo),
			label: q(t?.label),
			task: q(t?.task)
		});
		case "orchestrator-stop-agent": {
			let e = q(t?.sessionId);
			if (!e) throw Error("sessionId is required to stop an agent.");
			return { stopped: await g.stopOrchestratorAgent(ut(t), e) };
		}
		case "orchestrator-send-message": {
			let e = q(t?.content);
			if (!e) throw Error("content is required to send a message.");
			return { sent: await g.postOrchestratorTaskMessage(ut(t), e) };
		}
		default: throw Error(`Orchestrator view does not support "${e}".`);
	}
}
//#endregion
//#region src/CodingAgentTasksPanel.interact.ts
async function Aa(e, t) {
	if (Oa.has(e)) return ka(e, t);
	if (e === "list-sessions" || e === "refresh") return g.getCodingAgentStatus();
	if (e === "list-task-threads") return g.listCodingAgentTaskThreads({
		includeArchived: t?.includeArchived === !0,
		search: typeof t?.search == "string" ? t.search : void 0,
		limit: typeof t?.limit == "number" ? t.limit : 30
	});
	if (e === "open-thread") {
		let e = typeof t?.threadId == "string" ? t.threadId.trim() : "";
		if (e) return g.getCodingAgentTaskThread(e);
		let [n] = await g.listCodingAgentTaskThreads({
			includeArchived: !1,
			limit: 1
		});
		return n ? g.getCodingAgentTaskThread(n.id) : null;
	}
	if (e === "stop-session") {
		let e = typeof t?.sessionId == "string" ? t.sessionId.trim() : "";
		return e ? g.stopCodingAgent(e) : {
			stopped: !1,
			reason: "sessionId is required to stop a coding agent session"
		};
	}
	throw Error(`Task Coordinator TUI does not support "${e}".`);
}
//#endregion
//#region src/components/OrchestratorSpatialView.tsx
var ja = {
	status: null,
	threads: [],
	hasMore: !1,
	detail: null,
	planSteps: [],
	pendingInputs: []
}, Ma = {
	open: "primary",
	active: "success",
	validating: "primary",
	waiting_on_user: "warning",
	blocked: "warning",
	interrupted: "warning",
	done: "success",
	failed: "danger",
	archived: "muted"
}, Na = {
	open: "o",
	active: ">",
	validating: "~",
	waiting_on_user: "?",
	blocked: "!",
	interrupted: "!",
	done: "+",
	failed: "x",
	archived: "."
}, Pa = {
	low: "muted",
	normal: "default",
	high: "warning",
	urgent: "danger"
}, Fa = {
	pending: "muted",
	active: "primary",
	done: "success",
	blocked: "danger"
}, Ia = {
	pending: "[ ]",
	active: "[>]",
	done: "[x]",
	blocked: "[!]"
}, La = {
	passed: "success",
	failed: "danger",
	pending: "warning",
	unknown: "muted"
};
function Ra(e) {
	return Ma[e] ?? "muted";
}
function za(e) {
	return Na[e] ?? ".";
}
function Ba(e) {
	return e.replace(/_/g, " ");
}
function Va(e) {
	return e === 0 ? "$0" : e < 1 ? `$${e.toFixed(4)}` : `$${e.toFixed(2)}`;
}
function Ha(e) {
	return e >= 1e6 ? `${(e / 1e6).toFixed(1)}M` : e >= 1e3 ? `${(e / 1e3).toFixed(1)}K` : String(e);
}
function Ua(e, t) {
	return e.length <= t ? e : `${e.slice(0, Math.max(0, t - 1))}…`;
}
function Wa({ snapshot: e, onAction: t }) {
	let n = (e) => () => t?.(e);
	return e.detail ? /* @__PURE__ */ E(qa, {
		detail: e.detail,
		planSteps: e.planSteps,
		pendingInputs: e.pendingInputs,
		dispatch: n
	}) : /* @__PURE__ */ E(Ga, {
		status: e.status,
		threads: e.threads,
		hasMore: e.hasMore,
		loading: e.loading,
		error: e.error,
		dispatch: n
	});
}
function Ga({ status: e, threads: t, hasMore: n, loading: r, error: i, dispatch: a }) {
	return /* @__PURE__ */ D(Le, {
		gap: 1,
		padding: 1,
		children: [
			/* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				wrap: !0,
				children: [/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					grow: 1,
					children: r ? "loading" : `${t.length} threads`
				}), e ? /* @__PURE__ */ D(T, { children: [
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "success",
						children: `${e.activeTaskCount} active`
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "warning",
						children: `${e.blockedTaskCount} blocked`
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "muted",
						children: `${e.sessionCount} sessions`
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "primary",
						children: Va(e.usage.costUsd)
					})
				] }) : null]
			}),
			i ? /* @__PURE__ */ E(G, {
				tone: "danger",
				style: "caption",
				children: i
			}) : null,
			/* @__PURE__ */ D(U, {
				gap: 1,
				wrap: !0,
				children: [
					/* @__PURE__ */ E(V, {
						variant: "outline",
						tone: "default",
						agent: "pause-all",
						onPress: a("pause-all"),
						children: "Pause all"
					}),
					/* @__PURE__ */ E(V, {
						variant: "outline",
						tone: "default",
						agent: "resume-all",
						onPress: a("resume-all"),
						children: "Resume all"
					}),
					/* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "default",
						agent: "refresh",
						onPress: a("refresh"),
						children: "Refresh"
					})
				]
			}),
			/* @__PURE__ */ E(H, { label: "tasks" }),
			t.length === 0 ? /* @__PURE__ */ E(G, {
				tone: "muted",
				align: "center",
				style: "caption",
				children: "Describe a task in chat to start one."
			}) : /* @__PURE__ */ E(W, {
				gap: 1,
				children: t.map((e) => /* @__PURE__ */ E(Ka, {
					thread: e,
					dispatch: a
				}, e.id))
			}),
			n ? /* @__PURE__ */ E(G, {
				tone: "muted",
				align: "center",
				style: "caption",
				children: "more…"
			}) : null
		]
	});
}
function Ka({ thread: e, dispatch: t }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		agent: `task-${e.id}`,
		children: [/* @__PURE__ */ D(U, {
			gap: 1,
			align: "center",
			children: [
				/* @__PURE__ */ E(G, {
					tone: Ra(e.status),
					children: za(e.status)
				}),
				/* @__PURE__ */ E(G, {
					bold: !0,
					wrap: !1,
					grow: 1,
					children: e.title
				}),
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: Pa[e.priority],
					children: e.priority
				})
			]
		}), /* @__PURE__ */ D(U, {
			gap: 1,
			align: "center",
			wrap: !0,
			children: [
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: Ra(e.status),
					children: Ba(e.status)
				}),
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					children: `${e.activeSessionCount}/${e.sessionCount} sess`
				}),
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					children: `${e.decisionCount} dec`
				}),
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					children: Ha(e.usage.totalTokens)
				}),
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "primary",
					grow: 1,
					children: Va(e.usage.costUsd)
				}),
				/* @__PURE__ */ E(V, {
					variant: "outline",
					tone: "default",
					agent: `open-${e.id}`,
					onPress: t(`open:${e.id}`),
					children: "Open"
				})
			]
		})]
	});
}
function qa({ detail: e, planSteps: t, pendingInputs: n, dispatch: r }) {
	let i = e.status === "done" || e.status === "failed" || e.status === "archived";
	return /* @__PURE__ */ D(Le, {
		gap: 1,
		padding: 1,
		children: [
			/* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				children: [
					/* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "default",
						agent: "back",
						onPress: r("back"),
						children: "< Back"
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: Ra(e.status),
						grow: 1,
						children: Ba(e.status)
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: Pa[e.priority],
						children: e.priority
					})
				]
			}),
			/* @__PURE__ */ E(G, {
				style: "subheading",
				bold: !0,
				wrap: !0,
				children: e.title
			}),
			e.goal ? /* @__PURE__ */ E(G, {
				style: "caption",
				tone: "muted",
				wrap: !0,
				children: Ua(e.goal, 200)
			}) : null,
			/* @__PURE__ */ D(U, {
				gap: 1,
				wrap: !0,
				children: [
					e.paused ? /* @__PURE__ */ E(V, {
						agent: "resume",
						onPress: r("resume"),
						children: "Resume"
					}) : /* @__PURE__ */ E(V, {
						variant: "outline",
						tone: "default",
						agent: "pause",
						onPress: r("pause"),
						children: "Pause"
					}),
					/* @__PURE__ */ E(V, {
						variant: "outline",
						tone: "default",
						agent: "validate",
						onPress: r("validate"),
						children: "Validate"
					}),
					i ? null : /* @__PURE__ */ D(T, { children: [
						/* @__PURE__ */ E(V, {
							variant: "outline",
							tone: "default",
							agent: "fork",
							onPress: r("fork"),
							children: "Fork"
						}),
						/* @__PURE__ */ E(V, {
							variant: "outline",
							tone: "default",
							agent: "restart",
							onPress: r("restart"),
							children: "Restart"
						}),
						/* @__PURE__ */ E(V, {
							variant: "outline",
							tone: "default",
							agent: "add-agent",
							onPress: r("add-agent"),
							children: "Add agent"
						})
					] }),
					/* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "default",
						agent: "copy-link",
						onPress: r("copy-link"),
						children: "Copy link"
					}),
					e.status === "archived" ? /* @__PURE__ */ E(V, {
						variant: "outline",
						tone: "default",
						agent: "reopen",
						onPress: r("reopen"),
						children: "Reopen"
					}) : /* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "default",
						agent: "archive",
						onPress: r("archive"),
						children: "Archive"
					}),
					/* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "danger",
						agent: "delete",
						onPress: r("delete"),
						children: "Delete"
					})
				]
			}),
			i ? null : /* @__PURE__ */ E(ze, {
				label: "priority",
				kind: "select",
				value: e.priority,
				options: [
					"low",
					"normal",
					"high",
					"urgent"
				],
				agent: "priority",
				onChange: (e) => r(`priority:${e}`)()
			}),
			n.length > 0 ? /* @__PURE__ */ E(Ja, { inputs: n }) : null,
			t.length > 0 ? /* @__PURE__ */ E(Ya, { steps: t }) : null,
			/* @__PURE__ */ E(Xa, {
				sessions: e.sessions,
				dispatch: r
			}),
			e.decisions.length > 0 ? /* @__PURE__ */ E(Za, { decisions: e.decisions }) : null,
			e.artifacts.length > 0 ? /* @__PURE__ */ E(Qa, { artifacts: e.artifacts }) : null,
			e.events.length > 0 ? /* @__PURE__ */ E($a, { events: e.events }) : null,
			e.transcripts.length > 0 ? /* @__PURE__ */ E(eo, { transcripts: e.transcripts }) : null
		]
	});
}
function Ja({ inputs: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: "awaiting you" }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 4).map((e) => /* @__PURE__ */ D(K, {
				gap: 0,
				agent: `pending-${e.sessionId}`,
				children: [/* @__PURE__ */ E(G, {
					tone: "warning",
					bold: !0,
					wrap: !0,
					children: Ua(e.promptText, 120)
				}), e.recentOutput ? /* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					wrap: !1,
					children: Ua(e.recentOutput, 80)
				}) : null]
			}, e.sessionId))
		})]
	});
}
function Ya({ steps: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: "plan" }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 10).map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `plan-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					tone: Fa[e.state],
					children: Ia[e.state]
				}), /* @__PURE__ */ E(G, {
					grow: 1,
					wrap: !1,
					tone: e.state === "done" ? "muted" : "default",
					children: e.label
				})]
			}, e.id))
		})]
	});
}
function Xa({ sessions: e, dispatch: t }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `sessions (${e.length})` }), e.length === 0 ? /* @__PURE__ */ E(G, {
			tone: "muted",
			align: "center",
			style: "caption",
			children: "None"
		}) : /* @__PURE__ */ E(W, {
			gap: 1,
			children: e.slice(0, 8).map((e) => /* @__PURE__ */ D(K, {
				gap: 0,
				agent: `session-${e.sessionId}`,
				children: [/* @__PURE__ */ D(U, {
					gap: 1,
					align: "center",
					children: [
						/* @__PURE__ */ E(G, {
							tone: Ra(e.status),
							children: za(e.status)
						}),
						/* @__PURE__ */ E(G, {
							bold: !0,
							wrap: !1,
							grow: 1,
							children: e.label
						}),
						/* @__PURE__ */ E(V, {
							variant: "ghost",
							tone: "danger",
							agent: `stop-${e.sessionId}`,
							onPress: t(`stop-session:${e.sessionId}`),
							children: "Stop"
						})
					]
				}), /* @__PURE__ */ D(U, {
					gap: 1,
					align: "center",
					wrap: !0,
					children: [
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: "muted",
							children: e.framework
						}),
						e.model ? /* @__PURE__ */ E(G, {
							style: "caption",
							tone: "muted",
							wrap: !1,
							children: e.model
						}) : null,
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: "muted",
							children: Ha(e.totalTokens)
						}),
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: "primary",
							grow: 1,
							children: Va(e.costUsd)
						}),
						e.activeTool ? /* @__PURE__ */ E(G, {
							style: "caption",
							tone: "success",
							wrap: !1,
							children: e.activeTool
						}) : null
					]
				})]
			}, e.id))
		})]
	});
}
function Za({ decisions: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `decisions (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 6).map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `decision-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					tone: "primary",
					wrap: !1,
					children: e.decision
				}), /* @__PURE__ */ E(G, {
					grow: 1,
					wrap: !1,
					children: Ua(e.promptText, 100)
				})]
			}, e.id))
		})]
	});
}
function Qa({ artifacts: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `artifacts (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 6).map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `artifact-${e.id}`,
				children: [
					/* @__PURE__ */ E(G, {
						tone: La[e.verificationStatus],
						wrap: !1,
						children: e.verificationStatus === "passed" ? "+" : e.verificationStatus === "failed" ? "x" : e.verificationStatus === "pending" ? "~" : "."
					}),
					/* @__PURE__ */ E(G, {
						grow: 1,
						wrap: !1,
						children: e.title
					}),
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "muted",
						wrap: !1,
						children: e.artifactType
					})
				]
			}, e.id))
		})]
	});
}
function $a({ events: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `events (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 6).map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `event-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					wrap: !1,
					children: e.eventType
				}), /* @__PURE__ */ E(G, {
					style: "caption",
					grow: 1,
					wrap: !1,
					children: Ua(e.summary, 90)
				})]
			}, e.id))
		})]
	});
}
function eo({ transcripts: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `transcript (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(-6).map((e) => /* @__PURE__ */ E(G, {
				style: "caption",
				tone: e.direction === "stderr" ? "danger" : "muted",
				wrap: !1,
				children: Ua(e.content.replace(/\s+/g, " ").trim(), 110)
			}, e.id))
		})]
	});
}
//#endregion
//#region src/OrchestratorView.tsx
function to() {
	return /* @__PURE__ */ E(Re, {
		width: "100%",
		height: "100%",
		tui: /* @__PURE__ */ E(Wa, { snapshot: ja }),
		children: /* @__PURE__ */ E(wa, {})
	});
}
//#endregion
//#region src/components/TaskCoordinatorSpatialView.tsx
var no = {
	open: "primary",
	active: "success",
	validating: "primary",
	waiting_on_user: "warning",
	blocked: "warning",
	interrupted: "warning",
	done: "success",
	failed: "danger",
	archived: "muted"
}, ro = {
	open: "o",
	active: ">",
	validating: "~",
	waiting_on_user: "?",
	blocked: "!",
	interrupted: "!",
	done: "+",
	failed: "x",
	archived: "."
};
function io(e) {
	return no[e] ?? "muted";
}
function ao(e) {
	return ro[e] ?? ".";
}
function oo(e) {
	return e.replace(/_/g, " ");
}
function so(e, t) {
	return e.length <= t ? e : `${e.slice(0, Math.max(0, t - 1))}…`;
}
function co(e) {
	return {
		id: e.id,
		title: e.title,
		subtitle: e.summary || e.originalRequest || void 0,
		status: e.status,
		sessionCount: e.sessionCount,
		decisionCount: e.decisionCount
	};
}
function lo({ snapshot: e, onAction: t }) {
	let n = (e) => () => t?.(e);
	return e.detail ? /* @__PURE__ */ E(po, {
		detail: e.detail,
		dispatch: n,
		onAction: t
	}) : /* @__PURE__ */ E(uo, {
		threads: e.threads,
		showArchived: e.showArchived,
		search: e.search,
		loading: e.loading,
		error: e.error,
		dispatch: n,
		onAction: t
	});
}
function uo({ threads: e, showArchived: t, search: n, loading: r, error: i, dispatch: a, onAction: o }) {
	let s = e.filter((e) => e.status === "active").length, c = e.filter((e) => e.status === "done").length;
	return /* @__PURE__ */ D(Le, {
		gap: 1,
		padding: 1,
		children: [
			/* @__PURE__ */ E(Be, { size: 8 }),
			/* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				wrap: !0,
				children: [
					/* @__PURE__ */ E(G, {
						style: "caption",
						tone: "muted",
						grow: 1,
						children: r ? "loading" : `${e.length} total`
					}),
					s > 0 ? /* @__PURE__ */ E(G, {
						style: "caption",
						tone: "success",
						children: `${s} active`
					}) : null,
					c > 0 ? /* @__PURE__ */ E(G, {
						style: "caption",
						tone: "primary",
						children: `${c} done`
					}) : null
				]
			}),
			i ? /* @__PURE__ */ E(G, {
				tone: "danger",
				style: "caption",
				children: i
			}) : null,
			/* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				wrap: !0,
				children: [
					/* @__PURE__ */ E(ze, {
						placeholder: "Search tasks",
						value: n,
						agent: "search",
						grow: 1,
						onChange: (e) => o?.(`search:${e}`)
					}),
					/* @__PURE__ */ E(V, {
						variant: t ? "solid" : "outline",
						tone: "default",
						agent: "toggle-archived",
						onPress: a("toggle-archived"),
						children: t ? "Hide archived" : "Show archived"
					}),
					/* @__PURE__ */ E(V, {
						variant: "ghost",
						tone: "default",
						agent: "refresh",
						onPress: a("refresh"),
						children: "Refresh"
					})
				]
			}),
			/* @__PURE__ */ E(H, { label: "tasks" }),
			e.length === 0 ? /* @__PURE__ */ E(G, {
				tone: "muted",
				align: "center",
				style: "caption",
				children: r ? "Loading" : "Dispatch a coding agent from chat."
			}) : /* @__PURE__ */ E(W, {
				gap: 1,
				children: e.map((e) => /* @__PURE__ */ E(fo, {
					thread: e,
					dispatch: a
				}, e.id))
			})
		]
	});
}
function fo({ thread: e, dispatch: t }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		agent: `task-${e.id}`,
		children: [/* @__PURE__ */ D(U, {
			gap: 1,
			align: "center",
			children: [
				/* @__PURE__ */ E(G, {
					tone: io(e.status),
					children: ao(e.status)
				}),
				/* @__PURE__ */ E(G, {
					bold: !0,
					wrap: !1,
					grow: 1,
					children: e.title
				}),
				/* @__PURE__ */ E(V, {
					variant: "outline",
					tone: "default",
					agent: `open-${e.id}`,
					onPress: t(`open:${e.id}`),
					children: "Open"
				})
			]
		}), /* @__PURE__ */ D(U, {
			gap: 1,
			align: "center",
			wrap: !0,
			children: [
				/* @__PURE__ */ E(G, {
					style: "caption",
					tone: io(e.status),
					children: oo(e.status)
				}),
				e.sessionCount > 0 ? /* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					children: `${e.sessionCount} sess`
				}) : null,
				e.decisionCount > 0 ? /* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					children: `${e.decisionCount} dec`
				}) : null,
				e.subtitle ? /* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					grow: 1,
					wrap: !1,
					children: so(e.subtitle, 80)
				}) : null
			]
		})]
	});
}
function po({ detail: e, dispatch: t }) {
	return /* @__PURE__ */ D(Le, {
		gap: 1,
		padding: 1,
		children: [
			/* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				children: [/* @__PURE__ */ E(V, {
					variant: "ghost",
					tone: "default",
					agent: "back",
					onPress: t("back"),
					children: "< Tasks"
				}), /* @__PURE__ */ E(G, {
					style: "caption",
					tone: io(e.status),
					grow: 1,
					children: oo(e.status)
				})]
			}),
			/* @__PURE__ */ E(G, {
				style: "subheading",
				bold: !0,
				wrap: !0,
				children: e.title
			}),
			e.originalRequest ? /* @__PURE__ */ E(G, {
				style: "caption",
				tone: "muted",
				wrap: !0,
				children: so(e.originalRequest, 200)
			}) : null,
			/* @__PURE__ */ E(U, {
				gap: 1,
				wrap: !0,
				children: e.status === "archived" ? /* @__PURE__ */ E(V, {
					agent: "reopen-thread",
					onPress: t("reopen-thread"),
					children: "Reopen"
				}) : /* @__PURE__ */ E(V, {
					variant: "ghost",
					tone: "danger",
					agent: "delete-thread",
					onPress: t("delete-thread"),
					children: "Delete"
				})
			}),
			e.acceptanceCriteria.length > 0 ? /* @__PURE__ */ E(mo, { criteria: e.acceptanceCriteria }) : null,
			/* @__PURE__ */ E(ho, { sessions: e.sessions }),
			e.artifacts.length > 0 ? /* @__PURE__ */ E(go, { artifacts: e.artifacts }) : null,
			e.decisions.length > 0 ? /* @__PURE__ */ E(_o, { decisions: e.decisions }) : null,
			e.events.length > 0 ? /* @__PURE__ */ E(vo, { events: e.events }) : null
		]
	});
}
function mo({ criteria: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: "acceptance" }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(0, 8).map((e) => /* @__PURE__ */ E(G, {
				style: "caption",
				wrap: !0,
				children: so(e, 110)
			}, e))
		})]
	});
}
function ho({ sessions: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `sessions (${e.length})` }), e.length === 0 ? /* @__PURE__ */ E(G, {
			tone: "muted",
			align: "center",
			style: "caption",
			children: "None"
		}) : /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(-6).reverse().map((e) => /* @__PURE__ */ D(K, {
				gap: 0,
				agent: `session-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					bold: !0,
					wrap: !1,
					children: e.label
				}), /* @__PURE__ */ D(U, {
					gap: 1,
					align: "center",
					wrap: !0,
					children: [
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: io(e.status),
							children: oo(e.status)
						}),
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: "muted",
							children: e.framework
						}),
						/* @__PURE__ */ E(G, {
							style: "caption",
							tone: "muted",
							grow: 1,
							wrap: !1,
							children: e.workdir || e.repo || "no workspace"
						})
					]
				})]
			}, e.id))
		})]
	});
}
function go({ artifacts: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `artifacts (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(-6).reverse().map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `artifact-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					grow: 1,
					wrap: !1,
					children: e.title
				}), /* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					wrap: !1,
					children: e.artifactType
				})]
			}, e.id))
		})]
	});
}
function _o({ decisions: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `decisions (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(-6).reverse().map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `decision-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					tone: "primary",
					wrap: !1,
					children: e.decision
				}), /* @__PURE__ */ E(G, {
					grow: 1,
					wrap: !1,
					children: so(e.reasoning || e.promptText, 100)
				})]
			}, e.id))
		})]
	});
}
function vo({ events: e }) {
	return /* @__PURE__ */ D(K, {
		gap: 0,
		children: [/* @__PURE__ */ E(H, { label: `events (${e.length})` }), /* @__PURE__ */ E(W, {
			gap: 0,
			children: e.slice(-6).reverse().map((e) => /* @__PURE__ */ D(U, {
				gap: 1,
				align: "center",
				agent: `event-${e.id}`,
				children: [/* @__PURE__ */ E(G, {
					style: "caption",
					tone: "muted",
					wrap: !1,
					children: e.eventType.replace(/_/g, " ")
				}), /* @__PURE__ */ E(G, {
					style: "caption",
					grow: 1,
					wrap: !1,
					children: so(e.summary, 90)
				})]
			}, e.id))
		})]
	});
}
//#endregion
//#region src/TaskCoordinatorView.tsx
var yo = 30;
function bo(e) {
	return e instanceof Error ? e.message : String(e);
}
function xo() {
	let [e, t] = w([]), [n, r] = w(null), [i, a] = w(null), [o, s] = w(!1), [c, u] = w(""), [d, f] = w(!0), [p, m] = w(null), h = y(async (e = !1) => {
		e || f(!0);
		try {
			let e = await g.listCodingAgentTaskThreads({
				includeArchived: o,
				search: c.trim() || void 0,
				limit: yo
			});
			t(e), m(null), r((t) => (t && e.some((e) => e.id === t), t));
		} catch (n) {
			if (n instanceof l && n.status === 404) {
				t([]), m(null);
				return;
			}
			e || (m(bo(n)), t([]));
		} finally {
			e || f(!1);
		}
	}, [o, c]), _ = y(async (e) => {
		try {
			a(await g.getCodingAgentTaskThread(e)), m(null);
		} catch (e) {
			m(bo(e)), a(null);
		}
	}, []), v = C(!1);
	x(() => {
		v.current = !0, h(!1);
		let e = setInterval(() => {
			h(!0), n && _(n);
		}, 5e3);
		return () => clearInterval(e);
	}, [
		h,
		_,
		n
	]), x(() => {
		if (!n) {
			a(null);
			return;
		}
		_(n);
	}, [n, _]);
	let b = y(async (e) => {
		try {
			await e(), r(null), await h(!0);
		} catch (e) {
			m(bo(e));
		}
	}, [h]), S = y((e) => {
		if (e.startsWith("open:")) {
			r(e.slice(5));
			return;
		}
		if (e.startsWith("search:")) {
			u(e.slice(7));
			return;
		}
		switch (e) {
			case "toggle-archived":
				s((e) => !e);
				return;
			case "refresh":
				h(!1);
				return;
			case "back":
				r(null);
				return;
			case "delete-thread":
				n && b(() => g.archiveCodingAgentTaskThread(n));
				return;
			case "reopen-thread":
				n && (s(!1), b(() => g.reopenCodingAgentTaskThread(n)));
				return;
		}
	}, [
		h,
		b,
		n
	]);
	return /* @__PURE__ */ E("div", {
		"data-testid": "task-coordinator-panel",
		style: {
			display: "flex",
			flexDirection: "column",
			width: "100%",
			height: "100%",
			minHeight: 0,
			minWidth: 0
		},
		children: /* @__PURE__ */ E(lo, {
			snapshot: {
				threads: e.map(co),
				selectedThreadId: n,
				detail: i,
				showArchived: o,
				search: c,
				loading: d,
				error: p
			},
			onAction: S
		})
	});
}
//#endregion
export { Da as CockpitRoute, to as OrchestratorView, xo as TaskCoordinatorView, Aa as interact, qe as t };

//# sourceMappingURL=bundle.js.map